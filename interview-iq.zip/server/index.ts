import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { evaluateCandidateAnswer, chatWithAIMentor } from './ai-service.js';
import { SERVER_QUESTION_BANK, ServerQuestion } from './question-bank.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  const hasGeminiKey = !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'your_gemini_api_key_here';
  res.json({
    status: 'online',
    platform: 'InterviewIQ Backend AI Service',
    ai_provider: hasGeminiKey ? 'Google Gemini 3.8 Flash' : 'Semantic Heuristic Engine (Offline / Demo Mode)',
    gemini_configured: hasGeminiKey,
    questions_count: SERVER_QUESTION_BANK.length,
    timestamp: new Date().toISOString(),
  });
});

// Questions list endpoint
app.get('/api/questions', (req: Request, res: Response) => {
  const { field, company, difficulty } = req.query;
  let results = [...SERVER_QUESTION_BANK];

  if (field && typeof field === 'string' && field !== 'All') {
    results = results.filter(q => q.field.toLowerCase().includes(field.toLowerCase()));
  }

  if (company && typeof company === 'string' && company !== 'All') {
    results = results.filter(q => q.company?.toLowerCase() === company.toLowerCase());
  }

  if (difficulty && typeof difficulty === 'string' && difficulty !== 'All') {
    results = results.filter(q => q.difficulty.toLowerCase() === difficulty.toLowerCase());
  }

  res.json(results);
});

// Evaluate interview answer endpoint
app.post('/api/evaluate', async (req: Request, res: Response) => {
  try {
    const { question_text, role_name, difficulty, topic, answer_text } = req.body;

    if (!question_text || typeof question_text !== 'string') {
      res.status(400).json({ error: 'question_text is required.' });
      return;
    }

    if (!answer_text || typeof answer_text !== 'string' || answer_text.trim().length < 5) {
      res.status(400).json({ error: 'answer_text must contain at least 5 characters.' });
      return;
    }

    const evaluation = await evaluateCandidateAnswer({
      question_text,
      role_name,
      difficulty,
      topic,
      answer_text,
    });

    res.json(evaluation);
  } catch (error: any) {
    console.error('Error during AI answer evaluation:', error);
    res.status(500).json({
      error: 'Evaluation failed due to an internal server error.',
      message: error?.message || 'Unknown error',
    });
  }
});

// Follow-up question generator endpoint
app.post('/api/followup', async (req: Request, res: Response) => {
  try {
    const { question_text, answer_text, topic } = req.body;
    const answerLower = (answer_text || '').toLowerCase();

    let result = {
      question_text: 'Could you walk me through a specific edge case or failure mode you encountered with this approach, and how you ensured system resilience?',
      context_reason: 'Interviewer wants to test your production troubleshooting and defensive architecture.',
      suggested_focus: 'Discuss error handling, latency, or concurrency bottlenecks.',
    };

    if (answerLower.includes('react') || answerLower.includes('component')) {
      result = {
        question_text: 'You highlighted using React components and state. How do you prevent unnecessary re-renders across the component tree, and what criteria determine whether you reach for useCallback vs useMemo vs React.memo?',
        context_reason: 'Interviewer wants to test your advanced render lifecycle & memoization mechanics.',
        suggested_focus: 'Explain referential equality, props comparison, and performance profiling.',
      };
    } else if (answerLower.includes('sql') || answerLower.includes('database')) {
      result = {
        question_text: 'Following up on your database explanation: How would you investigate a high-latency query running against a table with 10 million rows, and how do composite B-Tree indexes impact write throughput?',
        context_reason: 'Interviewer wants to evaluate your production indexing & query execution plan mastery.',
        suggested_focus: 'Cite EXPLAIN ANALYZE, index selectivity, write amplification, and connection pooling.',
      };
    } else if (answerLower.includes('api') || answerLower.includes('microservice') || answerLower.includes('backend')) {
      result = {
        question_text: 'How do you handle distributed failure scenarios when a downstream dependency times out, and how do you guarantee idempotency for critical data modification POST endpoints?',
        context_reason: 'Interviewer is evaluating your production resilience, circuit breaking, and idempotency guarantees.',
        suggested_focus: 'Mention Idempotency Keys, Circuit Breaker patterns, Exponential Backoff, and Dead Letter Queues.',
      };
    }

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error?.message || 'Failed to generate follow-up' });
  }
});

// AI Mentor Chat endpoint (real conversational multi-turn with student profile & history context)
app.post('/api/mentor/chat', async (req: Request, res: Response) => {
  try {
    const { message, conversationHistory = [], studentProfile = {}, interviewContext = {} } = req.body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      res.status(400).json({
        error: 'Validation Error',
        message: 'Message cannot be empty.',
        code: 'EMPTY_MESSAGE',
      });
      return;
    }

    const mentorResponse = await chatWithAIMentor({
      message: message.trim(),
      conversationHistory,
      studentProfile,
      interviewContext,
    });

    res.json(mentorResponse);
  } catch (error: any) {
    console.error('Error in AI Mentor Chat:', error);
    const statusCode = error.statusCode || 500;
    res.status(statusCode).json({
      error: error.name || 'AI Mentor Service Error',
      message: error.message || 'The AI service encountered an issue processing your request.',
      code: error.code || 'AI_SERVICE_ERROR',
    });
  }
});

// Configure Gemini API key endpoint
app.post('/api/settings/gemini-key', (req: Request, res: Response) => {
  try {
    const apiKey = (req.body.apiKey || req.body.key || '').trim();
    if (!apiKey || typeof apiKey !== 'string' || apiKey.length < 8) {
      res.status(400).json({ error: 'Please provide a valid Gemini API key.' });
      return;
    }

    const cleanKey = apiKey;
    process.env.GEMINI_API_KEY = cleanKey;

    // Persist key to .env so it remains active across server restarts
    try {
      const envPath = path.resolve(process.cwd(), '.env');
      let envContent = '';
      if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf8');
        if (/GEMINI_API_KEY=.*/.test(envContent)) {
          envContent = envContent.replace(/GEMINI_API_KEY=.*/, `GEMINI_API_KEY=${cleanKey}`);
        } else {
          envContent += `\nGEMINI_API_KEY=${cleanKey}\n`;
        }
      } else {
        envContent = `PORT=5000\nGEMINI_API_KEY=${cleanKey}\n`;
      }
      fs.writeFileSync(envPath, envContent, 'utf8');
    } catch (fsErr) {
      console.warn('Could not persist GEMINI_API_KEY to .env file:', fsErr);
    }

    res.json({
      success: true,
      message: 'Gemini API key configured and activated successfully.',
      gemini_configured: true,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to save API key' });
  }
});

// AI Configuration Status endpoint
app.get('/api/settings/ai-status', (req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;
  const isConfigured = !!apiKey && apiKey.trim() !== '' && apiKey !== 'your_gemini_api_key_here';
  
  res.json({
    gemini_configured: isConfigured,
    model: isConfigured ? 'gemini-2.5-flash / gemini-1.5-flash' : 'None',
    key_preview: isConfigured ? `...${apiKey.slice(-4)}` : null,
  });
});

// Start Express server
app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`InterviewIQ AI Evaluation Backend running on http://127.0.0.1:${PORT}`);
});

