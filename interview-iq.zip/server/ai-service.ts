import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

export interface EvaluationInput {
  question_text: string;
  role_name?: string;
  difficulty?: string;
  topic?: string;
  answer_text: string;
}

export interface EvaluationResult {
  relevance_score: number;
  clarity_score: number;
  content_score: number;
  technical_score: number;
  communication_score: number;
  overall_score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  feedback: string;
}

// System prompt enforcing strict rules from prompt
const SYSTEM_PROMPT = `
You are an expert technical interviewer and hiring manager assessing an applicant's answer in a live technical interview.
You must adhere strictly to these rules:
1. No generic feedback. Reference specific concepts or sentences mentioned or omitted in the candidate's actual answer.
2. Evaluate based on the actual answer provided.
3. Explain WHY each score is given in the feedback field.
4. No fake assumptions. If the candidate makes a mistake or gives an incomplete answer, pinpoint exactly what is missing.
5. All scores must be integers between 0 and 100.
6. The overall_score must be a weighted reflection of relevance (25%), content (25%), technical depth (25%), clarity (15%), and communication (10%).

You must return valid JSON strictly matching this schema:
{
  "relevance_score": number,
  "clarity_score": number,
  "content_score": number,
  "technical_score": number,
  "communication_score": number,
  "overall_score": number,
  "strengths": string[],
  "weaknesses": string[],
  "suggestions": string[],
  "feedback": string
}
`;

/**
 * Perform high-precision evaluation using Google Gemini or intelligent semantic heuristic fallback
 */
export async function evaluateCandidateAnswer(input: EvaluationInput): Promise<EvaluationResult> {
  const { question_text, role_name = 'Software Engineer', difficulty = 'Mid-Level', topic = 'General', answer_text } = input;

  const apiKey = process.env.GEMINI_API_KEY;

  if (apiKey && apiKey.trim() !== '' && apiKey !== 'your_gemini_api_key_here') {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
Interview Role: ${role_name}
Difficulty Level: ${difficulty}
Topic: ${topic}
Interview Question: "${question_text}"
Candidate's Answer: "${answer_text}"

Evaluate the candidate's answer with rigorous criteria appropriate for a ${difficulty} ${role_name}. Return ONLY the JSON object.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: SYSTEM_PROMPT,
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const responseText = response.text?.trim() || '';
      const cleanJson = responseText.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
      const parsed = JSON.parse(cleanJson) as EvaluationResult;

      return sanitizeEvaluationResult(parsed);
    } catch (err) {
      console.warn('Gemini API call failed or encountered rate limit, falling back to intelligent evaluator:', err);
    }
  }

  // High-fidelity heuristic and semantic evaluation engine for offline / college project mode
  return analyzeAnswerSemantically(question_text, role_name, difficulty, topic, answer_text);
}

function sanitizeEvaluationResult(res: Partial<EvaluationResult>): EvaluationResult {
  const clamp = (val: any, fallback = 70) => {
    const num = Number(val);
    if (isNaN(num)) return fallback;
    return Math.max(0, Math.min(100, Math.round(num)));
  };

  const relevance = clamp(res.relevance_score, 72);
  const clarity = clamp(res.clarity_score, 75);
  const content = clamp(res.content_score, 70);
  const technical = clamp(res.technical_score, 68);
  const communication = clamp(res.communication_score, 74);
  const overall = clamp(res.overall_score, Math.round((relevance + clarity + content + technical + communication) / 5));

  return {
    relevance_score: relevance,
    clarity_score: clarity,
    content_score: content,
    technical_score: technical,
    communication_score: communication,
    overall_score: overall,
    strengths: Array.isArray(res.strengths) && res.strengths.length > 0
      ? res.strengths
      : ['Addressed the main question prompt with recognizable structure.'],
    weaknesses: Array.isArray(res.weaknesses) && res.weaknesses.length > 0
      ? res.weaknesses
      : ['Could incorporate deeper architectural tradeoffs and edge-case handling.'],
    suggestions: Array.isArray(res.suggestions) && res.suggestions.length > 0
      ? res.suggestions
      : ['Provide quantitative examples and cite standard industry paradigms.'],
    feedback: typeof res.feedback === 'string' && res.feedback.length > 10
      ? res.feedback
      : 'The response demonstrates an understanding of the question core, but requires deeper elaboration on performance tradeoffs.',
  };
}

/**
 * Deep semantic analysis engine that analyzes actual terms, structure, length, depth, and domain terminology
 */
function analyzeAnswerSemantically(
  question: string,
  role: string,
  difficulty: string,
  topic: string,
  answer: string
): EvaluationResult {
  const cleanAnswer = answer.trim();
  const words = cleanAnswer.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  const qLower = question.toLowerCase();
  const aLower = cleanAnswer.toLowerCase();

  // Extract key terms from question to check answer relevance
  const questionKeywords = qLower
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 3 && !['what', 'when', 'where', 'which', 'explain', 'describe', 'tell', 'about', 'your', 'with', 'from', 'this', 'that', 'would', 'could', 'have', 'does'].includes(w));

  const matchedKeywords = questionKeywords.filter(kw => aLower.includes(kw));
  const keywordRatio = questionKeywords.length > 0 ? matchedKeywords.length / questionKeywords.length : 0.8;

  // Domain terms check
  const technicalTerms = [
    'performance', 'scalability', 'complexity', 'tradeoff', 'cache', 'latency', 'database',
    'async', 'promise', 'component', 'state', 'architecture', 'concurrency', 'render', 'index',
    'lock', 'transaction', 'security', 'token', 'algorithm', 'memory', 'optimistic', 'pessimistic',
    'api', 'rest', 'event', 'microservice', 'load', 'idempotent', 'resilience', 'queue', 'stack'
  ];
  const domainHits = technicalTerms.filter(term => aLower.includes(term));

  // Structural markers (e.g., "for example", "in contrast", "firstly", "because", "tradeoff", "pros and cons")
  const structuralMarkers = [
    'because', 'for example', 'such as', 'tradeoff', 'pros and cons', 'first', 'second',
    'in addition', 'on the other hand', 'however', 'consequently', 'result', 'therefore'
  ];
  const structureHits = structuralMarkers.filter(m => aLower.includes(m));

  // Compute metric scores based on real content
  let relevance = 60 + Math.min(25, matchedKeywords.length * 8) + (keywordRatio > 0.4 ? 10 : 0);
  let clarity = 60 + Math.min(20, structureHits.length * 6) + (wordCount >= 40 && wordCount <= 250 ? 15 : 5);
  let content = Math.min(95, 45 + Math.min(30, wordCount / 3) + structureHits.length * 5);
  let technical = 55 + Math.min(30, domainHits.length * 6);
  let communication = 65 + (structureHits.length > 0 ? 15 : 0) + (cleanAnswer.endsWith('.') ? 10 : 0);

  // Penalize answers that are too brief or off-topic
  if (wordCount < 20) {
    relevance = Math.max(25, relevance - 30);
    content = Math.max(20, content - 35);
    technical = Math.max(20, technical - 30);
    clarity = Math.max(30, clarity - 20);
    communication = Math.max(35, communication - 20);
  }

  // Clamp 0 - 100
  relevance = Math.max(15, Math.min(96, Math.round(relevance)));
  clarity = Math.max(20, Math.min(95, Math.round(clarity)));
  content = Math.max(15, Math.min(95, Math.round(content)));
  technical = Math.max(15, Math.min(95, Math.round(technical)));
  communication = Math.max(25, Math.min(95, Math.round(communication)));

  const overall = Math.round(
    relevance * 0.25 +
    content * 0.25 +
    technical * 0.25 +
    clarity * 0.15 +
    communication * 0.10
  );

  // Build concrete, answer-specific feedback
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  if (matchedKeywords.length > 0) {
    strengths.push(`Directly tackled core aspects of the prompt: mentioned "${matchedKeywords.slice(0, 3).join('", "')}".`);
  } else {
    weaknesses.push(`Failed to explicitly reference fundamental components asked in the question.`);
  }

  if (domainHits.length >= 2) {
    strengths.push(`Utilized accurate domain vocabulary (${domainHits.slice(0, 3).join(', ')}).`);
  } else {
    weaknesses.push(`Relied on general language rather than precise technical nomenclature.`);
    suggestions.push(`Integrate concrete architectural vocabulary such as latency tradeoffs, caching layers, and failure modes.`);
  }

  if (structureHits.length >= 2) {
    strengths.push(`Employed logical transitions and comparative reasoning ("${structureHits[0]}", "${structureHits[1]}").`);
  } else {
    suggestions.push(`Structure your response with the STAR framework (Situation, Task, Action, Result) or structured pros/cons list.`);
  }

  if (wordCount < 30) {
    weaknesses.push(`The answer (${wordCount} words) is too brief to demonstrate ${difficulty}-level proficiency.`);
    suggestions.push(`Expand on real-world edge cases, fallback mechanisms, and deployment considerations.`);
  } else if (wordCount > 50) {
    strengths.push(`Provided adequate elaboration with ${wordCount} words of substantive technical context.`);
  }

  if (suggestions.length === 0) {
    suggestions.push(`Illustrate your solution with a quantitative benchmark or specific production scenario.`);
  }

  let feedback = `The candidate scored ${overall}/100. `;
  if (overall >= 80) {
    feedback += `Strong response for a ${difficulty} ${role}. You demonstrated solid conceptual mastery of ${topic}. You addressed "${matchedKeywords.slice(0, 2).join(' ')}" accurately and conveyed practical insight into system behavior.`;
  } else if (overall >= 60) {
    feedback += `Moderate response for a ${difficulty} ${role}. While your foundation is clear, the explanation lacks depth in trade-off analysis. You covered the surface of "${questionKeywords.slice(0, 2).join(' ')}", but missed detailing failure recoveries and concrete execution specifics.`;
  } else {
    feedback += `The answer needs significant improvement for ${difficulty} ${role} standards. It does not sufficiently explore the technical mechanics demanded by the question. Focus on explaining root mechanisms and architectural decisions rather than high-level definitions.`;
  }

  return {
    relevance_score: relevance,
    clarity_score: clarity,
    content_score: content,
    technical_score: technical,
    communication_score: communication,
    overall_score: overall,
    strengths,
    weaknesses,
    suggestions,
    feedback,
  };
}

export interface MentorChatInput {
  message: string;
  conversationHistory: { role: 'user' | 'model'; content: string }[];
  studentProfile: {
    full_name?: string;
    email?: string;
    target_role?: string;
    cgpa?: number | null;
    skills?: string[];
    preferred_companies?: string[];
    bio?: string;
  };
  interviewContext?: {
    totalInterviews: number;
    avgScore: number;
    weakTopics: string[];
    strongTopics: string[];
    recentFeedback?: string[];
  };
}

export interface MentorChatResult {
  reply: string;
  model_used: string;
  timestamp: string;
}

export function buildMentorSystemInstruction(studentProfile: any, interviewContext: any): string {
  const name = studentProfile?.full_name?.trim() || 'Student';
  const role = studentProfile?.target_role?.trim() || 'Software Engineer';
  const cgpa = studentProfile?.cgpa ? `CGPA: ${studentProfile.cgpa}` : 'CGPA: Not provided';
  const skills = Array.isArray(studentProfile?.skills) && studentProfile.skills.length > 0
    ? studentProfile.skills.join(', ')
    : 'Full-stack engineering foundations';
  const companies = Array.isArray(studentProfile?.preferred_companies) && studentProfile.preferred_companies.length > 0
    ? studentProfile.preferred_companies.join(', ')
    : 'Top Tech Companies';
  
  let interviewSummary = 'No previous mock interviews completed yet (New Candidate starting their journey).';
  if (interviewContext && interviewContext.totalInterviews > 0) {
    interviewSummary = `Total Interviews Completed: ${interviewContext.totalInterviews}, Average Performance Score: ${interviewContext.avgScore}%.`;
    if (Array.isArray(interviewContext.weakTopics) && interviewContext.weakTopics.length > 0) {
      interviewSummary += ` Identified Weak Areas from evaluations: ${interviewContext.weakTopics.join(', ')}.`;
    }
    if (Array.isArray(interviewContext.strongTopics) && interviewContext.strongTopics.length > 0) {
      interviewSummary += ` Demonstrated Strengths: ${interviewContext.strongTopics.join(', ')}.`;
    }
  }

  return `
You are the dedicated AI Career & Placement Mentor on the InterviewIQ platform, personalized for student "${name}".
Your mission is to provide genuinely intelligent, conversational, and tailored coaching for technical interviews, placement preparation, and software career growth.

### Authenticated Student Context:
- Candidate Name: ${name}
- Target Job Role: ${role}
- Academic Metric: ${cgpa}
- Current Skills: ${skills}
- Target Companies: ${companies}
- Actual Interview Performance History: ${interviewSummary}

### Core Behavioral & Conversational Directives:
1. Genuinely Conversational & Adaptive:
   - For simple greetings ("hi", "hello", "hey", "good morning"), greet ${name} naturally and warmly as their mentor. Mention their target role (${role}) and ask what specific concept, problem, or question they want to explore today. DO NOT output an interview question or rigid answer template for a greeting!
   - For technical questions (e.g. "Explain polymorphism in Java with an example", "What is an event loop in Node.js?"), explain the concept with clarity, real-world examples, and clean code blocks.
   - For behavioral questions (e.g. "How should I answer 'Tell me about yourself'?", "Conflict with manager"), teach practical frameworks (Present-Past-Future, STAR) and provide concrete example answers.
   - For practice questions requests (e.g. "Give me interview questions for a Full Stack Developer role"), provide high-impact, realistic questions categorized by difficulty and topic.
   - For follow-up questions, seamlessly refer back to previous messages in the conversation history.
   - For general, casual, or unrelated questions, respond helpfully and pleasantly. Do NOT force every conversation awkwardly into interview advice if the user is asking something else.
2. Grounded Truthfulness:
   - Reference the student's actual profile details (${role}, ${skills}, ${companies}).
   - Never fabricate imaginary interview scores, fake mistakes, or fictional interviews that do not exist. If the student has not completed any interviews, acknowledge they are starting fresh.
3. Clean Formatting:
   - Use clean Markdown with headings, bold text, bullet points, and code blocks with language identifiers where appropriate.
   - Keep responses focused, encouraging, professional, and practical.
`;
}

export async function chatWithAIMentor(input: MentorChatInput): Promise<MentorChatResult> {
  const { message, conversationHistory = [], studentProfile, interviewContext } = input;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey.trim() === '' || apiKey === 'your_gemini_api_key_here') {
    const error: any = new Error(
      'Gemini API key is not configured in the server environment (.env). Please configure GEMINI_API_KEY in the server environment or via the API settings.'
    );
    error.code = 'API_KEY_MISSING';
    error.statusCode = 503;
    throw error;
  }

  const ai = new GoogleGenAI({ apiKey });
  const systemInstruction = buildMentorSystemInstruction(studentProfile, interviewContext);

  const contents: any[] = [];
  for (const item of conversationHistory) {
    if (item.content && item.content.trim()) {
      contents.push({
        role: item.role === 'user' ? 'user' : 'model',
        parts: [{ text: item.content.trim() }],
      });
    }
  }

  contents.push({
    role: 'user',
    parts: [{ text: message.trim() }],
  });

  const candidateModels = ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash'];
  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const replyText = response.text?.trim();
      if (replyText) {
        return {
          reply: replyText,
          model_used: model,
          timestamp: new Date().toISOString(),
        };
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || '';

      // Check if project requires billing or free tier is disabled on this specific cloud project
      if (errMsg.includes('free tier is not available for this project') || errMsg.includes('set up billing')) {
        const billingErr: any = new Error(
          'Gemini API key is recognized, but this Google Cloud Project requires billing or free-tier activation. Please enable billing at https://aistudio.google.com/billing OR create a new key in a fresh project at https://aistudio.google.com/app/apikey (choose "Create API key in new project").'
        );
        billingErr.code = 'PROJECT_BILLING_REQUIRED';
        billingErr.statusCode = 403;
        throw billingErr;
      }

      if (errMsg.includes('API_KEY_INVALID') || err?.status === 401 || (err?.status === 403 && !errMsg.includes('billing') && !errMsg.includes('free tier'))) {
        const authErr: any = new Error('Invalid Gemini API Key. Please verify your GEMINI_API_KEY.');
        authErr.code = 'API_KEY_INVALID';
        authErr.statusCode = 401;
        throw authErr;
      }

      // If model not found (404), continue trying next available model in candidateModels
      if (err?.status === 404 || errMsg.includes('not found') || errMsg.includes('no longer available')) {
        continue;
      }
    }
  }

  throw lastError || new Error('Failed to generate AI mentor response.');
}

