export interface ServerQuestion {
  id: string;
  field: string;
  company?: string;
  question_text: string;
  question_type: string;
  difficulty: string;
  topic: string;
}

export const SERVER_QUESTION_BANK: ServerQuestion[] = [
  // FRONTEND
  {
    id: 'fe-001',
    field: 'Frontend / Web Development',
    company: 'General',
    question_text: 'Explain the CSS Box Model. How does box-sizing: border-box differ from content-box in layout calculations?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'HTML & CSS Basics',
  },
  {
    id: 'fe-002',
    field: 'Frontend / Web Development',
    company: 'TCS',
    question_text: 'What is semantic HTML, and why is it important for accessibility (a11y) and search engine optimization (SEO)?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'HTML & CSS Basics',
  },
  {
    id: 'fe-003',
    field: 'Frontend / Web Development',
    company: 'Infosys',
    question_text: 'Explain the difference between let, const, and var in JavaScript. What is variable hoisting and the temporal dead zone?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'JavaScript Fundamentals',
  },
  {
    id: 'fe-005',
    field: 'Frontend / Web Development',
    company: 'Meta',
    question_text: 'How does React reconciler (Fiber) determine when to re-render a component tree, and how do useMemo, useCallback, and React.memo prevent unnecessary renders?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'React & State Management',
  },
  {
    id: 'fe-007',
    field: 'Frontend / Web Development',
    company: 'Google',
    question_text: 'Explain the JavaScript Event Loop in detail. What is the execution order between synchronous code, microtasks (Promises, queueMicrotask), and macrotasks (setTimeout, requestAnimationFrame)?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'JavaScript Internals',
  },
  {
    id: 'fe-009',
    field: 'Frontend / Web Development',
    company: 'Meta',
    question_text: 'Design the frontend architecture for an infinite-scroll social media feed with variable-height cards, image preloading, virtualization, and offline optimistic updates.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Frontend System Design',
  },

  // BACKEND
  {
    id: 'be-001',
    field: 'Backend Development',
    company: 'TCS',
    question_text: 'Explain the core principles of Object-Oriented Programming (OOP): Encapsulation, Abstraction, Inheritance, and Polymorphism with practical backend examples.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'OOP & Fundamentals',
  },
  {
    id: 'be-002',
    field: 'Backend Development',
    company: 'Infosys',
    question_text: 'What are the main HTTP methods (GET, POST, PUT, PATCH, DELETE) and HTTP status codes (200, 201, 400, 401, 403, 404, 500)? When should you choose PUT over PATCH?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'REST APIs',
  },
  {
    id: 'be-004',
    field: 'Backend Development',
    company: 'Amazon',
    question_text: 'Explain database transaction isolation levels (Read Uncommitted, Read Committed, Repeatable Read, Serializable). What are dirty reads, non-repeatable reads, and phantom reads?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Databases & ACID',
  },
  {
    id: 'be-006',
    field: 'Backend Development',
    company: 'Google',
    question_text: 'Describe distributed caching strategies using Redis (Cache-Aside, Write-Through, Write-Behind). How do you handle cache invalidation, cache stampede (thundering herd), and cache penetration?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Distributed Caching',
  },
  {
    id: 'be-008',
    field: 'Backend Development',
    company: 'Amazon',
    question_text: 'Design a distributed rate limiter that handles 100,000 requests per second across a global multi-region server cluster. Compare Token Bucket, Leaky Bucket, and Sliding Window Counter algorithms.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Distributed Systems Design',
  },

  // FULL STACK & CORE CS
  {
    id: 'fs-003',
    field: 'Full Stack Development',
    company: 'Microsoft',
    question_text: 'How do you secure user authentication across a Single Page App (SPA) and backend REST API? Compare HTTP-only SameSite cookies vs LocalStorage JWTs in terms of XSS and CSRF vulnerabilities.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Auth & Security',
  },
  {
    id: 'cs-001',
    field: 'Core Computer Science & DSA',
    company: 'TCS',
    question_text: 'Compare an Array with a Singly Linked List in memory representation. What are their respective time and space complexities for insertion at beginning, middle, and lookup by index?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Data Structures Basics',
  },
  {
    id: 'cs-004',
    field: 'Core Computer Science & DSA',
    company: 'Google',
    question_text: 'Explain Breadth-First Search (BFS) versus Depth-First Search (DFS) on graphs. In what problem domains (shortest path, topological sort, cycle detection) is one strictly preferred over the other?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Graph Algorithms',
  },
];
