-- InterviewIQ: Supabase PostgreSQL Schema & Seed Data
-- Run this script in your Supabase SQL Editor

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- PROFILES
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE,
  avatar_url TEXT,
  cgpa NUMERIC(4, 2),
  target_role TEXT,
  interested_fields TEXT[],
  skills TEXT[],
  preferred_companies TEXT[],
  bio TEXT,
  is_profile_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- JOB ROLES
CREATE TABLE IF NOT EXISTS job_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  category TEXT,
  difficulty TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- QUESTIONS
CREATE TABLE IF NOT EXISTS questions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  role_id UUID REFERENCES job_roles(id) ON DELETE SET NULL,
  field TEXT NOT NULL DEFAULT 'Core Computer Science',
  company TEXT DEFAULT 'General',
  question_text TEXT NOT NULL,
  question_type TEXT DEFAULT 'Technical',
  difficulty TEXT DEFAULT 'Medium',
  topic TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- INTERVIEWS
CREATE TABLE IF NOT EXISTS interviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  role_id UUID REFERENCES job_roles(id) ON DELETE SET NULL,
  field TEXT DEFAULT 'All',
  company TEXT DEFAULT 'All',
  difficulty TEXT DEFAULT 'Scaling',
  status TEXT CHECK (status IN ('in_progress', 'completed', 'cancelled')) DEFAULT 'in_progress',
  started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE,
  total_questions INT DEFAULT 3,
  overall_score INT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- INTERVIEW QUESTIONS
CREATE TABLE IF NOT EXISTS interview_questions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  interview_id UUID REFERENCES interviews(id) ON DELETE CASCADE,
  question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
  sequence_number INT
);

-- ANSWERS
CREATE TABLE IF NOT EXISTS answers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  interview_id UUID REFERENCES interviews(id) ON DELETE CASCADE,
  question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  answer_text TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- EVALUATIONS
CREATE TABLE IF NOT EXISTS evaluations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  answer_id UUID REFERENCES answers(id) ON DELETE CASCADE,
  relevance_score INT,
  clarity_score INT,
  content_score INT,
  technical_score INT,
  communication_score INT,
  overall_score INT,
  strengths TEXT[],
  weaknesses TEXT[],
  suggestions TEXT[],
  feedback TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- PERFORMANCE HISTORY
CREATE TABLE IF NOT EXISTS performance_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  interview_id UUID REFERENCES interviews(id) ON DELETE SET NULL,
  role_id UUID REFERENCES job_roles(id) ON DELETE SET NULL,
  field TEXT,
  company TEXT,
  score INT,
  completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_interviews_user ON interviews(user_id);
CREATE INDEX IF NOT EXISTS idx_answers_interview ON answers(interview_id);
CREATE INDEX IF NOT EXISTS idx_questions_field ON questions(field);
CREATE INDEX IF NOT EXISTS idx_questions_company ON questions(company);
CREATE INDEX IF NOT EXISTS idx_evaluations_answer ON evaluations(answer_id);

-- ENABLE ROW LEVEL SECURITY
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE interview_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluations ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_history ENABLE ROW LEVEL SECURITY;

-- RLS POLICIES
CREATE POLICY "Allow public read for job roles" ON job_roles FOR SELECT USING (true);
CREATE POLICY "Allow public read for questions" ON questions FOR SELECT USING (true);

CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users manage own interviews" ON interviews FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users manage own answers" ON answers FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users view own evaluations" ON evaluations FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM answers
    WHERE answers.id = evaluations.answer_id
    AND answers.user_id = auth.uid()
  )
);

CREATE POLICY "Users insert own evaluations" ON evaluations FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM answers
    WHERE answers.id = evaluations.answer_id
    AND answers.user_id = auth.uid()
  )
);

CREATE POLICY "Users view own performance" ON performance_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own performance" ON performance_history FOR INSERT WITH CHECK (auth.uid() = user_id);

-- AUTO PROFILE CREATION TRIGGER ON SIGNUP
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, email, is_profile_completed)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Candidate'),
    NEW.email,
    false
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();
