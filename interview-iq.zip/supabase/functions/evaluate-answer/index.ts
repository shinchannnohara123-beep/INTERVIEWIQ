// Supabase Edge Function: evaluate-answer
// Deploy with: supabase functions deploy evaluate-answer
// Set the secret with: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
//
// This function is the ONLY place the AI API key is used — it never
// reaches the browser. The client calls this function via
// supabase.functions.invoke('evaluate-answer', { body: {...} }).

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface RequestBody {
  answer_id: string
  question_text: string
  answer_text: string
  role_name: string
  difficulty: string
}

interface EvaluationResult {
  relevance_score: number
  clarity_score: number
  content_score: number
  technical_score: number
  communication_score: number
  overall_score: number
  strengths: string[]
  weaknesses: string[]
  suggestions: string[]
  feedback: string
}

const EVALUATION_SYSTEM_PROMPT = `You are an expert technical interviewer evaluating a candidate's spoken/written interview answer.

Score strictly based on the ACTUAL content of the answer provided — never assume information the candidate did not state, and never give generic or templated feedback. If the answer is empty, off-topic, or extremely thin, scores must reflect that honestly (low scores), and you must say why in "feedback".

Return ONLY valid JSON (no markdown fences, no preamble, no trailing text) matching exactly this shape:
{
  "relevance_score": <0-100 integer, how directly the answer addresses the question asked>,
  "clarity_score": <0-100 integer, structure and ease of understanding>,
  "content_score": <0-100 integer, depth and correctness of the substance>,
  "technical_score": <0-100 integer, technical accuracy where applicable; if the question is purely behavioral, judge soundness of reasoning instead>,
  "communication_score": <0-100 integer, tone, confidence, and articulation>,
  "overall_score": <0-100 integer, your holistic weighted judgment — not necessarily a plain average>,
  "strengths": [<2-4 short specific strings, each citing something the candidate actually said or did well>],
  "weaknesses": [<2-4 short specific strings, each citing something concretely missing or weak in THIS answer>],
  "suggestions": [<2-4 short specific, actionable strings for how to improve THIS answer>],
  "feedback": <2-4 sentence string explaining WHY the overall_score was given, referencing specifics from the answer>
}`

// Model id below is current as of writing — check
// https://docs.claude.com/en/docs/about-claude/models for the latest
// available model strings before deploying.
async function callAnthropic(body: RequestBody): Promise<EvaluationResult> {
  const apiKey = Deno.env.get('ANTHROPIC_API_KEY')
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY secret is not set on this function')

  const userPrompt = `Role being interviewed for: ${body.role_name} (difficulty: ${body.difficulty})

Question asked:
"""${body.question_text}"""

Candidate's answer:
"""${body.answer_text}"""

Evaluate this answer now and return only the JSON object described in your instructions.`

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-5',
      max_tokens: 1024,
      system: EVALUATION_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userPrompt }],
    }),
  })

  if (!response.ok) {
    const errText = await response.text()
    throw new Error(`Anthropic API error (${response.status}): ${errText}`)
  }

  const data = await response.json()
  const textBlock = (data.content ?? []).find((b: { type: string }) => b.type === 'text')
  if (!textBlock) throw new Error('No text content returned from model')

  const cleaned = textBlock.text.replace(/```json|```/g, '').trim()
  const parsed = JSON.parse(cleaned) as EvaluationResult

  // Clamp scores defensively in case the model drifts outside range
  const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)))
  return {
    relevance_score: clamp(parsed.relevance_score),
    clarity_score: clamp(parsed.clarity_score),
    content_score: clamp(parsed.content_score),
    technical_score: clamp(parsed.technical_score),
    communication_score: clamp(parsed.communication_score),
    overall_score: clamp(parsed.overall_score),
    strengths: parsed.strengths ?? [],
    weaknesses: parsed.weaknesses ?? [],
    suggestions: parsed.suggestions ?? [],
    feedback: parsed.feedback ?? '',
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Missing Authorization header' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Verify the caller is a real authenticated user before spending AI credits.
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: userData, error: userError } = await supabaseClient.auth.getUser()
    if (userError || !userData?.user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const body = (await req.json()) as RequestBody
    if (!body.answer_text || body.answer_text.trim().length === 0) {
      return new Response(JSON.stringify({ error: 'answer_text is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const evaluation = await callAnthropic(body)

    // Persist the evaluation server-side using the service role, then
    // return it. This keeps evaluations tamper-proof from the client.
    const serviceClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )
    const { data: inserted, error: insertError } = await serviceClient
      .from('evaluations')
      .insert({
        answer_id: body.answer_id,
        relevance_score: evaluation.relevance_score,
        clarity_score: evaluation.clarity_score,
        content_score: evaluation.content_score,
        technical_score: evaluation.technical_score,
        communication_score: evaluation.communication_score,
        overall_score: evaluation.overall_score,
        strengths: evaluation.strengths,
        weaknesses: evaluation.weaknesses,
        suggestions: evaluation.suggestions,
        feedback: evaluation.feedback,
      })
      .select()
      .single()

    if (insertError) throw insertError

    return new Response(JSON.stringify({ evaluation: inserted }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
