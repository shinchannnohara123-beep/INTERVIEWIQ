import { Question, QuestionFilters } from '../types/database.types';

export const COMPREHENSIVE_QUESTION_BANK: Question[] = [
  // ==========================================
  // FRONTEND / WEB DEVELOPMENT
  // ==========================================
  // Easy / Basics
  {
    id: 'fe-001',
    field: 'Frontend / Web Development',
    company: 'General',
    question_text: 'Explain the CSS Box Model. How does box-sizing: border-box differ from content-box in layout calculations?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'HTML & CSS Basics',
  },
  {
    id: 'fe-002',
    field: 'Frontend / Web Development',
    company: 'TCS',
    question_text: 'What is semantic HTML, and why is it important for accessibility (a11y) and search engine optimization (SEO)?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'HTML & CSS Basics',
  },
  {
    id: 'fe-003',
    field: 'Frontend / Web Development',
    company: 'Infosys',
    question_text: 'Explain the difference between let, const, and var in JavaScript. What is variable hoisting and the temporal dead zone?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'JavaScript Fundamentals',
  },
  {
    id: 'fe-004',
    field: 'Frontend / Web Development',
    company: 'General',
    question_text: 'What are JavaScript closures, and how can you use them to create private state or factory functions?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'JavaScript Fundamentals',
  },
  // Medium / Core
  {
    id: 'fe-005',
    field: 'Frontend / Web Development',
    company: 'Meta',
    question_text: 'How does React reconciler (Fiber) determine when to re-render a component tree, and how do useMemo, useCallback, and React.memo prevent unnecessary renders?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'React & State Management',
  },
  {
    id: 'fe-006',
    field: 'Frontend / Web Development',
    company: 'Microsoft',
    question_text: 'Compare Client-Side Rendering (CSR), Server-Side Rendering (SSR), and Static Site Generation (SSG). How do hydration and streaming SSR work in modern frameworks?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Web Architecture',
  },
  {
    id: 'fe-007',
    field: 'Frontend / Web Development',
    company: 'Google',
    question_text: 'Explain the JavaScript Event Loop in detail. What is the execution order between synchronous code, microtasks (Promises, queueMicrotask), and macrotasks (setTimeout, requestAnimationFrame)?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'JavaScript Internals',
  },
  {
    id: 'fe-008',
    field: 'Frontend / Web Development',
    company: 'Amazon',
    question_text: 'How do you measure and optimize Core Web Vitals (Largest Contentful Paint, Interaction to Next Paint, Cumulative Layout Shift) on high-traffic retail pages?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Web Performance',
  },
  // Hard / Advanced
  {
    id: 'fe-009',
    field: 'Frontend / Web Development',
    company: 'Meta',
    question_text: 'Design the frontend architecture for an infinite-scroll social media feed with variable-height cards, image preloading, virtualization, and offline optimistic updates.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Frontend System Design',
  },
  {
    id: 'fe-010',
    field: 'Frontend / Web Development',
    company: 'Google',
    question_text: 'How would you build a real-time collaborative rich-text editor in the browser? Compare Operational Transformation (OT) vs CRDTs (Conflict-free Replicated Data Types) for state synchronization.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Real-time Web & Concurrency',
  },

  // ==========================================
  // BACKEND DEVELOPMENT
  // ==========================================
  // Easy / Basics
  {
    id: 'be-001',
    field: 'Backend Development',
    company: 'TCS',
    question_text: 'Explain the core principles of Object-Oriented Programming (OOP): Encapsulation, Abstraction, Inheritance, and Polymorphism with practical backend examples.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'OOP & Fundamentals',
  },
  {
    id: 'be-002',
    field: 'Backend Development',
    company: 'Infosys',
    question_text: 'What are the main HTTP methods (GET, POST, PUT, PATCH, DELETE) and HTTP status codes (200, 201, 400, 401, 403, 404, 500)? When should you choose PUT over PATCH?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'REST APIs',
  },
  {
    id: 'be-003',
    field: 'Backend Development',
    company: 'General',
    question_text: 'What are database indexes, and how does a B-Tree index speed up SELECT queries? What are the tradeoffs when performing INSERT and UPDATE operations?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Databases & SQL',
  },
  // Medium / Core
  {
    id: 'be-004',
    field: 'Backend Development',
    company: 'Amazon',
    question_text: 'Explain database transaction isolation levels (Read Uncommitted, Read Committed, Repeatable Read, Serializable). What are dirty reads, non-repeatable reads, and phantom reads?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Databases & ACID',
  },
  {
    id: 'be-005',
    field: 'Backend Development',
    company: 'Microsoft',
    question_text: 'How do you design an idempotent API for payment or order checkout? How do you prevent double-charging during network retries or client timeout disconnects?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'API Design & Idempotency',
  },
  {
    id: 'be-006',
    field: 'Backend Development',
    company: 'Google',
    question_text: 'Describe distributed caching strategies using Redis (Cache-Aside, Write-Through, Write-Behind). How do you handle cache invalidation, cache stampede (thundering herd), and cache penetration?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Distributed Caching',
  },
  {
    id: 'be-007',
    field: 'Backend Development',
    company: 'Netflix',
    question_text: 'How does asynchronous message queuing (e.g., Kafka, RabbitMQ, SQS) decouple microservices? Compare at-least-once vs at-most-once vs exactly-once delivery guarantees.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Message Queues & Event-Driven',
  },
  // Hard / Advanced
  {
    id: 'be-008',
    field: 'Backend Development',
    company: 'Amazon',
    question_text: 'Design a distributed rate limiter that handles 100,000 requests per second across a global multi-region server cluster. Compare Token Bucket, Leaky Bucket, and Sliding Window Counter algorithms.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Distributed Systems Design',
  },
  {
    id: 'be-009',
    field: 'Backend Development',
    company: 'Google',
    question_text: 'Design a globally distributed URL shortening service (like Bitly). Detail schema design, base62 hash collision resolution, database partitioning/sharding, and 99.99% read latency optimization.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'System Design',
  },
  {
    id: 'be-010',
    field: 'Backend Development',
    company: 'Netflix',
    question_text: 'How do you handle distributed transactions across microservices? Explain the 2-Phase Commit (2PC) protocol versus the Saga Pattern (orchestration vs choreography) with compensating actions.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Distributed Transactions',
  },

  // ==========================================
  // FULL STACK DEVELOPMENT
  // ==========================================
  {
    id: 'fs-001',
    field: 'Full Stack Development',
    company: 'Infosys',
    question_text: 'Explain the client-server request/response cycle from the moment a user types a URL into a browser until the page is fully rendered.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Web Fundamentals',
  },
  {
    id: 'fs-002',
    field: 'Full Stack Development',
    company: 'TCS',
    question_text: 'Compare SQL (Relational) vs NoSQL (Document/Key-Value) databases. In what full-stack application scenarios would you choose MongoDB vs PostgreSQL?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Database Selection',
  },
  {
    id: 'fs-003',
    field: 'Full Stack Development',
    company: 'Microsoft',
    question_text: 'How do you secure user authentication across a Single Page App (SPA) and backend REST API? Compare HTTP-only SameSite cookies vs LocalStorage JWTs in terms of XSS and CSRF vulnerabilities.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Auth & Security',
  },
  {
    id: 'fs-004',
    field: 'Full Stack Development',
    company: 'Amazon',
    question_text: 'How do you manage file uploads of large video or image files from the browser to cloud object storage (S3)? Explain presigned URLs and multipart upload architecture.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Cloud Storage & File Handling',
  },
  {
    id: 'fs-005',
    field: 'Full Stack Development',
    company: 'Google',
    question_text: 'Design an end-to-end real-time collaborative document platform (like Google Docs). Address client synchronization, server conflict resolution, offline editing, and presence tracking.',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Full Stack Architecture',
  },

  // ==========================================
  // DATA SCIENCE & ANALYTICS
  // ==========================================
  {
    id: 'ds-001',
    field: 'Data Science & Analytics',
    company: 'TCS',
    question_text: 'Explain the difference between supervised, unsupervised, and reinforcement learning. Give one practical business example for each.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Machine Learning Basics',
  },
  {
    id: 'ds-002',
    field: 'Data Science & Analytics',
    company: 'Infosys',
    question_text: 'How do you handle missing values and outliers in a structured tabular dataset before training a model? Compare imputation strategies.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Data Preprocessing',
  },
  {
    id: 'ds-003',
    field: 'Data Science & Analytics',
    company: 'Google',
    question_text: 'Explain the Bias-Variance Tradeoff. How do L1 (Lasso) and L2 (Ridge) regularization help prevent overfitting in regression and classification models?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Statistical Modeling',
  },
  {
    id: 'ds-004',
    field: 'Data Science & Analytics',
    company: 'Amazon',
    question_text: 'When evaluating an imbalanced classification dataset (e.g. 99% negative, 1% fraudulent), why is Accuracy a misleading metric? Compare Precision, Recall, F1-Score, and ROC-AUC.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Model Evaluation Metrics',
  },
  {
    id: 'ds-005',
    field: 'Data Science & Analytics',
    company: 'Netflix',
    question_text: 'Design an A/B testing framework for evaluating recommendation algorithm improvements. How do you calculate sample size, avoid p-hacking, and detect spillover effects?',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Experimental Design & A/B Testing',
  },

  // ==========================================
  // AI / MACHINE LEARNING
  // ==========================================
  {
    id: 'ai-001',
    field: 'AI / Machine Learning',
    company: 'Infosys',
    question_text: 'What is gradient descent, and how does backpropagation update weights in a multi-layer neural network?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Neural Networks Basics',
  },
  {
    id: 'ai-002',
    field: 'AI / Machine Learning',
    company: 'Microsoft',
    question_text: 'Explain the Transformer architecture mechanism. How does Scaled Dot-Product Self-Attention enable models to capture long-range contextual dependencies compared to RNNs?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Deep Learning & Transformers',
  },
  {
    id: 'ai-003',
    field: 'AI / Machine Learning',
    company: 'Google',
    question_text: 'What is Retrieval-Augmented Generation (RAG)? Explain chunking strategies, vector embeddings, cosine similarity search, and reranking in modern enterprise LLM pipelines.',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'LLMs & Generative AI',
  },
  {
    id: 'ai-004',
    field: 'AI / Machine Learning',
    company: 'Amazon',
    question_text: 'How do you detect and mitigate Data Drift and Concept Drift in production ML models? Outline a continuous monitoring and automated retraining pipeline.',
    question_type: 'Technical',
    difficulty: 'Hard',
    topic: 'MLOps & Production AI',
  },
  {
    id: 'ai-005',
    field: 'AI / Machine Learning',
    company: 'Meta',
    question_text: 'Design a scalable multi-modal recommendation engine that predicts user engagement over billions of candidate items in under 50ms latency using two-stage retrieval (candidate generation + ranking).',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Recommendation Systems',
  },

  // ==========================================
  // DEVOPS & CLOUD INFRASTRUCTURE
  // ==========================================
  {
    id: 'do-001',
    field: 'DevOps & Cloud Infrastructure',
    company: 'TCS',
    question_text: 'What is Continuous Integration and Continuous Deployment (CI/CD)? What automated checks should run before merging code to the main production branch?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'CI/CD Foundations',
  },
  {
    id: 'do-002',
    field: 'DevOps & Cloud Infrastructure',
    company: 'Infosys',
    question_text: 'Explain the difference between a Virtual Machine (VM) and a Docker container. What is container image layering and how do you minimize Docker image sizes?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Containerization Basics',
  },
  {
    id: 'do-003',
    field: 'DevOps & Cloud Infrastructure',
    company: 'Amazon',
    question_text: 'In Kubernetes, explain the differences between Pods, ReplicaSets, Deployments, StatefulSets, and Services (ClusterIP vs NodePort vs LoadBalancer).',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Kubernetes Orchestration',
  },
  {
    id: 'do-004',
    field: 'DevOps & Cloud Infrastructure',
    company: 'Google',
    question_text: 'Compare Blue-Green deployments, Canary deployments, and Rolling updates. How do you design an automated health check and rollback strategy if error rates spike?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Deployment Strategies',
  },
  {
    id: 'do-005',
    field: 'DevOps & Cloud Infrastructure',
    company: 'Netflix',
    question_text: 'Design a multi-region disaster recovery and high-availability architecture on cloud infrastructure with zero data loss (RPO = 0) and under 5 minutes downtime (RTO < 5m).',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Cloud Reliability & Chaos Eng',
  },

  // ==========================================
  // CORE COMPUTER SCIENCE & DSA
  // ==========================================
  {
    id: 'cs-001',
    field: 'Core Computer Science & DSA',
    company: 'TCS',
    question_text: 'Compare an Array with a Singly Linked List in memory representation. What are their respective time and space complexities for insertion at beginning, middle, and lookup by index?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Data Structures Basics',
  },
  {
    id: 'cs-002',
    field: 'Core Computer Science & DSA',
    company: 'Infosys',
    question_text: 'Explain the difference between a Stack and a Queue. How do you implement a Queue using two Stacks?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Data Structures Basics',
  },
  {
    id: 'cs-003',
    field: 'Core Computer Science & DSA',
    company: 'Microsoft',
    question_text: 'Explain how Hash Tables handle key collisions. Compare Separate Chaining (Linked Lists/Red-Black Trees) with Open Addressing (Linear Probing, Double Hashing).',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Hashing & Internals',
  },
  {
    id: 'cs-004',
    field: 'Core Computer Science & DSA',
    company: 'Google',
    question_text: 'Explain Breadth-First Search (BFS) versus Depth-First Search (DFS) on graphs. In what problem domains (shortest path, topological sort, cycle detection) is one strictly preferred over the other?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Graph Algorithms',
  },
  {
    id: 'cs-005',
    field: 'Core Computer Science & DSA',
    company: 'Amazon',
    question_text: 'Explain the principles of Dynamic Programming. Compare top-down memoization with bottom-up tabulation. How do you recognize overlapping subproblems and optimal substructure?',
    question_type: 'Technical',
    difficulty: 'Hard',
    topic: 'Dynamic Programming',
  },

  // ==========================================
  // COMPANY SPECIFIC BEHAVIORAL & SCENARIO
  // ==========================================
  {
    id: 'comp-amz-001',
    field: 'Full Stack Development',
    company: 'Amazon',
    question_text: 'Amazon Leadership Principle (Customer Obsession): Tell me about a time when you had to push back on a feature requirement or deadline because it compromised the customer experience.',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Leadership & Decision Making',
  },
  {
    id: 'comp-goog-001',
    field: 'Backend Development',
    company: 'Google',
    question_text: 'Google Engineering Culture: Describe a complex technical failure or production outage you caused or diagnosed. How did you conduct the blameless post-mortem and what preventative safeguards were implemented?',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Incident Management & Safeguards',
  },
  {
    id: 'comp-tcs-001',
    field: 'Core Computer Science & DSA',
    company: 'TCS',
    question_text: 'What are database normalization normal forms (1NF, 2NF, 3NF, BCNF)? Why do enterprise applications sometimes intentionally denormalize database tables in read-heavy production?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'Database Normalization',
  },
  {
    id: 'comp-infy-001',
    field: 'Backend Development',
    company: 'Infosys',
    question_text: 'Explain the Software Development Life Cycle (SDLC) models. Compare the traditional Waterfall approach with Agile Scrum methodologies in project delivery.',
    question_type: 'Conceptual',
    difficulty: 'Easy',
    topic: 'SDLC & Agile Workflows',
  },
  {
    id: 'comp-wipro-001',
    field: 'Full Stack Development',
    company: 'Wipro',
    question_text: 'What are the main principles of Object-Oriented Programming (Encapsulation, Inheritance, Polymorphism, Abstraction)? Provide a practical example of polymorphism in code.',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'OOP Concepts',
  },
  {
    id: 'comp-wipro-002',
    field: 'Backend Development',
    company: 'Wipro',
    question_text: 'Explain the difference between Synchronous and Asynchronous execution. How does the JavaScript Event Loop handle microtasks vs macrotasks?',
    question_type: 'Technical',
    difficulty: 'Medium',
    topic: 'Async Programming',
  },
  {
    id: 'comp-wipro-003',
    field: 'Core Computer Science & DSA',
    company: 'Wipro',
    question_text: 'What is a Primary Key vs Foreign Key in relational databases? How do referential integrity constraints prevent orphaned records?',
    question_type: 'Technical',
    difficulty: 'Easy',
    topic: 'RDBMS Constraints',
  },
  {
    id: 'comp-custom-001',
    field: 'Full Stack Development',
    company: 'Custom',
    question_text: 'Walk me through an end-to-end user authentication flow. How do you store JWT tokens securely on the client, and how do you handle token expiration and refresh?',
    question_type: 'System Design',
    difficulty: 'Medium',
    topic: 'Auth & Security',
  },
  {
    id: 'comp-custom-002',
    field: 'Backend Development',
    company: 'Custom',
    question_text: 'How do you design a database schema to handle high-frequency writes while maintaining fast analytical read queries? What trade-offs do you consider?',
    question_type: 'System Design',
    difficulty: 'Hard',
    topic: 'Database Architecture',
  },

  // ==========================================
  // HR & FITMENT QUESTIONS (REAL-WORLD)
  // ==========================================
  {
    id: 'hr-gen-001',
    field: 'All',
    company: 'General',
    question_text: 'Tell me about yourself, your educational background, and what inspired you to pursue a career in software engineering.',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Personal Introduction',
  },
  {
    id: 'hr-gen-002',
    field: 'All',
    company: 'General',
    question_text: 'Why are you interested in joining our company, and how do your technical interests and career aspirations align with our mission?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Company Fit & Motivation',
  },
  {
    id: 'hr-gen-003',
    field: 'All',
    company: 'General',
    question_text: 'Where do you see yourself in 3 to 5 years, and what specific technical and architectural competencies are you actively developing to achieve that vision?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Career Vision & Goals',
  },
  {
    id: 'hr-gen-004',
    field: 'All',
    company: 'General',
    question_text: 'What is your greatest technical strength, and what is one area or weakness you are actively trying to improve upon?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Self-Awareness & Growth',
  },
  {
    id: 'hr-gen-005',
    field: 'All',
    company: 'General',
    question_text: 'How do you handle working on technologies or tasks outside your immediate comfort zone when faced with tight delivery deadlines?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Adaptability & Learning',
  },
  {
    id: 'hr-tcs-001',
    field: 'All',
    company: 'TCS',
    question_text: 'TCS HR: How comfortable are you with adapting to enterprise client environments, rotating shifts, or learning new proprietary technology stacks based on client demands?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Flexibility & Enterprise Delivery',
  },
  {
    id: 'hr-infy-001',
    field: 'All',
    company: 'Infosys',
    question_text: 'Infosys HR: In a rapidly changing software landscape, how do you continuously upskill yourself, and how have you applied self-learning in your academic or personal projects?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Continuous Learning & Growth',
  },
  {
    id: 'hr-wipro-001',
    field: 'All',
    company: 'Wipro',
    question_text: 'Wipro HR: Walk me through a challenging academic project milestone where things went wrong. How did you maintain composure and deliver the solution?',
    question_type: 'HR',
    difficulty: 'Easy',
    topic: 'Resilience & Problem Solving',
  },
  {
    id: 'hr-goog-001',
    field: 'All',
    company: 'Google',
    question_text: 'Google Culture (Googleyness): Describe a time when you saw an opportunity to improve a team process or help a struggling peer without being explicitly directed to do so.',
    question_type: 'HR',
    difficulty: 'Medium',
    topic: 'Googleyness & Initiative',
  },
  {
    id: 'hr-amz-001',
    field: 'All',
    company: 'Amazon',
    question_text: 'Amazon Leadership Principle (Earn Trust): Tell me about a time when you made a misjudgment or error in a project. How did you communicate the mistake transparently and remediate the impact?',
    question_type: 'HR',
    difficulty: 'Medium',
    topic: 'Earn Trust & Accountability',
  },

  // ==========================================
  // BEHAVIORAL QUESTIONS (STAR METHOD REAL SCENARIOS)
  // ==========================================
  {
    id: 'beh-gen-001',
    field: 'All',
    company: 'General',
    question_text: 'Describe a technical disagreement you had with a team member or mentor regarding design or code architecture. How did you navigate the conversation and reach consensus?',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Conflict Resolution & Teamwork',
  },
  {
    id: 'beh-gen-002',
    field: 'All',
    company: 'General',
    question_text: 'Tell me about a time when you faced tight, competing project deadlines with ambiguous requirements. How did you prioritize tasks and communicate expectations?',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Time Management & Prioritization',
  },
  {
    id: 'beh-gen-003',
    field: 'All',
    company: 'General',
    question_text: 'Walk me through a project failure or a production bug that escaped testing. What was the root cause, how did you fix it, and what systemic prevention did you implement?',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Blameless Post-Mortem & Ownership',
  },
  {
    id: 'beh-gen-004',
    field: 'All',
    company: 'General',
    question_text: 'Describe an instance where you had to explain a complex engineering architecture or data concept to a non-technical stakeholder or client.',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Stakeholder Communication',
  },
  {
    id: 'beh-gen-005',
    field: 'All',
    company: 'General',
    question_text: 'Tell me about a time when you proactively identified a performance bottleneck or security vulnerability in a codebase and resolved it before it became a crisis.',
    question_type: 'Behavioral',
    difficulty: 'Hard',
    topic: 'Proactivity & Engineering Craft',
  },
  {
    id: 'beh-goog-001',
    field: 'All',
    company: 'Google',
    question_text: 'Google Behavioral: Tell me about a project where you had to make critical architectural decisions in the face of incomplete requirements or high ambiguity. What framework did you use?',
    question_type: 'Behavioral',
    difficulty: 'Hard',
    topic: 'Navigating Ambiguity',
  },
  {
    id: 'beh-amz-002',
    field: 'All',
    company: 'Amazon',
    question_text: 'Amazon Leadership Principle (Bias for Action): Describe a situation where you had to make a swift decision with calculated risk and limited data instead of waiting for extensive analysis.',
    question_type: 'Behavioral',
    difficulty: 'Medium',
    topic: 'Bias for Action',
  },
  {
    id: 'beh-tcs-002',
    field: 'All',
    company: 'TCS',
    question_text: 'TCS Behavioral: Describe how you manage quality standards and attention to detail when working under repetitive or high-pressure delivery cycles.',
    question_type: 'Behavioral',
    difficulty: 'Easy',
    topic: 'Quality & Consistency',
  },
  {
    id: 'beh-infy-002',
    field: 'All',
    company: 'Infosys',
    question_text: 'Infosys Behavioral: Describe a scenario where you received critical constructive feedback on your code or documentation. How did you internalize and apply it to subsequent sprints?',
    question_type: 'Behavioral',
    difficulty: 'Easy',
    topic: 'Receptivity to Feedback',
  },
  {
    id: 'beh-wipro-002',
    field: 'All',
    company: 'Wipro',
    question_text: 'Wipro Behavioral: Tell me about a time you had to collaborate with team members who had conflicting working styles or different technical proficiencies.',
    question_type: 'Behavioral',
    difficulty: 'Easy',
    topic: 'Collaboration & Empathy',
  },
];

/**
 * Smart Question Engine:
 * - Dynamic generation based on Field, Company, and Difficulty
 * - Balanced interview mix: Technical (core role & architecture) + HR (motivation/fit) + Behavioral (STAR)
 * - Zero repeated questions: strictly excludes the last 10 asked questions
 * - Company-targeted questions (Google, Amazon, TCS, Infosys, Wipro, etc.)
 * - Randomized & shuffled every session for different questions
 */
export function generateDynamicQuestions(filters: QuestionFilters): Question[] {
  const {
    field = 'All',
    company = 'All',
    difficulty = 'Scaling',
    totalQuestions = 3,
    excludeIds = [],
  } = filters;

  // 1. Filter out strictly excluded questions (the user's last 10 questions)
  let eligiblePool = COMPREHENSIVE_QUESTION_BANK.filter(q => !excludeIds.includes(q.id));

  // If exclusions leave fewer questions than needed, fallback to entire bank
  if (eligiblePool.length < totalQuestions) {
    eligiblePool = [...COMPREHENSIVE_QUESTION_BANK];
  }

  // Helper to shuffle an array
  const shuffle = <T>(arr: T[]): T[] => {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  };

  // Helper to pick candidates with company boosting
  const pickFromCategory = (
    categoryType: 'Technical' | 'HR' | 'Behavioral',
    specificField = 'All',
    targetDifficulty?: string
  ): Question | null => {
    let subset = eligiblePool.filter(q => {
      if (categoryType === 'Technical') {
        return q.question_type === 'Technical' || q.question_type === 'System Design' || q.question_type === 'Conceptual';
      }
      return q.question_type === categoryType;
    });

    if (subset.length === 0) {
      subset = COMPREHENSIVE_QUESTION_BANK.filter(q => {
        if (categoryType === 'Technical') {
          return q.question_type === 'Technical' || q.question_type === 'System Design';
        }
        return q.question_type === categoryType;
      });
    }

    // Filter by field for technical questions
    if (categoryType === 'Technical' && specificField !== 'All') {
      const fieldMatched = subset.filter(q => q.field.toLowerCase().includes(specificField.toLowerCase()));
      if (fieldMatched.length > 0) subset = fieldMatched;
    }

    // Company preference
    if (company !== 'All') {
      const companyMatched = subset.filter(q => q.company && q.company.toLowerCase() === company.toLowerCase());
      if (companyMatched.length > 0) {
        // 75% chance to prioritize company specific question if available
        if (Math.random() < 0.75) {
          subset = companyMatched;
        }
      }
    }

    // Difficulty filter if specified and available
    if (targetDifficulty && targetDifficulty !== 'Scaling' && targetDifficulty !== 'All') {
      const diffMatched = subset.filter(q => q.difficulty.toLowerCase() === targetDifficulty.toLowerCase());
      if (diffMatched.length > 0) subset = diffMatched;
    }

    const shuffled = shuffle(subset);
    const chosen = shuffled[0] || null;
    if (chosen) {
      eligiblePool = eligiblePool.filter(q => q.id !== chosen.id);
    }
    return chosen;
  };

  const selectedQuestions: Question[] = [];

  // Determine how many Technical, HR, and Behavioral questions to select
  let hrCount = 0;
  let behavioralCount = 0;
  let technicalCount = totalQuestions;

  if (totalQuestions >= 3) {
    hrCount = 1;
    behavioralCount = 1;
    technicalCount = totalQuestions - 2;
  } else if (totalQuestions === 2) {
    technicalCount = 1;
    behavioralCount = 1;
  }

  // 1. Pick Technical Questions (with difficulty scaling: Easy -> Medium -> Hard)
  const diffSequence = ['Easy', 'Medium', 'Hard'];
  for (let i = 0; i < technicalCount; i++) {
    const targetDiff = difficulty === 'Scaling' || difficulty === 'All'
      ? diffSequence[Math.min(i, diffSequence.length - 1)]
      : difficulty;

    const q = pickFromCategory('Technical', field, targetDiff);
    if (q) selectedQuestions.push(q);
  }

  // 2. Pick Behavioral Question (STAR scenario)
  for (let i = 0; i < behavioralCount; i++) {
    const q = pickFromCategory('Behavioral', 'All', difficulty === 'Easy' ? 'Easy' : 'Medium');
    if (q) selectedQuestions.push(q);
  }

  // 3. Pick HR Question (Motivation, fit, goals)
  for (let i = 0; i < hrCount; i++) {
    const q = pickFromCategory('HR', 'All', 'Easy');
    if (q) selectedQuestions.push(q);
  }

  // Fill up if any were missed
  while (selectedQuestions.length < totalQuestions && eligiblePool.length > 0) {
    const candidate = shuffle(eligiblePool)[0];
    if (candidate) {
      selectedQuestions.push(candidate);
      eligiblePool = eligiblePool.filter(q => q.id !== candidate.id);
    }
  }

  return selectedQuestions;
}

function pickRandom<T>(arr: T[]): T | null {
  if (!arr || arr.length === 0) return null;
  const index = Math.floor(Math.random() * arr.length);
  return arr[index];
}

export const AVAILABLE_FIELDS = [
  'All',
  'Frontend / Web Development',
  'Backend Development',
  'Full Stack Development',
  'Data Science & Analytics',
  'AI / Machine Learning',
  'DevOps & Cloud Infrastructure',
  'Core Computer Science & DSA',
];

export const AVAILABLE_COMPANIES = [
  'All',
  'Google',
  'Amazon',
  'TCS',
  'Infosys',
  'Wipro',
  'Custom',
  'Microsoft',
  'Meta',
  'Netflix',
];
