import { UserRoadmap, RoadmapStage, TopicMasteryRecord, AIMentorInsight, SkillGapItem } from '../types/database.types';

export function getDefaultRoadmap(userId: string, targetRole = 'Full Stack Developer'): UserRoadmap {
  const isDataScience = targetRole.toLowerCase().includes('data') || targetRole.toLowerCase().includes('ml') || targetRole.toLowerCase().includes('ai');

  const stages: RoadmapStage[] = isDataScience
    ? [
        {
          id: 1,
          title: 'Foundations',
          description: 'Master mathematical foundations, statistical probability, and core Python for data science.',
          skills: ['Python 3.12 Fundamentals', 'Linear Algebra & Vectors', 'Descriptive & Inferential Stats', 'Data Structures in Python'],
          progress: 80,
          is_unlocked: true,
          tasks: [
            { id: 'ds-f1', title: 'Review Probability distributions, Bayes theorem, and hypothesis testing', completed: true, difficulty: 'Beginner', tag: 'Statistics' },
            { id: 'ds-f2', title: 'Implement Matrix operations, eigenvalues, and dot products using NumPy', completed: true, difficulty: 'Beginner', tag: 'Math' },
            { id: 'ds-f3', title: 'Master Python memory management, list comprehensions, and generators', completed: true, difficulty: 'Beginner', tag: 'Python' },
            { id: 'ds-f4', title: 'Study asymptotic time complexity of Pandas indexing and sorting', completed: false, difficulty: 'Intermediate', tag: 'CS Theory' },
          ],
        },
        {
          id: 2,
          title: 'Core Concepts',
          description: 'Deep dive into data wrangling, SQL analytical aggregations, and exploratory data analysis.',
          skills: ['Pandas DataFrames', 'SQL Aggregations & Joins', 'Feature Preprocessing', 'Data Visualization (Seaborn/Plotly)'],
          progress: 65,
          is_unlocked: true,
          tasks: [
            { id: 'ds-c1', title: 'Perform exploratory data analysis and outlier detection on tabular datasets', completed: true, difficulty: 'Intermediate', tag: 'EDA' },
            { id: 'ds-c2', title: 'Write advanced SQL queries with Window functions, CTEs, and group rollups', completed: true, difficulty: 'Intermediate', tag: 'SQL' },
            { id: 'ds-c3', title: 'Engineer missing-value imputation, one-hot encoding, and min-max scaling', completed: false, difficulty: 'Intermediate', tag: 'Preprocessing' },
            { id: 'ds-c4', title: 'Build automated interactive dashboard visualising feature distributions', completed: false, difficulty: 'Intermediate', tag: 'Visualization' },
          ],
        },
        {
          id: 3,
          title: 'Intermediate',
          description: 'Classical machine learning algorithms, cross-validation, and bias-variance tradeoff.',
          skills: ['Supervised Learning (Scikit-Learn)', 'Unsupervised Clustering', 'Tree Ensembles (XGBoost/LightGBM)', 'Model Validation (K-Fold/ROC-AUC)'],
          progress: 50,
          is_unlocked: true,
          tasks: [
            { id: 'ds-i1', title: 'Train and tune Random Forest & XGBoost classifiers with GridSearchCV', completed: true, difficulty: 'Intermediate', tag: 'ML' },
            { id: 'ds-i2', title: 'Mitigate class imbalance using SMOTE and focal loss thresholds', completed: false, difficulty: 'Intermediate', tag: 'ML' },
            { id: 'ds-i3', title: 'Implement K-Means and DBSCAN clustering with silhouette score audits', completed: false, difficulty: 'Intermediate', tag: 'Clustering' },
            { id: 'ds-i4', title: 'Evaluate models using Confusion Matrix, Precision-Recall curves, and F1-score', completed: false, difficulty: 'Intermediate', tag: 'Metrics' },
          ],
        },
        {
          id: 4,
          title: 'Advanced',
          description: 'Deep neural networks, PyTorch, natural language processing, and LLM fine-tuning.',
          skills: ['PyTorch & Tensor Operations', 'Convolutional & Recurrent Nets', 'Transformer Attention Mechanisms', 'RAG Pipelines & Vector DBs'],
          progress: 35,
          is_unlocked: true,
          tasks: [
            { id: 'ds-a1', title: 'Build custom multi-layer perceptron and CNN in PyTorch from scratch', completed: true, difficulty: 'Advanced', tag: 'Deep Learning' },
            { id: 'ds-a2', title: 'Implement Self-Attention and multi-head attention blocks mathematically', completed: false, difficulty: 'Advanced', tag: 'Transformers' },
            { id: 'ds-a3', title: 'Construct Retrieval-Augmented Generation (RAG) pipeline with ChromaDB', completed: false, difficulty: 'Advanced', tag: 'GenAI' },
            { id: 'ds-a4', title: 'Fine-tune open-weights LLM using LoRA / QLoRA adapters', completed: false, difficulty: 'Advanced', tag: 'LLM' },
          ],
        },
        {
          id: 5,
          title: 'Projects',
          description: 'Production-grade MLOps pipelines, API serving, containerization, and monitoring.',
          skills: ['FastAPI Model Serving', 'Docker for ML', 'MLflow Experiment Tracking', 'Model Drift & Monitoring'],
          progress: 25,
          is_unlocked: true,
          tasks: [
            { id: 'ds-p1', title: 'Deploy PyTorch/Scikit-Learn model behind async FastAPI microservice', completed: true, difficulty: 'Advanced', tag: 'API Serving' },
            { id: 'ds-p2', title: 'Containerize ML prediction service with Docker and GPU acceleration', completed: false, difficulty: 'Advanced', tag: 'Docker' },
            { id: 'ds-p3', title: 'Track model experiments, parameters, and artifacts with MLflow', completed: false, difficulty: 'Intermediate', tag: 'MLOps' },
            { id: 'ds-p4', title: 'Implement data drift detection using Kolmogorov-Smirnov test', completed: false, difficulty: 'Advanced', tag: 'Reliability' },
          ],
        },
        {
          id: 6,
          title: 'Mock Interviews',
          description: 'High-stakes machine learning system design, A/B testing defense, and statistical coding.',
          skills: ['ML System Design', 'A/B Testing Frameworks', 'Live Statistical Modeling', 'STAR Behavioral Delivery'],
          progress: 15,
          is_unlocked: true,
          tasks: [
            { id: 'ds-m1', title: 'Simulate Recommendation System design (Collaborative Filtering vs Embeddings)', completed: false, difficulty: 'Advanced', tag: 'System Design' },
            { id: 'ds-m2', title: 'Defend statistical hypothesis test design and sample size calculation', completed: false, difficulty: 'Intermediate', tag: 'A/B Testing' },
            { id: 'ds-m3', title: 'Complete 3 AI InterviewIQ Data Science technical rounds with >80% score', completed: false, difficulty: 'Advanced', tag: 'Mock' },
          ],
        },
        {
          id: 7,
          title: 'Placement Ready',
          description: 'Kaggle portfolio showcase, ATS resume optimization, and corporate offer negotiation.',
          skills: ['Kaggle & GitHub Portfolio', 'ATS Resume for Data Roles', 'Executive Storytelling', 'Compensation Negotiation'],
          progress: 0,
          is_unlocked: false,
          tasks: [
            { id: 'ds-pl1', title: 'Curate top 3 end-to-end ML projects on GitHub with architecture diagrams', completed: false, difficulty: 'Beginner', tag: 'Portfolio' },
            { id: 'ds-pl2', title: 'Optimize resume for ATS keyword scanning (PyTorch, SQL, XGBoost, MLOps)', completed: false, difficulty: 'Beginner', tag: 'Resume' },
            { id: 'ds-pl3', title: 'Practice 5 STAR stories emphasizing business metrics and revenue impact', completed: false, difficulty: 'Intermediate', tag: 'Behavioral' },
          ],
        },
      ]
    : [
        {
          id: 1,
          title: 'Foundations',
          description: 'Master core CS fundamentals, algorithmic thinking, and system principles.',
          skills: ['Data Structures & Algorithms', 'Object-Oriented Programming', 'OS & Memory Management', 'Database Systems (DBMS)'],
          progress: 85,
          is_unlocked: true,
          tasks: [
            { id: 'f-1', title: 'Review Big-O notation, Time & Space Complexity trade-offs', completed: true, difficulty: 'Beginner', tag: 'CS Theory' },
            { id: 'f-2', title: 'Implement Arrays, Linked Lists, Stacks, Queues from scratch', completed: true, difficulty: 'Beginner', tag: 'DSA' },
            { id: 'f-3', title: 'Understand relational algebra, ACID properties, and normalization', completed: true, difficulty: 'Intermediate', tag: 'DBMS' },
            { id: 'f-4', title: 'Study multi-threading, concurrency, race conditions, and deadlocks', completed: false, difficulty: 'Intermediate', tag: 'OS' },
          ],
        },
        {
          id: 2,
          title: 'Core Concepts',
          description: 'Deep dive into modern role-specific frameworks, architecture, and APIs.',
          skills: ['React 19 & TypeScript', 'Node.js & Express / Fastify', 'PostgreSQL & ORMs', 'REST & GraphQL Architecture'],
          progress: 70,
          is_unlocked: true,
          tasks: [
            { id: 'c-1', title: 'Master React reconciliation, useEffect dependency traps, and custom hooks', completed: true, difficulty: 'Intermediate', tag: 'Frontend' },
            { id: 'c-2', title: 'Build asynchronous REST APIs with input validation (Zod/Joi) and JWT auth', completed: true, difficulty: 'Intermediate', tag: 'Backend' },
            { id: 'c-3', title: 'Design normalized SQL schema with composite indexes and transaction locks', completed: false, difficulty: 'Advanced', tag: 'Database' },
            { id: 'c-4', title: 'Implement Redis caching with TTL and cache-aside invalidation', completed: false, difficulty: 'Advanced', tag: 'Caching' },
          ],
        },
        {
          id: 3,
          title: 'Intermediate',
          description: 'State management, architectural caching, database indexing, and async flow control.',
          skills: ['Zustand / Redux Toolkit', 'PostgreSQL B-Tree Indexing', 'Redis Cache-Aside', 'Connection Pooling'],
          progress: 60,
          is_unlocked: true,
          tasks: [
            { id: 'in-1', title: 'Optimize multi-table SQL queries using composite B-Tree indexes and EXPLAIN ANALYZE', completed: true, difficulty: 'Intermediate', tag: 'SQL' },
            { id: 'in-2', title: 'Implement Redis cache invalidation on write events with fallback handling', completed: true, difficulty: 'Intermediate', tag: 'Caching' },
            { id: 'in-3', title: 'Handle async race conditions and idempotency for payment POST routes', completed: false, difficulty: 'Advanced', tag: 'Backend' },
            { id: 'in-4', title: 'Configure database connection pooling with pg-pool to prevent socket exhaustion', completed: false, difficulty: 'Intermediate', tag: 'Database' },
          ],
        },
        {
          id: 4,
          title: 'Advanced',
          description: 'Scalable system design, distributed data patterns, microservices, and concurrency locks.',
          skills: ['High-Level System Design', 'Distributed Caching', 'Event-Driven Message Queues', 'Database Sharding & Replication'],
          progress: 45,
          is_unlocked: true,
          tasks: [
            { id: 'adv-1', title: 'Design URL shortener & Pastebin handling 100k writes/sec with consistent hashing', completed: true, difficulty: 'Advanced', tag: 'System Design' },
            { id: 'adv-2', title: 'Implement asynchronous job processing with BullMQ and Redis queues', completed: false, difficulty: 'Advanced', tag: 'Distributed' },
            { id: 'adv-3', title: 'Compare database replication (Read Replicas) vs Sharding horizontal partitions', completed: false, difficulty: 'Advanced', tag: 'Architecture' },
            { id: 'adv-4', title: 'Mitigate Distributed Denial of Service (DDoS) and design rate-limiting algorithms', completed: false, difficulty: 'Advanced', tag: 'Security' },
          ],
        },
        {
          id: 5,
          title: 'Projects',
          description: 'Engineer production-grade portfolio applications showcasing full-stack competence.',
          skills: ['Full Stack Architecture', 'Microservices', 'Docker & Containerization', 'Cloud Deployment (AWS/Vercel)'],
          progress: 30,
          is_unlocked: true,
          tasks: [
            { id: 'p-1', title: 'Build full-stack SaaS with role-based access control and payment/auth flow', completed: true, difficulty: 'Advanced', tag: 'Full Stack' },
            { id: 'p-2', title: 'Containerize backend services with Docker and Docker Compose', completed: false, difficulty: 'Intermediate', tag: 'DevOps' },
            { id: 'p-3', title: 'Deploy with CI/CD pipeline using GitHub Actions to Cloud environment', completed: false, difficulty: 'Advanced', tag: 'DevOps' },
            { id: 'p-4', title: 'Write comprehensive integration tests covering critical API routes', completed: false, difficulty: 'Intermediate', tag: 'Testing' },
          ],
        },
        {
          id: 6,
          title: 'Mock Interviews',
          description: 'Simulate high-stakes technical rounds for target tech giants & startups.',
          skills: ['Company-Specific Rounds', 'STAR Method Behavioral', 'Live Coding Defense', 'Confidence & Voice Delivery'],
          progress: 20,
          is_unlocked: true,
          tasks: [
            { id: 'm-1', title: 'Complete 3 Google-style System Design & Algorithm mock rounds', completed: true, difficulty: 'Advanced', tag: 'Google Mock' },
            { id: 'm-2', title: 'Practice Amazon Leadership Principles with concrete STAR scenario answers', completed: false, difficulty: 'Intermediate', tag: 'Amazon LP' },
            { id: 'm-3', title: 'Undergo TCS & Service Tech Giant technical aptitude & core rounds', completed: false, difficulty: 'Beginner', tag: 'TCS Practice' },
            { id: 'm-4', title: 'Achieve >80% Communication & Voice Confidence score in voice mode', completed: false, difficulty: 'Intermediate', tag: 'Voice AI' },
          ],
        },
        {
          id: 7,
          title: 'Placement Ready',
          description: 'Final resume polish, portfolio audit, behavioral readiness, and offer negotiation.',
          skills: ['ATS-Optimized Resume', 'Portfolio & GitHub Cleanliness', 'Executive Presence', 'Salary Negotiation'],
          progress: 0,
          is_unlocked: false,
          tasks: [
            { id: 'pl-1', title: 'Align resume keywords to target role with quantified metric achievements', completed: false, difficulty: 'Beginner', tag: 'Resume' },
            { id: 'pl-2', title: 'Prepare 5 concise STAR stories covering challenges, conflict, and ownership', completed: false, difficulty: 'Intermediate', tag: 'Behavioral' },
            { id: 'pl-3', title: 'Pin top 3 GitHub projects with clean READMEs, live demo links, and docs', completed: false, difficulty: 'Beginner', tag: 'GitHub' },
            { id: 'pl-4', title: 'Review compensation structure, base salary brackets, and negotiation script', completed: false, difficulty: 'Intermediate', tag: 'Negotiation' },
          ],
        },
      ];

  // Calculate overall progress across all tasks
  const totalTasks = stages.flatMap(s => s.tasks);
  const completedTasks = totalTasks.filter(t => t.completed).length;
  const overall_progress = Math.round((completedTasks / totalTasks.length) * 100);

  const detailed_skill_gaps: SkillGapItem[] = isDataScience
    ? [
        {
          skill: 'SQL Analytical Functions & CTEs',
          priority: 'High',
          category: 'SQL & Data Wrangling',
          resource_title: 'PostgreSQL Window Functions & Analytical SQL Mastery',
          resource_url: 'https://mode.com/sql-tutorial/sql-window-functions/',
          action_summary: 'Master OVER (PARTITION BY ... ORDER BY), ROW_NUMBER, and DENSE_RANK for cohort analytics.',
        },
        {
          skill: 'Class Imbalance & Evaluation Metrics',
          priority: 'High',
          category: 'Machine Learning',
          resource_title: 'Precision-Recall Tradeoff & SMOTE Oversampling Guide',
          resource_url: 'https://scikit-learn.org/stable/modules/model_evaluation.html',
          action_summary: 'Learn when to avoid raw Accuracy in favor of PR-AUC, F1-Score, and Cost-Sensitive Learning.',
        },
        {
          skill: 'Vector Search & Embeddings (RAG)',
          priority: 'Medium',
          category: 'Generative AI',
          resource_title: 'Pinecone Vector Search & Transformer Embeddings Primer',
          resource_url: 'https://www.pinecone.io/learn/vector-database/',
          action_summary: 'Study cosine similarity, HNSW indexing, and chunking strategies for enterprise retrieval.',
        },
      ]
    : [
        {
          skill: 'SQL Optimization & Indexing',
          priority: 'High',
          category: 'Database Architecture',
          resource_title: 'Use The Index, Luke! Database Indexing Tutorial',
          resource_url: 'https://use-the-index-luke.com/',
          action_summary: 'Master composite B-Tree indexes, index selectivity, and query execution plans via EXPLAIN ANALYZE.',
        },
        {
          skill: 'System Design & Scalability',
          priority: 'High',
          category: 'Distributed Systems',
          resource_title: 'The System Design Primer (by Donne Martin)',
          resource_url: 'https://github.com/donnemartin/system-design-primer',
          action_summary: 'Study Cache-Aside invalidation, Load Balancing algorithms, and horizontal database sharding.',
        },
        {
          skill: 'DSA & Tree Traversals',
          priority: 'Medium',
          category: 'Core Computer Science',
          resource_title: 'NeetCode 150 - Binary Trees & Graph Traversal Patterns',
          resource_url: 'https://neetcode.io/practice',
          action_summary: 'Practice recursive vs iterative call-stack space complexity trade-offs for BFS/DFS.',
        },
      ];

  return {
    user_id: userId,
    target_role: targetRole,
    overall_progress,
    stages,
    skill_gaps: detailed_skill_gaps.map(g => g.skill),
    detailed_skill_gaps,
    last_updated: new Date().toISOString(),
  };
}

export const INITIAL_TOPIC_HEATMAP: TopicMasteryRecord[] = [
  { topic: 'React & State Management', category: 'Frontend', score: 88, status: 'strong', sessions_tested: 4, trend: 'up', last_tested: 'Yesterday' },
  { topic: 'JavaScript Core / Async', category: 'Frontend', score: 82, status: 'strong', sessions_tested: 3, trend: 'up', last_tested: '2 days ago' },
  { topic: 'REST API & Express', category: 'Backend', score: 79, status: 'strong', sessions_tested: 3, trend: 'up', last_tested: '3 days ago' },
  { topic: 'Data Structures & Algorithms', category: 'CS Core', score: 68, status: 'medium', sessions_tested: 2, trend: 'neutral', last_tested: '4 days ago' },
  { topic: 'Object-Oriented Design', category: 'CS Core', score: 72, status: 'medium', sessions_tested: 2, trend: 'up', last_tested: '5 days ago' },
  { topic: 'SQL Queries & Joins', category: 'Database', score: 48, status: 'weak', sessions_tested: 3, trend: 'down', last_tested: '1 day ago' },
  { topic: 'Database Indexing & Locks', category: 'Database', score: 42, status: 'weak', sessions_tested: 2, trend: 'down', last_tested: '3 days ago' },
  { topic: 'System Design & Scalability', category: 'Architecture', score: 45, status: 'weak', sessions_tested: 2, trend: 'down', last_tested: '2 days ago' },
  { topic: 'Docker & Microservices', category: 'DevOps', score: 62, status: 'medium', sessions_tested: 1, trend: 'neutral', last_tested: '6 days ago' },
  { topic: 'STAR Behavioral Scenarios', category: 'HR / Culture', score: 85, status: 'strong', sessions_tested: 2, trend: 'up', last_tested: 'Yesterday' },
];

export const INITIAL_AI_MENTOR_INSIGHTS: AIMentorInsight[] = [
  {
    id: 'insight-1',
    skill_area: 'SQL Querying & Database Indexing',
    score: 4.8,
    issue: 'Omission of composite indexes, query execution plans, and multi-table JOIN edge cases.',
    recommendation: 'Practice writing complex queries with EXPLAIN ANALYZE, composite indexes, and understand B-Tree index lookup tradeoffs.',
    priority: 'high',
    category: 'Database & SQL',
    action_label: 'Practice SQL Drills',
    action_type: 'practice',
  },
  {
    id: 'insight-2',
    skill_area: 'System Design & Scalability',
    score: 5.1,
    issue: 'Lacks discussion of cache-aside patterns, database replication bottlenecks, and load balancer algorithms.',
    recommendation: 'In corporate interviews (Google/Amazon), always structure system design: Requirements -> High-Level Design -> Deep Dive -> Failure Modes.',
    priority: 'high',
    category: 'Architecture',
    action_label: 'Start System Design Mock',
    action_type: 'practice',
  },
  {
    id: 'insight-3',
    skill_area: 'Data Structures & Algorithms',
    score: 6.8,
    issue: 'Occasionally hesitates when calculating Worst-Case Space Complexity in recursive algorithms.',
    recommendation: 'Explicitly state the call-stack memory depth O(N) when discussing recursion or DFS traversals.',
    priority: 'medium',
    category: 'Algorithms',
    action_label: 'Review DSA Checklist',
    action_type: 'guide',
  },
  {
    id: 'insight-4',
    skill_area: 'React 19 & State Architecture',
    score: 8.8,
    issue: 'Solid foundational grasp; could highlight Concurrent Mode, useTransition, and Server Actions for senior roles.',
    recommendation: 'Leverage your React strength! Elaborate on preventing unnecessary renders using immutable data patterns.',
    priority: 'low',
    category: 'Frontend',
    action_label: 'Explore Advanced React',
    action_type: 'roadmap',
  },
];
