export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type InterviewStatus = 'in_progress' | 'completed' | 'cancelled';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  avatar_url?: string | null;
  cgpa?: string | number | null;
  target_role?: string | null;
  interested_fields?: string[];
  skills?: string[];
  preferred_companies?: string[];
  bio?: string | null;
  is_profile_completed?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface JobRole {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  difficulty: 'Junior' | 'Mid-Level' | 'Senior' | string;
  created_at?: string;
}

export interface Question {
  id: string;
  role_id?: string | null;
  field: string;
  company?: string;
  question_text: string;
  question_type: 'Technical' | 'System Design' | 'Behavioral' | 'Conceptual' | string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Junior' | 'Mid-Level' | 'Senior' | string;
  topic: string;
  created_at?: string;
}

export interface Interview {
  id: string;
  user_id: string;
  role_id: string | null;
  field?: string;
  company?: string;
  difficulty?: string;
  status: InterviewStatus;
  started_at: string;
  completed_at: string | null;
  total_questions: number;
  overall_score: number | null;
  created_at: string;
  // Joined relation fields
  job_role?: JobRole;
  questions?: (Question & { sequence_number?: number })[];
}

export interface InterviewQuestion {
  id: string;
  interview_id: string;
  question_id: string;
  sequence_number: number;
}

export interface Answer {
  id: string;
  interview_id: string;
  question_id: string;
  user_id: string;
  answer_text: string;
  submitted_at: string;
  // Joined evaluation
  evaluation?: Evaluation;
  question?: Question;
}

export interface Evaluation {
  id: string;
  answer_id: string;
  relevance_score: number;
  clarity_score: number;
  content_score: number;
  technical_score: number;
  communication_score: number;
  overall_score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  feedback: string;
  created_at?: string;
}

export interface PerformanceHistory {
  id: string;
  user_id: string;
  interview_id: string | null;
  role_id: string | null;
  field?: string;
  company?: string;
  score: number;
  completed_at: string;
  job_role?: JobRole;
}

export interface AIEvaluationResponse {
  relevance_score: number;
  clarity_score: number;
  content_score: number;
  technical_score: number;
  communication_score: number;
  overall_score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  feedback: string;
}

export interface QuestionFilters {
  field: string;
  company: string;
  difficulty: string;
  totalQuestions: number;
  excludeIds?: string[];
}

// Career Roadmap Types
export interface RoadmapTask {
  id: string;
  title: string;
  completed: boolean;
  tag?: string;
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface RoadmapStage {
  id: number;
  title: string;
  description: string;
  skills: string[];
  tasks: RoadmapTask[];
  progress: number; // 0 - 100
  is_unlocked: boolean;
}

export interface SkillGapItem {
  skill: string;
  priority: 'High' | 'Medium' | 'Low';
  category?: string;
  resource_title: string;
  resource_url: string;
  action_summary: string;
}

export interface UserRoadmap {
  user_id: string;
  target_role: string;
  overall_progress: number; // 0 - 100
  stages: RoadmapStage[];
  skill_gaps: string[];
  detailed_skill_gaps?: SkillGapItem[];
  last_updated: string;
}

// Voice & Communication Delivery Types
export interface VoiceMetrics {
  wpm: number;
  filler_count: number;
  filler_words: string[];
  pause_count: number;
  confidence_score: number; // 0 - 10
  clarity_score: number;    // 0 - 10
  tone: string;             // e.g. "Direct & Professional"
  timing_available: boolean;
  duration_seconds?: number;
  delivery_feedback: string;
  personality_verdict?: string; // Kept for backward compatibility
  pace_feedback: string;
  structural_clarity?: {
    has_intro: boolean;
    has_technical_body: boolean;
    has_conclusion: boolean;
  };
}

// Real-Time Answer Improver Types
export interface RealtimeImprovementData {
  word_count: number;
  reading_time_sec: number;
  structure: {
    has_intro: boolean;
    has_technical_body: boolean;
    has_conclusion: boolean;
    has_star_method: boolean;
  };
  suggestions: string[];
  detected_keywords: string[];
  recommended_keywords: string[];
  status_badge: string;
  improved_star_answer?: string;
  grammar_corrections?: {
    original: string;
    correction: string;
    reason: string;
  }[];
}

// Answer Comparison Mode Types
export interface AnswerComparisonData {
  question_id: string;
  user_answer: string;
  ideal_answer: string;
  score_out_of_10: number; // 0 - 10
  missing_points: string[];
  missing_keywords: string[];
  phrasing_suggestions: {
    original: string;
    improved: string;
    rationale: string;
  }[];
  depth_critique: string;
}

// Topic Heatmap Types
export interface TopicMasteryRecord {
  topic: string;
  category: string;
  score: number; // 0 - 100
  status: 'strong' | 'medium' | 'weak';
  sessions_tested: number;
  trend: 'up' | 'down' | 'neutral';
  last_tested: string;
}

// AI Mentor Insight Types
export interface AIMentorInsight {
  id: string;
  skill_area: string;
  score: number; // e.g. 5.2 / 10 or percentage
  issue: string;
  recommendation: string;
  priority: 'high' | 'medium' | 'low';
  category: string;
  action_label: string;
  action_type: 'practice' | 'roadmap' | 'guide';
}

// AI Follow-Up Question
export interface FollowUpQuestion {
  question_text: string;
  context_reason: string;
  parent_question_id?: string;
  suggested_focus: string;
}


