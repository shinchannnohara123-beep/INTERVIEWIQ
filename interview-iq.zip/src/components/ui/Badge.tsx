import React from 'react';

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children: React.ReactNode;
  variant?: 'blue' | 'emerald' | 'amber' | 'purple' | 'slate' | 'rose' | 'outline';
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'blue',
  size = 'md',
  className = '',
  ...props
}) => {
  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5 font-medium rounded-md',
    md: 'text-xs px-2.5 py-1 font-medium rounded-lg',
  };

  const variantStyles = {
    blue: 'bg-blue-50 text-blue-700 border border-blue-200/60',
    emerald: 'bg-emerald-50 text-emerald-700 border border-emerald-200/60',
    amber: 'bg-amber-50 text-amber-700 border border-amber-200/60',
    purple: 'bg-purple-50 text-purple-700 border border-purple-200/60',
    slate: 'bg-slate-100 text-slate-700 border border-slate-200',
    rose: 'bg-rose-50 text-rose-700 border border-rose-200/60',
    outline: 'bg-white text-slate-700 border border-slate-200',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </span>
  );
};

export const DifficultyBadge: React.FC<{ difficulty: string; size?: 'sm' | 'md' }> = ({ difficulty, size = 'md' }) => {
  const d = difficulty?.toLowerCase() || '';
  if (d.includes('senior')) {
    return <Badge variant="purple" size={size}>{difficulty}</Badge>;
  }
  if (d.includes('mid')) {
    return <Badge variant="blue" size={size}>{difficulty}</Badge>;
  }
  return <Badge variant="emerald" size={size}>{difficulty}</Badge>;
};

export const ScoreBadge: React.FC<{ score: number | null | undefined; size?: 'sm' | 'md' }> = ({ score, size = 'md' }) => {
  if (score === null || score === undefined) {
    return <Badge variant="slate" size={size}>Pending</Badge>;
  }
  if (score >= 85) {
    return <Badge variant="emerald" size={size}>★ {score}/100</Badge>;
  }
  if (score >= 70) {
    return <Badge variant="blue" size={size}>{score}/100</Badge>;
  }
  if (score >= 50) {
    return <Badge variant="amber" size={size}>{score}/100</Badge>;
  }
  return <Badge variant="rose" size={size}>{score}/100</Badge>;
};
