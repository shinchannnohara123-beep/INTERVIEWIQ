import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface ScoreDataPoint {
  date: string;
  score: number;
  role?: string;
}

interface ScoreTrendChartProps {
  data: ScoreDataPoint[];
}

export const ScoreTrendChart: React.FC<ScoreTrendChartProps> = ({ data }) => {
  // If no data, provide gentle default trend
  const chartData = data.length > 0
    ? data
    : [
        { date: 'Initial', score: 65, role: 'Frontend Developer' },
        { date: 'Session 2', score: 72, role: 'Frontend Developer' },
        { date: 'Session 3', score: 82, role: 'Frontend Developer' },
      ];

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={chartData}
          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
        >
          <defs>
            <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#2563eb" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis
            dataKey="date"
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
            dy={8}
          />
          <YAxis
            domain={[0, 100]}
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload as ScoreDataPoint;
                return (
                  <div className="bg-white p-3 rounded-xl shadow-lg border border-slate-100 text-xs">
                    <p className="font-semibold text-slate-800">{item.role || 'Interview'}</p>
                    <p className="text-slate-500 mt-0.5">{item.date}</p>
                    <div className="mt-1 flex items-center gap-1.5 font-bold text-blue-600">
                      <span>Score:</span>
                      <span className="text-sm">{item.score}/100</span>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area
            type="monotone"
            dataKey="score"
            stroke="#2563eb"
            strokeWidth={3}
            fillOpacity={1}
            fill="url(#scoreGradient)"
            dot={{ r: 4, fill: '#2563eb', strokeWidth: 2, stroke: '#ffffff' }}
            activeDot={{ r: 6, fill: '#1d4ed8', stroke: '#ffffff', strokeWidth: 2 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
