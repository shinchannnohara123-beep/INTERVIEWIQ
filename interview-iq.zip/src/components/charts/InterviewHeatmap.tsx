import React from 'react';
import { Flame, TrendingUp, TrendingDown, CheckCircle2, AlertTriangle, ArrowUpRight, Zap } from 'lucide-react';
import { TopicMasteryRecord } from '../../types/database.types';

interface HeatmapProps {
  data: TopicMasteryRecord[];
  onPracticeTopic?: (topic: string) => void;
  showActions?: boolean;
}

export const InterviewHeatmap: React.FC<HeatmapProps> = ({
  data,
  onPracticeTopic,
  showActions = true,
}) => {
  const weakTopics = data.filter((d) => d.status === 'weak');
  const strongTopics = data.filter((d) => d.status === 'strong');
  const mediumTopics = data.filter((d) => d.status === 'medium');

  const mostImproved = data.filter((d) => d.trend === 'up');

  // Overall topic mastery average
  const avgScore = data.length > 0
    ? Math.round(data.reduce((sum, d) => sum + d.score, 0) / data.length)
    : 72;

  return (
    <div className="space-y-6">
      {/* Top Summary Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Strong Mastery</div>
            <div className="text-xl font-extrabold text-emerald-900 mt-0.5">{strongTopics.length} Topics</div>
            <div className="text-[11px] text-emerald-600 font-medium">Score &ge; 75%</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700">Moderate Depth</div>
            <div className="text-xl font-extrabold text-amber-900 mt-0.5">{mediumTopics.length} Topics</div>
            <div className="text-[11px] text-amber-600 font-medium">Score 50% - 74%</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700">
            <Zap className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50/80 border border-rose-200/80 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-rose-700">Needs Urgent Focus</div>
            <div className="text-xl font-extrabold text-rose-900 mt-0.5">{weakTopics.length} Topics</div>
            <div className="text-[11px] text-rose-600 font-medium">Score &lt; 50%</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center text-rose-700">
            <Flame className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Topics vs Performance Heatmap Matrix */}
      <div className="rounded-2xl border border-slate-200 overflow-hidden bg-white shadow-2xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-500" />
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Topic Mastery & Retention Heatmap
            </h4>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-semibold">
            <span className="flex items-center gap-1.5 text-emerald-700">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Strong (&ge;75%)
            </span>
            <span className="flex items-center gap-1.5 text-amber-700">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Medium (50-74%)
            </span>
            <span className="flex items-center gap-1.5 text-rose-700">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Weak (&lt;50%)
            </span>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {data.map((item, idx) => {
            const isStrong = item.status === 'strong';
            const isMedium = item.status === 'medium';
            const isWeak = item.status === 'weak';

            return (
              <div
                key={idx}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-3 h-10 rounded-full shrink-0 ${
                      isStrong
                        ? 'bg-emerald-500'
                        : isMedium
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{item.topic}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                        {item.category}
                      </span>
                      {item.trend === 'up' && (
                        <span className="text-[10px] text-emerald-600 flex items-center font-bold">
                          <TrendingUp className="w-3 h-3 mr-0.5" /> +Improving
                        </span>
                      )}
                      {item.trend === 'down' && (
                        <span className="text-[10px] text-rose-600 flex items-center font-bold">
                          <TrendingDown className="w-3 h-3 mr-0.5" /> -Dip
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Evaluated in {item.sessions_tested} practice rounds • Last tested: {item.last_tested}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end sm:self-center">
                  {/* Progress bar visual */}
                  <div className="w-32 hidden md:block">
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          isStrong
                            ? 'bg-emerald-500'
                            : isMedium
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${item.score}%` }}
                      />
                    </div>
                  </div>

                  {/* Score pill */}
                  <span
                    className={`px-3 py-1 rounded-xl text-xs font-extrabold min-w-[56px] text-center border ${
                      isStrong
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : isMedium
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}
                  >
                    {item.score}%
                  </span>

                  {/* Drill Button */}
                  {showActions && onPracticeTopic && (
                    <button
                      onClick={() => onPracticeTopic(item.topic)}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>Drill</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Most Weak vs Most Improved callout blocks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Most Weak */}
        <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-rose-900 uppercase tracking-wider">
            <Flame className="w-4 h-4 text-rose-600" />
            <span>Top Weak Topics (Focus Here First)</span>
          </div>
          <div className="space-y-1.5 pt-1">
            {weakTopics.slice(0, 3).map((w, i) => (
              <div key={i} className="flex items-center justify-between text-xs p-2 rounded-xl bg-white border border-rose-100">
                <span className="font-semibold text-slate-800">{w.topic}</span>
                <span className="font-bold text-rose-600">{w.score}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Most Improved */}
        <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/80 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 uppercase tracking-wider">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>Most Improved Topics</span>
          </div>
          <div className="space-y-1.5 pt-1">
            {mostImproved.slice(0, 3).map((imp, i) => (
              <div key={i} className="flex items-center justify-between text-xs p-2 rounded-xl bg-white border border-emerald-100">
                <span className="font-semibold text-slate-800">{imp.topic}</span>
                <span className="font-bold text-emerald-600">{imp.score}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
