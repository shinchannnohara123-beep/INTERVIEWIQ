import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface RoleScore {
  name: string;
  score: number;
  attempts: number;
}

interface RolePerformanceChartProps {
  data?: RoleScore[];
}

export const RolePerformanceChart: React.FC<RolePerformanceChartProps> = ({ data }) => {
  const defaultData: RoleScore[] = [
    { name: 'Web Dev', score: 84, attempts: 3 },
    { name: 'Backend', score: 79, attempts: 2 },
    { name: 'Full Stack', score: 82, attempts: 2 },
    { name: 'Data / AI', score: 73, attempts: 1 },
    { name: 'DevOps', score: 76, attempts: 1 },
  ];

  const chartData = data && data.length > 0 ? data : defaultData;
  const colors = ['#2563eb', '#3b82f6', '#0284c7', '#0ea5e9', '#6366f1'];

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
            dy={8}
          />
          <YAxis
            domain={[0, 100]}
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload as RoleScore;
                return (
                  <div className="bg-white p-3 rounded-xl shadow-lg border border-slate-100 text-xs">
                    <p className="font-semibold text-slate-800">{item.name}</p>
                    <p className="text-slate-500 mt-0.5">{item.attempts} interview session(s)</p>
                    <div className="mt-1 flex items-center gap-1.5 font-bold text-blue-600">
                      <span>Avg Score:</span>
                      <span className="text-sm">{item.score}/100</span>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey="score" radius={[6, 6, 0, 0]} maxBarSize={36}>
            {chartData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
