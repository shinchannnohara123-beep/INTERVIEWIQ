import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface SkillScore {
  name: string;
  score: number;
  weight: string;
}

interface RadarSkillsChartProps {
  skills?: SkillScore[];
}

export const RadarSkillsChart: React.FC<RadarSkillsChartProps> = ({ skills }) => {
  const defaultSkills: SkillScore[] = [
    { name: 'Relevance', score: 85, weight: '25%' },
    { name: 'Technical', score: 78, weight: '25%' },
    { name: 'Content', score: 80, weight: '25%' },
    { name: 'Clarity', score: 84, weight: '15%' },
    { name: 'Communication', score: 88, weight: '10%' },
  ];

  const data = skills && skills.length > 0 ? skills : defaultSkills;

  const barColors = ['#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#38bdf8'];

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
            dy={8}
          />
          <YAxis
            domain={[0, 100]}
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 11, fill: '#64748b' }}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload as SkillScore;
                return (
                  <div className="bg-white p-2.5 rounded-xl shadow-lg border border-slate-100 text-xs">
                    <p className="font-semibold text-slate-800">{item.name}</p>
                    <p className="text-slate-500">Weight: {item.weight}</p>
                    <p className="font-bold text-blue-600 mt-1">{item.score} / 100</p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey="score" radius={[6, 6, 0, 0]} maxBarSize={40}>
            {data.map((_, index) => (
              <Cell key={`cell-${index}`} fill={barColors[index % barColors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
