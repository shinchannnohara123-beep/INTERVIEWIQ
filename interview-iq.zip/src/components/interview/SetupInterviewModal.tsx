import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Play, Sparkles, Building2, Layers, CheckCircle, TrendingUp } from 'lucide-react';
import { JobRole } from '../../types/database.types';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { dbService } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { AVAILABLE_FIELDS, AVAILABLE_COMPANIES } from '../../data/question-bank';

interface SetupInterviewModalProps {
  role?: JobRole | null;
  isOpen: boolean;
  onClose: () => void;
}

export const SetupInterviewModal: React.FC<SetupInterviewModalProps> = ({
  role,
  isOpen,
  onClose,
}) => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();

  const [selectedField, setSelectedField] = useState<string>('All');
  const [selectedCompany, setSelectedCompany] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('Scaling');
  const [questionCount, setQuestionCount] = useState<number>(3);
  const [isStarting, setIsStarting] = useState(false);

  // Sync initial defaults from selected role or user profile
  useEffect(() => {
    if (role) {
      if (role.name.includes('Frontend')) setSelectedField('Frontend / Web Development');
      else if (role.name.includes('Backend')) setSelectedField('Backend Development');
      else if (role.name.includes('Full Stack')) setSelectedField('Full Stack Development');
      else if (role.name.includes('Data') || role.name.includes('ML')) setSelectedField('Data Science & Analytics');
      else if (role.name.includes('DevOps')) setSelectedField('DevOps & Cloud Infrastructure');
      else setSelectedField('All');
    } else if (profile?.interested_fields && profile.interested_fields.length > 0) {
      setSelectedField(profile.interested_fields[0]);
    }
  }, [role, profile]);

  if (!isOpen) return null;

  const handleStart = async () => {
    if (!user) return;
    setIsStarting(true);
    try {
      const result = await dbService.createInterview({
        userId: user.id,
        roleId: role?.id || undefined,
        field: selectedField,
        company: selectedCompany,
        difficulty: selectedDifficulty,
        totalQuestions: questionCount,
      });

      onClose();
      navigate(`/interview/${result.interview.id}`);
    } catch (err) {
      console.error('Failed to create interview session:', err);
    } finally {
      setIsStarting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/50 to-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Configure AI Interview</h3>
              <p className="text-xs text-slate-500">Dynamic questions tailored by field & company</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Target Role preview if launched from role card */}
          {role && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Selected Track</span>
                <span className="text-xs font-bold text-slate-800">{role.name}</span>
              </div>
              <Badge variant="blue" size="sm">{role.category || 'Tech'}</Badge>
            </div>
          )}

          {/* 1. Field Dropdown */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>Target Technical Field</span>
            </label>
            <select
              value={selectedField}
              onChange={(e) => setSelectedField(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 bg-white focus:outline-none focus:border-blue-500 cursor-pointer shadow-2xs"
            >
              {AVAILABLE_FIELDS.map((f) => (
                <option key={f} value={f}>
                  {f === 'All' ? '🌟 All Fields (Comprehensive Mixed Track)' : f}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Company Dropdown */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Target Company / Interview Style</span>
            </label>
            <select
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 bg-white focus:outline-none focus:border-blue-500 cursor-pointer shadow-2xs"
            >
              {AVAILABLE_COMPANIES.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? '🌐 All Companies (General Industry Standard)' : `${c} Style Interview`}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Difficulty Level */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              <span>Difficulty Progression</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'Scaling', label: 'Scaling', sub: 'Easy → Hard' },
                { id: 'Easy', label: 'Junior', sub: 'Basics' },
                { id: 'Medium', label: 'Mid-Level', sub: 'Core' },
                { id: 'Hard', label: 'Senior', sub: 'System' },
              ].map((lvl) => (
                <button
                  key={lvl.id}
                  type="button"
                  onClick={() => setSelectedDifficulty(lvl.id)}
                  className={`py-2 px-2.5 rounded-xl border text-center cursor-pointer transition-all ${
                    selectedDifficulty === lvl.id
                      ? 'border-blue-600 bg-blue-50/90 text-blue-800 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <p className="text-xs font-bold leading-tight">{lvl.label}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{lvl.sub}</p>
                </button>
              ))}
            </div>
          </div>

          {/* 4. Session Length */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              Number of Questions
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { count: 3, label: '3 Questions', desc: '~10 mins' },
                { count: 5, label: '5 Questions', desc: '~20 mins' },
                { count: 7, label: 'Full Mock', desc: '~30 mins' },
              ].map((item) => (
                <button
                  key={item.count}
                  type="button"
                  onClick={() => setQuestionCount(item.count)}
                  className={`py-2.5 px-3 rounded-xl border text-left cursor-pointer transition-all ${
                    questionCount === item.count
                      ? 'border-blue-600 bg-blue-50/80 shadow-2xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <p className={`text-xs font-bold ${questionCount === item.count ? 'text-blue-700' : 'text-slate-800'}`}>
                    {item.label}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{item.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Dynamic Smart Engine Banner */}
          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 flex items-start gap-2.5 text-xs text-blue-900">
            <CheckCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong>Smart Engine Active:</strong> Questions are randomized with zero repetition, starting with core concepts and progressing through production trade-offs.
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <Button variant="outline" size="md" onClick={onClose} disabled={isStarting}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="md"
            isLoading={isStarting}
            leftIcon={<Play className="w-4 h-4 fill-current" />}
            onClick={handleStart}
          >
            Start Dynamic Interview
          </Button>
        </div>
      </div>
    </div>
  );
};
