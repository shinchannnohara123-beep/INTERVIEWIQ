import React, { useState, useMemo } from 'react';
import {
  Zap,
  CheckCircle2,
  Circle,
  Lightbulb,
  Clock,
  FileText,
  AlertCircle,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { analyzeRealtimeAnswer } from '../../lib/ai-client';

interface RealtimeImproverProps {
  answerText: string;
  questionText: string;
  topic?: string;
  isDarkTheme?: boolean;
}

export const RealtimeImprover: React.FC<RealtimeImproverProps> = ({
  answerText,
  questionText,
  topic = 'General',
  isDarkTheme = true,
}) => {
  const [activeTab, setActiveTab] = useState<'heuristics' | 'comparison'>('heuristics');

  const analysis = useMemo(() => {
    return analyzeRealtimeAnswer(answerText, questionText, topic);
  }, [answerText, questionText, topic]);

  const {
    word_count,
    reading_time_sec,
    structure,
    suggestions,
    detected_keywords,
    recommended_keywords,
    status_badge,
    improved_star_answer,
    grammar_corrections = [],
  } = analysis;

  return (
    <div
      className={`rounded-2xl border p-4 space-y-4 transition-all duration-200 ${
        isDarkTheme
          ? 'bg-slate-900/90 border-slate-800 text-slate-100 shadow-xl backdrop-blur-md'
          : 'bg-white border-slate-200 text-slate-800 shadow-sm'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b pb-3 border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold tracking-tight">Real-Time Answer Improver</h4>
            <p className="text-[10px] text-slate-400">Live AI heuristic & STAR engine</p>
          </div>
        </div>

        <span
          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
            status_badge.includes('Comprehensive')
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              : status_badge.includes('Solid')
              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
              : status_badge.includes('Needs')
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              : 'bg-slate-800 text-slate-400'
          }`}
        >
          {status_badge}
        </span>
      </div>

      {/* Tab Selector: Heuristics vs USER ANSWER vs AI IMPROVED ANSWER */}
      <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-800/70 border border-slate-700/60 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveTab('heuristics')}
          className={`py-1.5 rounded-lg transition-all cursor-pointer text-center text-[11px] ${
            activeTab === 'heuristics'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Heuristics & Checklist
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('comparison')}
          className={`py-1.5 rounded-lg transition-all cursor-pointer text-center text-[11px] flex items-center justify-center gap-1 ${
            activeTab === 'comparison'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3 h-3 text-sky-300" />
          <span>User vs AI Answer</span>
        </button>
      </div>

      {activeTab === 'comparison' ? (
        /* USER ANSWER vs AI IMPROVED ANSWER Display */
        <div className="space-y-3.5 animate-in fade-in duration-150">
          <div className="text-[11px] font-bold uppercase tracking-wider text-blue-400 flex items-center justify-between">
            <span>USER ANSWER vs AI IMPROVED ANSWER</span>
            <span className="text-[10px] text-slate-400 lowercase">live dynamic comparison</span>
          </div>

          {/* User Answer Column */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/70 space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 uppercase tracking-wider">
              <span className="flex items-center gap-1">
                <FileText className="w-3 h-3 text-blue-400" /> User Answer (Your Draft)
              </span>
              <span className="text-slate-400 font-mono">{word_count} words</span>
            </div>
            <div className="text-xs text-slate-300 leading-relaxed max-h-36 overflow-y-auto whitespace-pre-wrap font-sans p-2 rounded-lg bg-slate-900/60 border border-slate-800">
              {answerText.trim() ? answerText : <span className="text-slate-500 italic">Start typing your answer to generate real-time comparison...</span>}
            </div>
          </div>

          {/* AI Improved Answer (STAR Format) */}
          <div className="p-3 rounded-xl bg-gradient-to-br from-blue-950/40 to-slate-900 border border-blue-500/30 space-y-2">
            <div className="flex items-center justify-between text-[10px] font-bold text-blue-300 uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" /> AI Improved Answer (STAR Format)
              </span>
              <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-bold text-[9px] border border-blue-400/30">
                FAANG Standard
              </span>
            </div>
            <div className="text-xs text-slate-200 leading-relaxed max-h-44 overflow-y-auto whitespace-pre-wrap font-sans p-2.5 rounded-lg bg-slate-950/70 border border-blue-900/50">
              {improved_star_answer ? (
                improved_star_answer
              ) : (
                <span className="text-slate-500 italic">Type at least 15 words to unlock live STAR restructuring...</span>
              )}
            </div>
          </div>

          {/* Grammar & Phrasing Corrections */}
          {grammar_corrections.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Grammar & Phrasing Polish
              </div>
              <div className="space-y-1.5">
                {grammar_corrections.slice(0, 2).map((gc: { original: string; correction: string; reason: string }, idx: number) => (
                  <div
                    key={idx}
                    className="p-2 rounded-lg bg-slate-800/70 border border-slate-700/80 text-[10px] space-y-0.5"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-rose-400 line-through">{gc.original}</span>
                      <ArrowRight className="w-2.5 h-2.5 text-slate-500" />
                      <span className="text-emerald-300 font-semibold">{gc.correction}</span>
                    </div>
                    <p className="text-slate-400">{gc.reason}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Heuristics & Checklist Mode */
        <div className="space-y-4 animate-in fade-in duration-150">
          {/* Live Count & Pacing Stats */}
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className={`p-2.5 rounded-xl ${isDarkTheme ? 'bg-slate-800/60' : 'bg-slate-50'}`}>
              <div className="text-[10px] text-slate-400 font-medium">Word Count</div>
              <div className="text-base font-extrabold text-blue-400 mt-0.5">{word_count}</div>
              <div className="text-[9px] text-slate-500">Min 40-80 recommended</div>
            </div>

            <div className={`p-2.5 rounded-xl ${isDarkTheme ? 'bg-slate-800/60' : 'bg-slate-50'}`}>
              <div className="text-[10px] text-slate-400 font-medium">Speaking Duration</div>
              <div className="text-base font-extrabold text-sky-400 mt-0.5">~{reading_time_sec}s</div>
              <div className="text-[9px] text-slate-500">Target 45s - 90s</div>
            </div>
          </div>

          {/* STAR Structure Checklist */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              <span>Structure Checklist</span>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between p-1.5 rounded-lg bg-slate-800/30">
                <span className="text-[11px] text-slate-300">1. Core Definition / Context</span>
                {structure.has_intro ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                )}
              </div>

              <div className="flex items-center justify-between p-1.5 rounded-lg bg-slate-800/30">
                <span className="text-[11px] text-slate-300">2. Technical Implementation</span>
                {structure.has_technical_body ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                )}
              </div>

              <div className="flex items-center justify-between p-1.5 rounded-lg bg-slate-800/30">
                <span className="text-[11px] text-slate-300">3. Tradeoffs & Result</span>
                {structure.has_conclusion ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                )}
              </div>
            </div>
          </div>

          {/* Real-time Dynamic AI Suggestions */}
          {suggestions.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Live Recommendations</span>
              </div>

              <div className="space-y-1.5">
                {suggestions.slice(0, 3).map((sug, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] leading-relaxed"
                  >
                    {sug}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Suggested Strong Keywords to Include */}
          {recommended_keywords.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Strong Industry Keywords:
              </div>
              <div className="flex flex-wrap gap-1.5">
                {recommended_keywords.map((kw, idx) => {
                  const isDetected = answerText.toLowerCase().includes(kw.toLowerCase());
                  return (
                    <span
                      key={idx}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition-all ${
                        isDetected
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 line-through opacity-70'
                          : 'bg-blue-500/15 text-blue-300 border border-blue-500/30 hover:bg-blue-500/25'
                      }`}
                    >
                      {kw}
                    </span>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
export default RealtimeImprover;
