import React, { useState, useEffect } from 'react';
import { Sparkles, Brain, Cpu, CheckCircle2 } from 'lucide-react';

interface AnalyzingLoaderProps {
  message?: string;
}

export const AnalyzingLoader: React.FC<AnalyzingLoaderProps> = ({
  message = 'Analyzing your answer...',
}) => {
  const steps = [
    'Evaluating response relevance & keyword alignment...',
    'Assessing technical accuracy & architectural depth...',
    'Scoring structural clarity & communication flow...',
    'Synthesizing strengths, weaknesses & targeted advice...',
  ];

  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveStep((prev) => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 900);
    return () => clearInterval(timer);
  }, [steps.length]);

  return (
    <div className="flex flex-col items-center justify-center p-12 bg-white rounded-2xl border border-blue-100 shadow-xl max-w-lg mx-auto text-center animate-in zoom-in-95 duration-200">
      {/* Animated pulsing AI icon */}
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-sky-400 flex items-center justify-center text-white shadow-xl shadow-blue-500/25 animate-pulse">
          <Brain className="w-10 h-10 animate-bounce" />
        </div>
        <div className="absolute -inset-2 rounded-3xl bg-blue-500/10 -z-10 animate-ping" />
      </div>

      <h3 className="text-xl font-bold text-slate-900 tracking-tight">
        {message}
      </h3>
      <p className="text-xs text-slate-500 mt-1 max-w-sm">
        Our AI model is performing multi-dimensional evaluation of your technical response.
      </p>

      {/* Progress steps animation */}
      <div className="w-full mt-6 space-y-2.5 text-left border-t border-slate-100 pt-5">
        {steps.map((text, idx) => (
          <div
            key={idx}
            className={`flex items-center gap-3 text-xs transition-opacity duration-300 ${
              idx <= activeStep ? 'opacity-100' : 'opacity-30'
            }`}
          >
            {idx < activeStep ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : idx === activeStep ? (
              <span className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin shrink-0" />
            ) : (
              <span className="w-4 h-4 rounded-full border border-slate-200 shrink-0" />
            )}
            <span className={idx === activeStep ? 'font-semibold text-blue-700' : 'text-slate-600'}>
              {text}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
