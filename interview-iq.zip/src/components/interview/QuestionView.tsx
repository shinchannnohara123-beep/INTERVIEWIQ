import React from 'react';
import { Question } from '../../types/database.types';
import { Badge, DifficultyBadge } from '../ui/Badge';
import { HelpCircle, Building2, Layers } from 'lucide-react';

interface QuestionViewProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  roleName: string;
}

export const QuestionView: React.FC<QuestionViewProps> = ({
  question,
  currentIndex,
  totalQuestions,
  roleName,
}) => {
  const progressPercent = Math.round(((currentIndex + 1) / totalQuestions) * 100);

  return (
    <div className="space-y-4">
      {/* Top Meta Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-100">
            Question {currentIndex + 1} of {totalQuestions}
          </span>
          <span className="text-xs text-slate-400">•</span>
          <span className="text-xs font-semibold text-slate-700">{roleName}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {question.company && question.company !== 'General' && question.company !== 'All' && (
            <Badge variant="purple" size="sm" className="font-semibold">
              <Building2 className="w-3 h-3 text-purple-600 inline mr-1" />
              {question.company} Style
            </Badge>
          )}

          {question.field && question.field !== 'All' && (
            <Badge variant="blue" size="sm">
              <Layers className="w-3 h-3 text-blue-600 inline mr-1" />
              {question.field}
            </Badge>
          )}

          {question.topic && (
            <Badge variant="slate" size="sm">
              {question.topic}
            </Badge>
          )}
          <DifficultyBadge difficulty={question.difficulty} size="sm" />
        </div>
      </div>

      {/* Progress Bar (Question X of Y) */}
      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
        <div
          className="bg-blue-600 h-2 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs relative overflow-hidden">
        <div className="absolute top-0 left-0 bottom-0 w-1.5 bg-blue-600" />
        <div className="flex items-start gap-3.5">
          <div className="p-2 rounded-xl bg-blue-50 text-blue-600 shrink-0 mt-0.5">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <p className="text-xs uppercase font-bold tracking-wider text-slate-400">
              Technical Interview Question
            </p>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 leading-snug">
              {question.question_text}
            </h2>
          </div>
        </div>
      </div>
    </div>
  );
};
