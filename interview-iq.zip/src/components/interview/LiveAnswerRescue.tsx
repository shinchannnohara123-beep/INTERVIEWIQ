import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  Lightbulb,
  BookOpen,
  HelpCircle,
  ChevronRight,
  ChevronDown,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  AlertCircle,
  CheckCircle2,
  ListPlus,
  Flame,
} from 'lucide-react';
import { Question } from '../../types/database.types';

interface LiveAnswerRescueProps {
  question: Question | null;
  answerText: string;
  onInsertSkeleton?: (skeletonText: string) => void;
  isDarkTheme?: boolean;
}

export type RescueMode = 'assessment' | 'learning';

export const LiveAnswerRescue: React.FC<LiveAnswerRescueProps> = ({
  question,
  answerText,
  onInsertSkeleton,
  isDarkTheme = true,
}) => {
  const [isEnabled, setIsEnabled] = useState(true);
  const [mode, setMode] = useState<RescueMode>('assessment');
  const [revealedHintLevel, setRevealedHintLevel] = useState<number>(0); // 0 = none, 1, 2, 3
  const [isStuckDetected, setIsStuckDetected] = useState(false);
  const [timeSpentSeconds, setTimeSpentSeconds] = useState(0);

  // Reset hints whenever question changes
  useEffect(() => {
    setRevealedHintLevel(0);
    setIsStuckDetected(false);
    setTimeSpentSeconds(0);
  }, [question?.id]);

  // Track time on question for auto-stuck detection
  useEffect(() => {
    if (!isEnabled || !question) return;

    const timer = setInterval(() => {
      setTimeSpentSeconds((prev) => {
        const next = prev + 1;
        const words = answerText.trim().split(/\s+/).filter(Boolean);
        const lowerAnswer = answerText.toLowerCase();
        const hasStuckKeywords =
          lowerAnswer.includes('stuck') ||
          lowerAnswer.includes("don't know") ||
          lowerAnswer.includes('dont know') ||
          lowerAnswer.includes('no idea') ||
          lowerAnswer.includes('help');

        if ((next >= 30 && words.length < 15) || hasStuckKeywords) {
          setIsStuckDetected(true);
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isEnabled, question?.id, answerText]);

  if (!question) return null;

  // Generate contextual hints dynamically based on question metadata
  const qTopic = question.topic || 'Software Engineering';
  const qText = question.question_text || '';
  const isBehavioral = question.question_type === 'Behavioral' || /tell me|situation|challenge|conflict|time when/i.test(qText);
  const isSystemDesign = question.question_type === 'System Design' || /scale|architect|design|throughput|latency/i.test(qText);

  // Progressive hints
  const hintLevel1 = isBehavioral
    ? 'Identify a concrete situation from your past projects or college coursework. Anchor it with clear stakes and technical context.'
    : isSystemDesign
    ? 'Establish requirements first: estimate read vs write throughput, latency SLA, data volume, and single points of failure.'
    : `Anchor the core definition of ${qTopic}. State what problem this primitive solves and why engineers use it.`;

  const hintLevel2 = isBehavioral
    ? 'Highlight the exact engineering action you took (not just the team). Detail tools used, decisions evaluated, and how you navigated constraints.'
    : isSystemDesign
    ? 'Propose high-level layers: Client -> CDN / Load Balancer -> Stateless App Servers -> Cache Layer (Redis) -> Relational/NoSQL Database.'
    : 'Analyze internal mechanisms and tradeoffs: discuss time/space complexity, memory footprint, or alternatives (e.g. why choose A over B).';

  const hintLevel3 = isBehavioral
    ? 'Conclude with quantifiable outcomes: metrics improved (latency reduced by X%, test coverage increased, bug resolved), and what you learned.'
    : isSystemDesign
    ? 'Address failure scenarios: circuit breakers, database read replicas, partition sharding strategies, and asynchronous queues (RabbitMQ/Kafka).'
    : 'Provide a concise production code or system example illustrating where this is applied in a real application.';

  // Standard response skeleton
  const responseSkeleton = isBehavioral
    ? `**1. Situation & Context:**\n[Describe the team, problem, and system challenge]\n\n**2. Specific Engineering Task:**\n[What were you specifically responsible for solving?]\n\n**3. Technical Actions Taken:**\n[Architectural decisions, algorithms, refactoring, or tools applied]\n\n**4. Quantified Result & Learnings:**\n[Performance improvement %, delivery outcome, key retrospective]`
    : isSystemDesign
    ? `**1. System Requirements & Scope:**\n- Functional requirements (Core APIs)\n- Non-functional (Scale, latency, 99.9% availability)\n\n**2. High-Level Architecture:**\n- Load Balancing & API Gateway\n- Microservices / App layer\n- Cache & Database tier\n\n**3. Key Trade-offs & Bottlenecks:**\n- Cache invalidation strategy\n- Database indexing & read-replica failover`
    : `**1. Foundational Definition:**\n[Clear, 1-2 sentence core definition of ${qTopic}]\n\n**2. Internal Mechanics & Trade-offs:**\n[How it works under the hood and comparison with alternatives]\n\n**3. Practical Production Example:**\n[Real-world scenario or code pattern where this is applied]`;

  return (
    <div
      className={`rounded-2xl border transition-all ${
        isDarkTheme
          ? 'bg-slate-900/90 border-slate-800 text-slate-100 shadow-xl'
          : 'bg-white border-slate-200 text-slate-800 shadow-md'
      }`}
    >
      {/* Header Bar */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <LifeBuoy className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-white">
                Live Answer Rescue
              </span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                mode === 'assessment'
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
              }`}>
                {mode === 'assessment' ? 'Hints Mode' : 'Learning Mode'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">Real-time interview assistance</p>
          </div>
        </div>

        {/* Master On/Off Switch */}
        <button
          onClick={() => setIsEnabled(!isEnabled)}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          title={isEnabled ? 'Disable Rescue' : 'Enable Rescue'}
        >
          {isEnabled ? (
            <>
              <span className="text-emerald-400 text-[11px]">Active</span>
              <ToggleRight className="w-6 h-6 text-emerald-400" />
            </>
          ) : (
            <>
              <span className="text-slate-500 text-[11px]">Off</span>
              <ToggleLeft className="w-6 h-6 text-slate-500" />
            </>
          )}
        </button>
      </div>

      {isEnabled && (
        <div className="p-4 space-y-4">
          {/* Mode Switcher Tabs */}
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800 text-xs">
            <button
              onClick={() => setMode('assessment')}
              className={`py-1.5 px-2.5 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'assessment'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5" />
              <span>Assessment Mode</span>
            </button>

            <button
              onClick={() => setMode('learning')}
              className={`py-1.5 px-2.5 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'learning'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Learning Mode</span>
            </button>
          </div>

          {/* Auto-Stuck Alert Banner */}
          {isStuckDetected && revealedHintLevel === 0 && mode === 'assessment' && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2.5 animate-in fade-in">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold text-amber-300">Taking time to gather your thoughts?</span>
                <p className="text-[11px] text-amber-200/80 leading-relaxed">
                  Live Answer Rescue can give you a starting direction without giving away the answer.
                </p>
                <button
                  onClick={() => setRevealedHintLevel(1)}
                  className="mt-1 px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] cursor-pointer transition-colors"
                >
                  Reveal Starting Hint
                </button>
              </div>
            </div>
          )}

          {/* Assessment Mode: Progressive Hint Escalation */}
          {mode === 'assessment' ? (
            <div className="space-y-2.5 text-xs">
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Progressive hints guide your problem-solving framework step-by-step while testing your independent recall.
              </p>

              {/* Hint 1 */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sky-400 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-extrabold flex items-center justify-center">1</span>
                    Direction & Core Framework
                  </span>
                  {revealedHintLevel < 1 ? (
                    <button
                      onClick={() => setRevealedHintLevel(1)}
                      className="text-[11px] font-bold text-sky-400 hover:underline cursor-pointer"
                    >
                      Unlock Hint
                    </button>
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </div>
                {revealedHintLevel >= 1 ? (
                  <p className="text-slate-200 leading-relaxed pt-1 text-[11px] animate-in fade-in">
                    {hintLevel1}
                  </p>
                ) : (
                  <p className="text-slate-500 italic text-[11px]">Hint hidden to encourage independent thinking.</p>
                )}
              </div>

              {/* Hint 2 */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-400 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-extrabold flex items-center justify-center">2</span>
                    Architectural Trade-offs
                  </span>
                  {revealedHintLevel < 2 ? (
                    <button
                      onClick={() => setRevealedHintLevel(2)}
                      disabled={revealedHintLevel < 1}
                      className={`text-[11px] font-bold ${
                        revealedHintLevel < 1 ? 'text-slate-600 cursor-not-allowed' : 'text-blue-400 hover:underline cursor-pointer'
                      }`}
                    >
                      Unlock Hint 2
                    </button>
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </div>
                {revealedHintLevel >= 2 ? (
                  <p className="text-slate-200 leading-relaxed pt-1 text-[11px] animate-in fade-in">
                    {hintLevel2}
                  </p>
                ) : (
                  <p className="text-slate-500 italic text-[11px]">Unlock Hint 1 first to reveal technical tradeoffs.</p>
                )}
              </div>

              {/* Hint 3 */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-400 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-extrabold flex items-center justify-center">3</span>
                    Concrete Example & Edge Cases
                  </span>
                  {revealedHintLevel < 3 ? (
                    <button
                      onClick={() => setRevealedHintLevel(3)}
                      disabled={revealedHintLevel < 2}
                      className={`text-[11px] font-bold ${
                        revealedHintLevel < 2 ? 'text-slate-600 cursor-not-allowed' : 'text-indigo-400 hover:underline cursor-pointer'
                      }`}
                    >
                      Unlock Hint 3
                    </button>
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </div>
                {revealedHintLevel >= 3 ? (
                  <p className="text-slate-200 leading-relaxed pt-1 text-[11px] animate-in fade-in">
                    {hintLevel3}
                  </p>
                ) : (
                  <p className="text-slate-500 italic text-[11px]">Unlock Hint 2 to view production context.</p>
                )}
              </div>

              {/* Insert Structure Outline CTA */}
              {onInsertSkeleton && (
                <button
                  onClick={() => onInsertSkeleton(responseSkeleton)}
                  className="w-full mt-2 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition-colors cursor-pointer"
                >
                  <ListPlus className="w-3.5 h-3.5 text-blue-400" />
                  <span>Insert Structured Outline Into Answer</span>
                </button>
              )}
            </div>
          ) : (
            /* Learning Mode: Full Model Walkthrough */
            <div className="space-y-3 text-xs animate-in fade-in">
              <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-800/60 text-purple-200 flex items-start gap-2">
                <BookOpen className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold text-purple-300">Learning Mode Active</span>
                  <p className="text-[11px] text-purple-200/80 leading-relaxed">
                    Study the recommended architectural structure below to understand how senior interviewers evaluate this question.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Ideal Structured Approach
                </span>
                <div className="whitespace-pre-line text-[11px] text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 font-mono">
                  {responseSkeleton}
                </div>
              </div>

              {onInsertSkeleton && (
                <button
                  onClick={() => onInsertSkeleton(responseSkeleton)}
                  className="w-full py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                >
                  <ListPlus className="w-3.5 h-3.5" />
                  <span>Use This Template in Answer</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
