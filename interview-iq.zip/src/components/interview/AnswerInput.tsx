import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';
import { Send, Mic, MicOff, AlertCircle, Sparkles } from 'lucide-react';

interface AnswerInputProps {
  value: string;
  onChange: (val: string) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  isLastQuestion: boolean;
}

export const AnswerInput: React.FC<AnswerInputProps> = ({
  value,
  onChange,
  onSubmit,
  isSubmitting,
  isLastQuestion,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);

  const words = value.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const charCount = value.length;
  const isTooShort = wordCount < 5;

  useEffect(() => {
    // Check Web Speech API support
    if (typeof window !== 'undefined') {
      const hasSpeech = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
      setSpeechSupported(hasSpeech);
    }
  }, []);

  const toggleSpeechRecognition = () => {
    if (!speechSupported) return;

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) return;

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          onChange(value ? `${value} ${transcript}` : transcript);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.warn('Speech recognition error:', err);
      setIsListening(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!isTooShort && !isSubmitting) {
        onSubmit();
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Textarea container */}
      <div className="relative rounded-2xl border border-slate-200 bg-white shadow-xs focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all overflow-hidden">
        {/* Toolbar */}
        <div className="px-4 py-2.5 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-700">Your Response</span>
            {speechSupported && (
              <button
                type="button"
                onClick={toggleSpeechRecognition}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                  isListening
                    ? 'bg-rose-100 text-rose-700 animate-pulse border border-rose-200'
                    : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-3.5 h-3.5" />
                    <span>Listening...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5 text-blue-600" />
                    <span>Dictate Answer</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="flex items-center gap-3 text-slate-400">
            <span>
              <strong className={wordCount < 10 ? 'text-amber-600' : 'text-slate-700'}>
                {wordCount}
              </strong>{' '}
              words
            </span>
            <span>•</span>
            <span>{charCount} chars</span>
          </div>
        </div>

        {/* Large Answer Textarea */}
        <textarea
          rows={9}
          value={value}
          disabled={isSubmitting}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Articulate your structured answer here. Include relevant architectural principles, technical terms, tradeoffs, or real-world experiences. (Press Ctrl+Enter to submit)"
          className="w-full p-5 text-sm md:text-base text-slate-800 placeholder-slate-400 resize-y focus:outline-none leading-relaxed bg-white"
        />

        {/* Bottom feedback hints */}
        {isTooShort && value.trim().length > 0 && (
          <div className="px-4 py-2 bg-amber-50/80 border-t border-amber-100 flex items-center gap-2 text-xs text-amber-700">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>
              Please write a more detailed response (at least 5-10 words) so the AI evaluator can accurately score your technical knowledge.
            </span>
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <div className="text-xs text-slate-400">
          Tip: You can use the STAR method (Situation, Task, Action, Result) for behavioral questions.
        </div>

        <Button
          size="lg"
          variant="primary"
          isLoading={isSubmitting}
          disabled={isTooShort || isSubmitting}
          leftIcon={<Sparkles className="w-4 h-4" />}
          rightIcon={<Send className="w-4 h-4" />}
          onClick={onSubmit}
          className="w-full sm:w-auto"
        >
          {isLastQuestion ? 'Submit & Finalize Interview' : 'Submit & Analyze Answer'}
        </Button>
      </div>
    </div>
  );
};
