import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Activity,
  AlertCircle,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { analyzeVoiceMetrics } from '../../lib/ai-client';
import { VoiceMetrics } from '../../types/database.types';

interface VoiceAnalysisProps {
  questionText: string;
  onTranscriptChange: (text: string) => void;
  onMetricsUpdate?: (metrics: VoiceMetrics) => void;
  isDarkTheme?: boolean;
}

export const VoiceAnalysisEngine: React.FC<VoiceAnalysisProps> = ({
  questionText,
  onTranscriptChange,
  onMetricsUpdate,
  isDarkTheme = true,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeakingQuestion, setIsSpeakingQuestion] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [speakingStartTime, setSpeakingStartTime] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [metrics, setMetrics] = useState<VoiceMetrics | null>(null);

  const recognitionRef = useRef<any>(null);
  const timerRef = useRef<any>(null);

  // Initialize Web Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let current = '';
      for (let i = 0; i < event.results.length; i++) {
        current += event.results[i][0].transcript + ' ';
      }
      const trimmed = current.trim();
      setLiveTranscript(trimmed);
      onTranscriptChange(trimmed);
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition event:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      if (isListening) {
        try {
          recognition.start();
        } catch {
          // ignore
        }
      }
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Timer for elapsed speaking seconds
  useEffect(() => {
    if (isListening) {
      setSpeakingStartTime(Date.now());
      timerRef.current = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      if (liveTranscript.length > 5) {
        const computed = analyzeVoiceMetrics(liveTranscript, Math.max(elapsedSeconds, 5));
        setMetrics(computed);
        if (onMetricsUpdate) onMetricsUpdate(computed);
      }
    }
  }, [isListening]);

  const toggleListening = () => {
    if (!speechSupported) {
      alert('Speech Recognition is not supported by your current browser. You can type your answer.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.warn('Recognition start error:', err);
      }
    }
  };

  // AI Voice Synthesis: Read question aloud
  const handleToggleSpeakQuestion = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeakingQuestion) {
      window.speechSynthesis.cancel();
      setIsSpeakingQuestion(false);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(questionText);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;

      utterance.onend = () => {
        setIsSpeakingQuestion(false);
      };

      utterance.onerror = () => {
        setIsSpeakingQuestion(false);
      };

      window.speechSynthesis.speak(utterance);
      setIsSpeakingQuestion(true);
    }
  };

  return (
    <div
      className={`p-4 rounded-2xl border transition-all ${
        isDarkTheme
          ? 'bg-slate-900/90 border-slate-800 text-slate-100 shadow-md backdrop-blur-md'
          : 'bg-white border-slate-200 text-slate-800 shadow-xs'
      }`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: AI Question Audio & Mic triggers */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleSpeakQuestion}
            title={isSpeakingQuestion ? 'Stop Audio' : 'Listen to AI Interviewer'}
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold cursor-pointer transition-all ${
              isSpeakingQuestion
                ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-500/30 animate-pulse'
                : isDarkTheme
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
          >
            {isSpeakingQuestion ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span>{isSpeakingQuestion ? 'Mute AI' : 'Play Question Audio'}</span>
          </button>

          <button
            onClick={toggleListening}
            className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold cursor-pointer transition-all ${
              isListening
                ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-500/30'
                : 'bg-blue-600 hover:bg-blue-500 text-white border-blue-500 shadow-md'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>{isListening ? 'Stop Voice Recording' : 'Answer with Voice (Speech-to-Text)'}</span>
          </button>
        </div>

        {/* Right: Audio Waveform Animation when listening */}
        {isListening && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/30">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping mr-1" />
            <span className="text-[11px] font-bold text-rose-400 mr-2">
              Listening ({elapsedSeconds}s)
            </span>
            <div className="flex items-end gap-1 h-4">
              <span className="w-1 bg-rose-500 rounded-full animate-bounce [animation-delay:0ms] h-2" />
              <span className="w-1 bg-rose-500 rounded-full animate-bounce [animation-delay:150ms] h-4" />
              <span className="w-1 bg-rose-500 rounded-full animate-bounce [animation-delay:300ms] h-3" />
              <span className="w-1 bg-rose-500 rounded-full animate-bounce [animation-delay:75ms] h-5" />
            </div>
          </div>
        )}
      </div>

      {/* Communication Delivery Metrics Bar (when calculated or active) */}
      {metrics && (
        <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Speaking Pace</div>
            <div className="text-base font-extrabold text-blue-400 mt-0.5">
              {metrics.timing_available ? `${metrics.wpm} WPM` : 'Typed Input'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              {metrics.timing_available ? `${metrics.duration_seconds || elapsedSeconds}s audio duration` : 'No audio timing'}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Fillers Count</div>
            <div className={`text-base font-extrabold mt-0.5 ${metrics.filler_count === 0 ? 'text-emerald-400' : metrics.filler_count <= 2 ? 'text-amber-400' : 'text-rose-400'}`}>
              {metrics.filler_count}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5 truncate">
              {metrics.filler_words.length > 0 ? metrics.filler_words.join(', ') : 'Zero fillers'}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Clarity Score</div>
            <div className="text-base font-extrabold text-sky-400 mt-0.5">{metrics.clarity_score} / 10</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Structure & articulation</div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Communication Tone</div>
            <div className="text-xs font-bold text-indigo-300 mt-1">{metrics.tone || 'Professional & Direct'}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Delivery style</div>
          </div>

          {/* Factual Communication Delivery Analysis Banner */}
          <div className="col-span-2 sm:col-span-4 text-left p-3 rounded-xl bg-gradient-to-r from-blue-900/30 via-indigo-900/20 to-slate-800 border border-blue-500/30 text-blue-200 text-xs mt-1 flex items-start gap-2.5 shadow-sm">
            <Sparkles className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="text-[10px] font-bold uppercase tracking-wider text-blue-300">
                Communication & Delivery Assessment
              </div>
              <div className="text-sm font-semibold text-white">
                {metrics.delivery_feedback || metrics.personality_verdict || 'Clear and structured delivery.'}
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {metrics.pace_feedback}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default VoiceAnalysisEngine;
