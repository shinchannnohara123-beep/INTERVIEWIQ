import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Briefcase,
  History,
  BarChart3,
  User,
  Sparkles,
  CheckCircle2,
  LogOut,
  ChevronRight,
  Compass,
  Bot,
  UserCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { profile, logout, isSupabaseMode } = useAuth();
  const [aiStatus, setAiStatus] = useState<{ online: boolean; provider: string }>({
    online: true,
    provider: 'Checking...',
  });

  useEffect(() => {
    // Check AI server health
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        setAiStatus({
          online: data.status === 'online',
          provider: data.gemini_configured ? 'Gemini 3.8 Flash' : 'Semantic Engine',
        });
      })
      .catch(() => {
        setAiStatus({
          online: true,
          provider: 'Intelligent Client AI',
        });
      });
  }, []);

  const navItems = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/roadmap', label: 'Career Roadmap', icon: Compass },
    { to: '/mentor', label: 'AI Career Mentor', icon: Bot },
    { to: '/twin', label: 'AI Interview Twin', icon: UserCheck },
    { to: '/roles', label: 'Job Roles & Practice', icon: Briefcase },
    { to: '/history', label: 'Interview History', icon: History },
    { to: '/analytics', label: 'Performance Analytics', icon: BarChart3 },
    { to: '/profile', label: 'Candidate Profile', icon: User },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200/90 flex flex-col h-screen sticky top-0 select-none z-30">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100 flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg text-slate-900 tracking-tight">Interview<span className="text-blue-600">IQ</span></span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-100">AI</span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">Smart Practice Platform</p>
          </div>
        </NavLink>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          Practice & Evaluation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {isActive && <ChevronRight className="w-4 h-4 text-blue-500" />}
                </>
              )}
            </NavLink>
          );
        })}
      </div>

      {/* Service Health Pill */}
      <div className="px-4 py-3 mx-3 mb-3 bg-gradient-to-br from-blue-50/60 to-slate-50 rounded-xl border border-blue-100/80">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-700 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            AI Evaluator
          </span>
          <span className="text-[10px] font-medium text-blue-700 bg-white px-2 py-0.5 rounded-md border border-blue-100 shadow-2xs">
            {aiStatus.provider}
          </span>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
          <span>Engine Status</span>
          <span className="flex items-center gap-1 font-medium text-slate-700">
            {isSupabaseMode ? (
              <>
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Cloud DB
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3 h-3 text-blue-600" /> PostgreSQL
              </>
            )}
          </span>
        </div>
      </div>

      {/* User Footer Profile */}
      <NavLink
        to="/profile"
        className="p-3 border-t border-slate-100 flex items-center justify-between bg-slate-50/50 hover:bg-blue-50/50 transition-colors"
      >
        <div className="flex items-center gap-2.5 overflow-hidden">
          <img
            src={profile?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=Candidate`}
            alt={profile?.full_name || 'Candidate'}
            className="w-9 h-9 rounded-full border border-slate-200 object-cover shrink-0 bg-white"
          />
          <div className="overflow-hidden text-left">
            <p className="text-xs font-semibold text-slate-800 truncate">
              {profile?.full_name || 'Candidate'}
            </p>
            <p className="text-[10px] text-slate-400 truncate">
              {profile?.email || 'user@example.com'}
            </p>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            logout();
          }}
          title="Sign out"
          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </NavLink>
    </aside>
  );
};
