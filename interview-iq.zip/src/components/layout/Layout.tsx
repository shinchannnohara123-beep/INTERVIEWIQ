import React from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  onStartInterviewClick?: () => void;
}

export const Layout: React.FC<LayoutProps> = ({
  children,
  title,
  subtitle,
  onStartInterviewClick,
}) => {
  return (
    <div className="flex min-h-screen bg-gradient-to-br from-blue-50/40 via-white to-slate-50 text-slate-900 font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          title={title}
          subtitle={subtitle}
          onStartInterviewClick={onStartInterviewClick}
        />
        <main className="flex-1 p-8 overflow-y-auto max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
