import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, PlusCircle, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  onStartInterviewClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  onStartInterviewClick,
}) => {
  const { profile, isSupabaseMode } = useAuth();
  const navigate = useNavigate();

  const handleStart = () => {
    if (onStartInterviewClick) {
      onStartInterviewClick();
    } else {
      navigate('/roles');
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200/80 px-8 flex items-center justify-between sticky top-0 z-20 shadow-2xs">
      <div>
        <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          {title || 'Practice Dashboard'}
        </h1>
        {subtitle && <p className="text-xs text-slate-500 font-normal">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-4">
        {/* Engine status badge */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100/80 text-slate-600 border border-slate-200/60">
          <Shield className="w-3.5 h-3.5 text-blue-600" />
          <span>{isSupabaseMode ? 'Supabase Live' : 'PostgreSQL Local'}</span>
        </div>

        {/* Start Interview CTA button */}
        <Button
          size="sm"
          variant="primary"
          leftIcon={<PlusCircle className="w-4 h-4" />}
          onClick={handleStart}
        >
          Start Interview
        </Button>

        {/* Clickable Profile Pill */}
        <button
          onClick={() => navigate('/profile')}
          title="View & Edit Profile"
          className="flex items-center gap-3 pl-2 border-l border-slate-200 hover:opacity-85 transition-opacity cursor-pointer text-left"
        >
          <img
            src={profile?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=Candidate`}
            alt={profile?.full_name || 'Candidate'}
            className="w-8 h-8 rounded-full border border-slate-200 object-cover bg-slate-50"
          />
          <div className="hidden lg:block">
            <p className="text-xs font-semibold text-slate-800 leading-tight">
              {profile?.full_name || 'Candidate'}
            </p>
            <p className="text-[10px] text-slate-400 leading-tight">
              {profile?.target_role || profile?.email || 'View Profile'}
            </p>
          </div>
        </button>
      </div>
    </header>
  );
};
