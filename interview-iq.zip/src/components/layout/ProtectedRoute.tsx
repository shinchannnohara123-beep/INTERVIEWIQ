import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Profile completion rule: User must create/complete profile before accessing dashboard
  const isProfileComplete = profile && profile.is_profile_completed && profile.full_name?.trim() && profile.target_role?.trim();
  if (!isProfileComplete && location.pathname !== '/profile') {
    return <Navigate to="/profile" state={{ from: location, needsProfile: true }} replace />;
  }

  return <>{children}</>;
};

