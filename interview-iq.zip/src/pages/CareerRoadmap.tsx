import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Compass,
  CheckCircle2,
  Circle,
  Plus,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Target,
  Award,
  Layers,
  Code2,
  FolderGit2,
  BrainCircuit,
  MessageSquare,
  FileCheck2,
  Briefcase,
  AlertCircle,
  TrendingUp,
  ExternalLink,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { CircularProgress } from '../components/charts/CircularProgress';
import { dbService } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { UserRoadmap, RoadmapStage } from '../types/database.types';

export const CareerRoadmap: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [roadmap, setRoadmap] = useState<UserRoadmap | null>(null);
  const [selectedRole, setSelectedRole] = useState<string>(profile?.target_role || 'Full Stack Developer');
  const [newTaskText, setNewTaskText] = useState<{ [stageId: number]: string }>({});
  const [isAddingTask, setIsAddingTask] = useState<{ [stageId: number]: boolean }>({});
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadRoadmap(user.id, selectedRole);
    }
  }, [user, selectedRole]);

  const loadRoadmap = async (userId: string, targetRole: string) => {
    const data = await dbService.getUserRoadmap(userId, targetRole);
    setRoadmap(data);
  };

  const handleToggleTask = async (stageId: number, taskId: string) => {
    if (!user) return;
    const updated = await dbService.toggleRoadmapTask(user.id, stageId, taskId);
    setRoadmap(updated);
  };

  const handleAddTask = async (stageId: number) => {
    const text = newTaskText[stageId]?.trim();
    if (!text || !user) return;

    const updated = await dbService.addCustomTaskToRoadmap(user.id, stageId, text);
    setRoadmap(updated);
    setNewTaskText(prev => ({ ...prev, [stageId]: '' }));
    setIsAddingTask(prev => ({ ...prev, [stageId]: false }));
  };

  const handleSyncWithInterviews = async () => {
    if (!user) return;
    setIsSyncing(true);
    try {
      const heatmap = await dbService.getTopicHeatmap(user.id);
      const weakTopics = heatmap.filter(h => h.status === 'weak');

      let updatedRoadmap = roadmap;
      for (const topic of weakTopics) {
        updatedRoadmap = await dbService.addSkillGapToRoadmap(user.id, topic.topic);
      }
      if (updatedRoadmap) setRoadmap({ ...updatedRoadmap });
      setSyncMessage(`Synced ${weakTopics.length} detected skill gaps into your practice stage!`);
      setTimeout(() => setSyncMessage(null), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSyncing(false);
    }
  };

  const getStageIcon = (stageId: number) => {
    switch (stageId) {
      case 1: return <Code2 className="w-5 h-5 text-blue-600" />;
      case 2: return <Layers className="w-5 h-5 text-indigo-600" />;
      case 3: return <FolderGit2 className="w-5 h-5 text-sky-600" />;
      case 4: return <BrainCircuit className="w-5 h-5 text-cyan-600" />;
      case 5: return <MessageSquare className="w-5 h-5 text-emerald-600" />;
      case 6: return <FileCheck2 className="w-5 h-5 text-amber-600" />;
      case 7: return <Briefcase className="w-5 h-5 text-violet-600" />;
      default: return <Compass className="w-5 h-5 text-blue-600" />;
    }
  };

  // Find next incomplete stage
  const nextStage = roadmap?.stages.find(s => s.progress < 100) || roadmap?.stages[0];

  return (
    <Layout
      title="Career Roadmap & Skill Gap Engine"
      subtitle="Structured 7-stage learning journey tailored to your target role and real interview results"
    >
      <div className="space-y-8 animate-in fade-in duration-200">
        {/* Top Header Card */}
        <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-700 text-white shadow-xl shadow-blue-500/15 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-3 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm border border-white/20 text-xs font-semibold tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-sky-200" />
                <span>AI-Generated Learning Pathway</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
                {selectedRole} Roadmap
              </h2>
              <p className="text-sm text-blue-100 leading-relaxed">
                Step-by-step technical mastery from fundamental data structures to corporate mock rounds and placement readiness.
              </p>

              {/* Target Role Selector */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <span className="text-xs text-blue-200 font-medium">Target Role:</span>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="bg-white/20 hover:bg-white/30 text-white font-semibold text-xs rounded-xl px-3 py-1.5 border border-white/30 backdrop-blur-md outline-none cursor-pointer transition-colors"
                >
                  <option value="Full Stack Developer" className="text-slate-900">Full Stack Developer</option>
                  <option value="Frontend Developer" className="text-slate-900">Frontend Developer</option>
                  <option value="Backend Engineer" className="text-slate-900">Backend Engineer</option>
                  <option value="Data Scientist / ML Engineer" className="text-slate-900">Data Scientist / ML Engineer</option>
                  <option value="DevOps & Cloud Engineer" className="text-slate-900">DevOps & Cloud Engineer</option>
                </select>

                <button
                  onClick={handleSyncWithInterviews}
                  disabled={isSyncing}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white text-blue-700 hover:bg-blue-50 text-xs font-bold shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>Sync Weak Skills</span>
                </button>
              </div>
            </div>

            {/* Circular Progress Meter */}
            <div className="flex items-center gap-6 bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/20">
              <CircularProgress
                value={roadmap?.overall_progress || 0}
                size={96}
                strokeWidth={9}
                label="Overall"
                sublabel="Roadmap"
              />
              <div className="space-y-1">
                <div className="text-xs text-blue-200 font-medium uppercase tracking-wider">Status</div>
                <div className="text-lg font-bold text-white">
                  {(roadmap?.overall_progress || 0) >= 80 ? 'Placement Ready' : (roadmap?.overall_progress || 0) >= 50 ? 'Accelerating' : 'Building Foundations'}
                </div>
                <div className="text-xs text-blue-100">
                  {roadmap?.stages.reduce((acc, s) => acc + s.tasks.filter(t => t.completed).length, 0)} of{' '}
                  {roadmap?.stages.reduce((acc, s) => acc + s.tasks.length, 0)} tasks complete
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sync notification message */}
        {syncMessage && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{syncMessage}</span>
          </div>
        )}

        {/* Highlight Card: Next Stage To Focus */}
        {nextStage && (
          <div className="p-5 rounded-2xl bg-white border border-blue-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">Current Focus</span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs font-semibold text-slate-600">Stage {nextStage.id} of 7</span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">
                  {nextStage.title} ({nextStage.progress}% Done)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{nextStage.description}</p>
              </div>
            </div>

            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                const element = document.getElementById(`stage-${nextStage.id}`);
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Jump to Stage
            </Button>
          </div>
        )}

        {/* Skill Gaps Auto-Detected Section (With Priority & Clickable Learning Resources) */}
        {roadmap?.skill_gaps && roadmap.skill_gaps.length > 0 && (
          <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-50/80 via-white to-amber-50/40 border border-amber-200/90 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/60 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wider">
                    Detected Skill Gaps & Actionable Learning Hub
                  </h4>
                  <p className="text-[11px] text-amber-700">
                    Prioritized based on your real interview evaluations and targeted job competencies
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSyncWithInterviews}
                disabled={isSyncing}
                className="text-xs border-amber-300 text-amber-900 hover:bg-amber-100/60 cursor-pointer"
                leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />}
              >
                {isSyncing ? 'Syncing...' : 'Sync Weak Skills'}
              </Button>
            </div>

            {/* Detailed Skill Gap Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {(roadmap.detailed_skill_gaps && roadmap.detailed_skill_gaps.length > 0
                ? roadmap.detailed_skill_gaps
                : roadmap.skill_gaps.map((gap, i) => ({
                    skill: gap,
                    priority: (i === 0 ? 'High' : i === 1 ? 'Medium' : 'Low') as 'High' | 'Medium' | 'Low',
                    category: 'Core Competency',
                    resource_title: `${gap} Reference Guide`,
                    resource_url: gap.toLowerCase().includes('sql')
                      ? 'https://use-the-index-luke.com/'
                      : gap.toLowerCase().includes('design')
                      ? 'https://github.com/donnemartin/system-design-primer'
                      : 'https://leetcode.com/explore/',
                    action_summary: `Identified gap during technical rounds. Focus on core architectural constraints and implementation patterns.`,
                  }))
              ).map((gapItem, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white border border-amber-200/80 shadow-2xs hover:shadow-sm hover:border-amber-300 transition-all flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        {gapItem.category || 'Interview Weakness'}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                          gapItem.priority === 'High'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : gapItem.priority === 'Medium'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-blue-50 text-blue-700 border-blue-200'
                        }`}
                      >
                        {gapItem.priority} Priority
                      </span>
                    </div>

                    <h5 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                      <span>{gapItem.skill}</span>
                    </h5>

                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      {gapItem.action_summary}
                    </p>
                  </div>

                  <a
                    href={gapItem.resource_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-between w-full px-3 py-2 rounded-lg bg-amber-50/70 hover:bg-amber-100/70 border border-amber-200 text-amber-900 text-[11px] font-bold transition-colors cursor-pointer group"
                  >
                    <span className="truncate mr-2">{gapItem.resource_title}</span>
                    <ExternalLink className="w-3.5 h-3.5 text-amber-600 group-hover:translate-x-0.5 transition-transform shrink-0" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7 Stages Vertical Timeline & Interactive Cards */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-600" />
              <span>Career Roadmap Stages (1 to 7)</span>
            </h3>
            <span className="text-xs text-slate-500">Check off tasks as you complete practice</span>
          </div>

          <div className="space-y-5">
            {roadmap?.stages.map((stage) => {
              const isCompleted = stage.progress === 100;
              return (
                <div
                  key={stage.id}
                  id={`stage-${stage.id}`}
                  className={`p-6 rounded-2xl bg-white border transition-all duration-200 ${
                    isCompleted
                      ? 'border-emerald-200 bg-emerald-50/10 shadow-xs'
                      : stage.id === nextStage?.id
                      ? 'border-blue-300 shadow-md ring-2 ring-blue-500/10'
                      : 'border-slate-200 shadow-xs'
                  }`}
                >
                  {/* Stage Header */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                    <div className="flex items-start gap-3.5">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0">
                        {getStageIcon(stage.id)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                            Stage {stage.id}
                          </span>
                          <span className="text-slate-300">•</span>
                          <h4 className="text-base font-bold text-slate-900">{stage.title}</h4>
                          {isCompleted ? (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              Completed ✓
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-bold">
                              {stage.progress}% Complete
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{stage.description}</p>
                      </div>
                    </div>

                    {/* Stage Progress Bar */}
                    <div className="w-full md:w-48 shrink-0 space-y-1.5">
                      <div className="flex justify-between text-[11px] font-semibold text-slate-600">
                        <span>Progress</span>
                        <span>{stage.progress}%</span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isCompleted ? 'bg-emerald-500' : 'bg-blue-600'
                          }`}
                          style={{ width: `${stage.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Skills Pills */}
                  <div className="pt-4 pb-3 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-slate-400 mr-1">Skills to master:</span>
                    {stage.skills.map((skill, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-[11px] font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* Tasks List */}
                  <div className="space-y-2.5 pt-2">
                    {stage.tasks.map((task) => (
                      <div
                        key={task.id}
                        onClick={() => handleToggleTask(stage.id, task.id)}
                        className={`p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                          task.completed
                            ? 'bg-slate-50/70 border-slate-200 text-slate-400 line-through'
                            : 'bg-white border-slate-200 hover:border-blue-300 text-slate-800 hover:shadow-2xs'
                        }`}
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          {task.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-300 hover:text-blue-500 shrink-0" />
                          )}
                          <span className="text-xs font-medium truncate">{task.title}</span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {task.tag && (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                              {task.tag}
                            </span>
                          )}
                          {task.difficulty && (
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                              task.difficulty === 'Beginner'
                                ? 'bg-emerald-50 text-emerald-700'
                                : task.difficulty === 'Intermediate'
                                ? 'bg-blue-50 text-blue-700'
                                : 'bg-purple-50 text-purple-700'
                            }`}>
                              {task.difficulty}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add Custom Task Form */}
                  <div className="pt-3">
                    {isAddingTask[stage.id] ? (
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          placeholder="e.g. Solve 5 dynamic programming grid questions..."
                          value={newTaskText[stage.id] || ''}
                          onChange={(e) =>
                            setNewTaskText((prev) => ({ ...prev, [stage.id]: e.target.value }))
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleAddTask(stage.id);
                          }}
                          className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 focus:border-blue-500 focus:outline-none"
                          autoFocus
                        />
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => handleAddTask(stage.id)}
                        >
                          Save Task
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            setIsAddingTask((prev) => ({ ...prev, [stage.id]: false }))
                          }
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <button
                        onClick={() =>
                          setIsAddingTask((prev) => ({ ...prev, [stage.id]: true }))
                        }
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors pt-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add customized task to Stage {stage.id}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default CareerRoadmap;
