import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  AlertCircle,
  ShieldAlert,
  Sparkles,
  Bot,
  Send,
  MessageSquare,
  HelpCircle,
  CheckCircle2,
  Zap,
  CornerDownRight,
  LifeBuoy,
} from 'lucide-react';
import { RealtimeImprover } from '../components/interview/RealtimeImprover';
import { VoiceAnalysisEngine } from '../components/interview/VoiceAnalysisEngine';
import { LiveAnswerRescue } from '../components/interview/LiveAnswerRescue';
import { AnalyzingLoader } from '../components/interview/AnalyzingLoader';
import { Button } from '../components/ui/Button';
import { dbService } from '../lib/supabase';
import { localDB } from '../lib/mock-db';
import { evaluateAnswer, generateFollowUpQuestion } from '../lib/ai-client';
import { useAuth } from '../context/AuthContext';
import { Question, JobRole, Interview, AIEvaluationResponse, VoiceMetrics, FollowUpQuestion } from '../types/database.types';

export const InterviewSession: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [interview, setInterview] = useState<Interview | null>(null);
  const [role, setRole] = useState<JobRole | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Answer and voice states
  const [answerText, setAnswerText] = useState<string>('');
  const [voiceMetrics, setVoiceMetrics] = useState<VoiceMetrics | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [evaluations, setEvaluations] = useState<AIEvaluationResponse[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // AI Follow-Up state
  const [activeFollowUp, setActiveFollowUp] = useState<FollowUpQuestion | null>(null);
  const [followUpAnswer, setFollowUpAnswer] = useState<string>('');
  const [isGeneratingFollowUp, setIsGeneratingFollowUp] = useState(false);
  const [hasFollowUpTriggeredForCurrent, setHasFollowUpTriggeredForCurrent] = useState(false);

  // Assistance Panel Tab
  const [sidebarTab, setSidebarTab] = useState<'rescue' | 'improver'>('rescue');

  const handleInsertSkeleton = (skeletonText: string) => {
    setAnswerText((prev) => {
      if (!prev.trim()) return skeletonText;
      return `${prev}\n\n${skeletonText}`;
    });
  };

  useEffect(() => {
    if (id) {
      loadInterviewSession(id);
    }
  }, [id, user]);

  const loadInterviewSession = async (interviewId: string) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const details = await dbService.getInterviewDetails(interviewId);
      if (details) {
        setInterview(details.interview);
        if (details.role) setRole(details.role);

        if (details.interview.status === 'completed') {
          navigate(`/result/${interviewId}`);
          return;
        }

        let activeQuestions: Question[] = [];
        const existingQs = details.answersWithEval.map(a => a.question).filter(Boolean) as Question[];
        const storedQuestions = localDB.getInterviewQuestions(interviewId);

        if (storedQuestions && storedQuestions.length > 0) {
          activeQuestions = storedQuestions;
        } else if (existingQs.length >= details.interview.total_questions) {
          activeQuestions = existingQs;
        } else {
          activeQuestions = await dbService.getDynamicQuestions({
            userId: user?.id || 'candidate',
            field: details.interview.field || 'All',
            company: details.interview.company || 'All',
            difficulty: details.interview.difficulty || 'Scaling',
            totalQuestions: details.interview.total_questions || 3,
          });
        }

        setQuestions(activeQuestions);

        const answeredCount = details.answersWithEval.length;
        if (answeredCount > 0 && answeredCount < activeQuestions.length) {
          setCurrentIndex(answeredCount);
        }
      } else {
        setErrorMessage('Interview session could not be found.');
      }
    } catch (err: any) {
      console.error('Error loading interview session:', err);
      setErrorMessage('Failed to load session details.');
    } finally {
      setIsLoading(false);
    }
  };

  const currentQuestion = questions[currentIndex];
  const isLastQuestion = currentIndex === questions.length - 1;

  // Handles primary answer submission with AI follow-up opportunity
  const handleProceedOrFollowUp = async () => {
    if (!currentQuestion || !interview || !user) return;
    if (answerText.trim().length < 5) {
      setErrorMessage('Please provide a substantive answer before submitting.');
      return;
    }

    setErrorMessage(null);

    // If answer has sufficient depth and follow-up hasn't been triggered yet, trigger dynamic follow-up!
    if (!hasFollowUpTriggeredForCurrent && answerText.trim().split(/\s+/).length >= 15) {
      setIsGeneratingFollowUp(true);
      setTimeout(() => {
        const followUp = generateFollowUpQuestion(
          currentQuestion.question_text,
          answerText,
          currentQuestion.topic
        );
        setActiveFollowUp(followUp);
        setHasFollowUpTriggeredForCurrent(true);
        setIsGeneratingFollowUp(false);
      }, 600);
      return;
    }

    // Submit answer + follow-up combined
    await finalizeAnswerSubmission();
  };

  const finalizeAnswerSubmission = async () => {
    if (!currentQuestion || !interview || !user) return;
    setIsSubmitting(true);
    setIsAnalyzing(true);

    try {
      const combinedAnswer = activeFollowUp && followUpAnswer.trim().length > 0
        ? `${answerText}\n\n[Follow-up Response]: ${followUpAnswer}`
        : answerText;

      const evalResult = await evaluateAnswer({
        question_text: currentQuestion.question_text,
        role_name: role?.name || interview.field || 'Software Engineer',
        difficulty: currentQuestion.difficulty || interview.difficulty || 'Mid-Level',
        topic: currentQuestion.topic || 'Core Technical',
        answer_text: combinedAnswer,
      });

      // Save answer and evaluation into database
      await dbService.saveAnswerAndEvaluation({
        interviewId: interview.id,
        questionId: currentQuestion.id,
        userId: user.id,
        answerText: combinedAnswer,
        evaluation: evalResult,
      });

      // Record topic score into heatmap
      await dbService.recordTopicScore(
        user.id,
        currentQuestion.topic || 'Technical Core',
        evalResult.technical_score
      );

      const updatedEvaluations = [...evaluations, evalResult];
      setEvaluations(updatedEvaluations);

      if (isLastQuestion) {
        const totalScore = updatedEvaluations.reduce((sum, item) => sum + item.overall_score, 0);
        const finalOverallScore = Math.round(totalScore / updatedEvaluations.length);

        await dbService.completeInterview({
          interviewId: interview.id,
          userId: user.id,
          roleId: role?.id || null,
          field: interview.field || 'All',
          company: interview.company || 'All',
          overallScore: finalOverallScore,
        });

        setTimeout(() => {
          navigate(`/result/${interview.id}`);
        }, 500);
      } else {
        // Advance to next question cleanly
        setCurrentIndex((prev) => prev + 1);
        setAnswerText('');
        setFollowUpAnswer('');
        setActiveFollowUp(null);
        setHasFollowUpTriggeredForCurrent(false);
      }
    } catch (err: any) {
      console.error('Submission failed:', err);
      setErrorMessage(err?.message || 'Failed to submit answer. Please try again.');
    } finally {
      setIsSubmitting(false);
      setIsAnalyzing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-3 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-semibold text-slate-300">Initializing Dark AI Interview Studio...</p>
        </div>
      </div>
    );
  }

  if (errorMessage && !currentQuestion) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
        <div className="max-w-md text-center space-y-4">
          <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto" />
          <h3 className="text-lg font-bold">{errorMessage}</h3>
          <Button variant="primary" onClick={() => navigate('/roles')}>
            Back to Role Tracks
          </Button>
        </div>
      </div>
    );
  }

  const displayRoleTitle = role?.name
    ? role.name
    : interview?.field && interview.field !== 'All'
    ? `${interview.field} Interview`
    : 'Technical Interview Track';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-[#0a0f24] to-[#0d1536] text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Top Studio Bar */}
      <header className="px-6 py-4 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              if (window.confirm('Do you want to pause this active interview? Your progress is saved.')) {
                navigate('/');
              }
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors cursor-pointer flex items-center gap-2 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-blue-400 uppercase tracking-wider">
                {displayRoleTitle}
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-300 font-medium">
                {interview?.company && interview.company !== 'All' ? `${interview.company} Round` : 'General Round'}
              </span>
            </div>
          </div>
        </div>

        {/* Question Sequence Counter & Indicator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            {questions.map((_, qIdx) => (
              <span
                key={qIdx}
                className={`h-2 rounded-full transition-all ${
                  qIdx === currentIndex
                    ? 'w-7 bg-blue-500 shadow-sm shadow-blue-500/50'
                    : qIdx < currentIndex
                    ? 'w-2.5 bg-emerald-500'
                    : 'w-2 bg-slate-700'
                }`}
              />
            ))}
          </div>

          <span className="text-xs font-bold text-slate-300 bg-slate-900 px-3 py-1 rounded-xl border border-slate-800">
            {currentIndex + 1} / {questions.length}
          </span>
        </div>
      </header>

      {/* Main Studio Body: Grid Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Question + Answer Input) (8 Cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* AI Interviewer Question Card */}
          {currentQuestion && (
            <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl relative overflow-hidden backdrop-blur-md">
              <div className="absolute right-0 top-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 space-y-4">
                {/* Badges Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400">
                      Technical Question {currentIndex + 1}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-blue-500/15 border border-blue-500/30 text-blue-300 text-[10px] font-bold">
                      {currentQuestion.topic || 'Engineering'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {currentQuestion.company && (
                      <span className="px-2.5 py-0.5 rounded-md bg-sky-500/15 border border-sky-500/30 text-sky-300 text-[10px] font-bold">
                        {currentQuestion.company} Style
                      </span>
                    )}
                    <span className="px-2.5 py-0.5 rounded-md bg-purple-500/15 border border-purple-500/30 text-purple-300 text-[10px] font-bold">
                      {currentQuestion.difficulty || 'Medium'}
                    </span>
                  </div>
                </div>

                {/* Question Text */}
                <h2 className="text-lg md:text-xl font-bold text-white leading-relaxed">
                  {currentQuestion.question_text}
                </h2>

                {/* Voice Engine Toolbar */}
                <VoiceAnalysisEngine
                  questionText={currentQuestion.question_text}
                  onTranscriptChange={(trans) => setAnswerText(trans)}
                  onMetricsUpdate={(met) => setVoiceMetrics(met)}
                  isDarkTheme={true}
                />
              </div>
            </div>
          )}

          {/* AI Analyzing State */}
          {isAnalyzing ? (
            <div className="py-12 p-8 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
              <AnalyzingLoader message="Evaluating answer depth, technical keywords, and confidence..." />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Answer Textarea */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                    <span>Your Answer (Speak or Type)</span>
                  </label>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {answerText.trim().split(/\s+/).filter(Boolean).length} words
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Explain your approach thoroughly: discuss the core definition, architecture trade-offs, internal mechanics, and real-world project scenarios..."
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-sm text-slate-100 placeholder:text-slate-600 focus:border-blue-500 focus:outline-none transition-colors font-sans leading-relaxed resize-y"
                />

                {errorMessage && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}
              </div>

              {/* Dynamic Follow-Up Question Card (If triggered) */}
              {isGeneratingFollowUp && (
                <div className="p-4 rounded-2xl bg-blue-950/50 border border-blue-800 text-xs text-blue-300 flex items-center gap-3 animate-pulse">
                  <Bot className="w-5 h-5 text-blue-400 animate-spin" />
                  <span>AI Interviewer is formulating a contextual follow-up question based on your answer...</span>
                </div>
              )}

              {activeFollowUp && (
                <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-950/80 to-indigo-950/80 border border-blue-600/50 shadow-xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-sky-400" />
                      <span className="text-xs font-bold text-sky-300 uppercase tracking-wider">
                        AI Follow-Up Question (Deep Dive)
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-bold">
                      Extra Credit
                    </span>
                  </div>

                  <p className="text-sm font-semibold text-white">
                    {activeFollowUp.question_text}
                  </p>

                  <div className="text-[11px] text-blue-300/80 flex items-center gap-1.5">
                    <CornerDownRight className="w-3.5 h-3.5 text-blue-400" />
                    <span>{activeFollowUp.context_reason}</span>
                  </div>

                  <textarea
                    rows={4}
                    value={followUpAnswer}
                    onChange={(e) => setFollowUpAnswer(e.target.value)}
                    placeholder="Provide your follow-up explanation..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-blue-400 focus:outline-none"
                  />
                </div>
              )}

              {/* Submit / Proceed Bar */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-500">
                  {activeFollowUp ? 'Follow-up ready for final grading' : 'Answering activates real-time evaluation'}
                </span>

                <Button
                  variant="primary"
                  size="lg"
                  onClick={activeFollowUp ? finalizeAnswerSubmission : handleProceedOrFollowUp}
                  isLoading={isSubmitting}
                  rightIcon={<Send className="w-4 h-4" />}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-lg shadow-blue-600/25"
                >
                  {isLastQuestion
                    ? activeFollowUp ? 'Finalize & View Results' : 'Submit & Review Round'
                    : activeFollowUp ? 'Submit & Next Question' : 'Submit Answer'}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: AI Assistance Studio (4 Cols) */}
        <div className="lg:col-span-4 sticky top-20 space-y-4">
          {/* Studio Tab Switcher */}
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs shadow-md backdrop-blur-md">
            <button
              onClick={() => setSidebarTab('rescue')}
              className={`py-2 px-3 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                sidebarTab === 'rescue'
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LifeBuoy className="w-3.5 h-3.5 text-amber-400" />
              <span>Live Rescue & Hints</span>
            </button>

            <button
              onClick={() => setSidebarTab('improver')}
              className={`py-2 px-3 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                sidebarTab === 'improver'
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>Real-Time Improver</span>
            </button>
          </div>

          {/* Active Tool Content */}
          {sidebarTab === 'rescue' ? (
            <LiveAnswerRescue
              question={currentQuestion}
              answerText={answerText}
              onInsertSkeleton={handleInsertSkeleton}
              isDarkTheme={true}
            />
          ) : (
            <RealtimeImprover
              answerText={answerText}
              questionText={currentQuestion?.question_text || ''}
              topic={currentQuestion?.topic}
              isDarkTheme={true}
            />
          )}
        </div>
      </main>
    </div>
  );
};
export default InterviewSession;
