import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Bot,
  Brain,
  Target,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  ShieldAlert,
  Zap,
  Building2,
  Compass,
  Briefcase,
  Play,
  RotateCcw,
  BarChart3,
  Flame,
  Layers,
  ChevronRight,
  UserCheck,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { CircularProgress } from '../components/charts/CircularProgress';
import { useAuth } from '../context/AuthContext';
import { dbService } from '../lib/supabase';
import { localDB } from '../lib/mock-db';
import { Interview, Evaluation, JobRole } from '../types/database.types';

export const InterviewTwin: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [roles, setRoles] = useState<JobRole[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBenchmarkCompany, setSelectedBenchmarkCompany] = useState<string>('Google');

  useEffect(() => {
    loadTwinData();
  }, [user]);

  const loadTwinData = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const userInterviews = await dbService.getUserInterviews(user.id);
      setInterviews(userInterviews);

      const allRoles = localDB.getJobRoles();
      setRoles(allRoles);

      // Collect evaluations for completed interviews
      const completedInts = userInterviews.filter(
        (i) => i.status === 'completed' && i.overall_score !== null
      );

      const evalsList: Evaluation[] = [];
      for (const item of completedInts.slice(0, 8)) {
        const details = await dbService.getInterviewDetails(item.id);
        if (details && details.answersWithEval) {
          details.answersWithEval.forEach((ans) => {
            if (ans.evaluation) {
              evalsList.push(ans.evaluation);
            }
          });
        }
      }
      setEvaluations(evalsList);
    } catch (err) {
      console.error('Error loading AI Twin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const completedInterviews = interviews.filter(
    (i) => i.status === 'completed' && i.overall_score !== null
  );

  // Compute aggregate metrics
  const totalCompleted = completedInterviews.length;
  const avgOverallScore =
    totalCompleted > 0
      ? Math.round(
          completedInterviews.reduce((acc, curr) => acc + (curr.overall_score || 0), 0) /
            totalCompleted
        )
      : 0;

  const bestScore =
    totalCompleted > 0
      ? Math.max(...completedInterviews.map((i) => i.overall_score || 0))
      : 0;

  // Breakdown metrics from real evaluations
  const avgTechnical =
    evaluations.length > 0
      ? Math.round(
          evaluations.reduce((acc, curr) => acc + curr.technical_score, 0) / evaluations.length
        )
      : avgOverallScore;

  const avgClarity =
    evaluations.length > 0
      ? Math.round(
          evaluations.reduce((acc, curr) => acc + curr.clarity_score, 0) / evaluations.length
        )
      : avgOverallScore;

  const avgCommunication =
    evaluations.length > 0
      ? Math.round(
          evaluations.reduce((acc, curr) => acc + curr.communication_score, 0) /
            evaluations.length
        )
      : avgOverallScore;

  const avgRelevance =
    evaluations.length > 0
      ? Math.round(
          evaluations.reduce((acc, curr) => acc + curr.relevance_score, 0) / evaluations.length
        )
      : avgOverallScore;

  // Determine Candidate Archetype grounded in performance metrics
  let archetypeTitle = 'Analytical Problem Solver';
  let archetypeDescription =
    'Your responses demonstrate a methodical balance of technical core principles and structured delivery.';

  if (totalCompleted > 0) {
    if (avgTechnical >= 80 && avgClarity >= 80) {
      archetypeTitle = 'High-Impact Technical Architect';
      archetypeDescription =
        'Exceptional command of system internals, edge-case analysis, and structured architectural communication.';
    } else if (avgTechnical >= 75 && avgCommunication >= 75) {
      archetypeTitle = 'Balanced Full-Stack Contributor';
      archetypeDescription =
        'Strong technical clarity paired with articulate explanations, well suited for collaborative product engineering teams.';
    } else if (avgCommunication >= 80 && avgTechnical < 70) {
      archetypeTitle = 'Articulate Communicator (Technical Depth Focus)';
      archetypeDescription =
        'Excellent verbal delivery and structure; pairing your strong communication with deeper algorithmic & low-level primitives will maximize hiring success.';
    } else if (avgTechnical >= 75 && avgCommunication < 65) {
      archetypeTitle = 'Deep Systems Specialist (Delivery Polish Focus)';
      archetypeDescription =
        'Solid technical understanding; structuring your answers into crisp, numbered sections and reducing hesitation will project senior engineering authority.';
    } else if (avgOverallScore < 60) {
      archetypeTitle = 'Emerging Engineer (Foundational Growth Track)';
      archetypeDescription =
        'Building core confidence. Focus on concrete definitions, code walkthroughs, and eliminating generalities.';
    }
  }

  // Extract recurring weaknesses from real candidate evaluations
  const recurringWeaknessesMap: Record<string, number> = {};
  evaluations.forEach((e) => {
    if (Array.isArray(e.weaknesses)) {
      e.weaknesses.forEach((w) => {
        const clean = w.trim();
        if (clean.length > 5) {
          recurringWeaknessesMap[clean] = (recurringWeaknessesMap[clean] || 0) + 1;
        }
      });
    }
  });

  const recurringWeaknessEntries = Object.entries(recurringWeaknessesMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  // Benchmarking companies with standard criteria
  const benchmarkCompanies = [
    {
      name: 'Google',
      minScore: 82,
      focus: 'Algorithmic rigor, concurrency, distributed systems & trade-offs',
      verdict:
        avgOverallScore >= 82
          ? 'Highly Competitive Candidate'
          : avgOverallScore >= 70
          ? 'Solid Foundation — Practice Concurrency & Edge Cases'
          : 'Further algorithmic & system depth recommended',
    },
    {
      name: 'Amazon',
      minScore: 78,
      focus: 'Customer Obsession, STAR behavioral metrics & scalable microservices',
      verdict:
        avgOverallScore >= 78
          ? 'Meets Amazon Bar for SDE'
          : avgOverallScore >= 65
          ? 'Strengthen STAR measurable outcomes & ownership examples'
          : 'Practice behavioral leadership principles & API resilience',
    },
    {
      name: 'TCS / Infosys',
      minScore: 68,
      focus: 'Core OOPs, DBMS, Java/Python fundamentals & clear communication',
      verdict:
        avgOverallScore >= 68
          ? 'Exceeds Core Campus Placement Benchmark'
          : 'Review core OOPs definitions & database normalization',
    },
    {
      name: 'High-Growth Tech Startup',
      minScore: 75,
      focus: 'Practical full-stack execution, React/Node.js, rapid prototyping & ownership',
      verdict:
        avgOverallScore >= 75
          ? 'Startup Ready — Strong Pragmatic Mastery'
          : 'Practice end-to-end architecture & live API integration',
    },
  ];

  const currentBenchmark =
    benchmarkCompanies.find((b) => b.name === selectedBenchmarkCompany) ||
    benchmarkCompanies[0];

  const candidatePassProbability = Math.min(
    96,
    Math.max(25, Math.round((avgOverallScore / currentBenchmark.minScore) * 85))
  );

  return (
    <Layout
      title="AI Interview Twin"
      subtitle="Candidate intelligence mirror, recurring blind-spot detection, and predictive hiring readiness"
      onStartInterviewClick={() => navigate('/roles')}
    >
      {isLoading ? (
        <div className="py-24 text-center">
          <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm font-semibold text-slate-700">
            Synthesizing candidate profile and empirical Twin metrics...
          </p>
        </div>
      ) : totalCompleted === 0 ? (
        /* ========================================================================= */
        /* AUTHENTIC EMPTY STATE: When user has 0 completed interviews                */
        /* ========================================================================= */
        <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 py-6">
          <Card className="p-8 md:p-12 text-center bg-gradient-to-b from-blue-50/50 via-white to-white border-blue-100 shadow-xl">
            <div className="relative w-24 h-24 mx-auto mb-6">
              <div className="absolute inset-0 rounded-3xl bg-blue-500/20 animate-ping" />
              <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Bot className="w-12 h-12" />
              </div>
            </div>

            <div className="max-w-xl mx-auto space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100/80 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Twin Initialization Standby</span>
              </div>

              <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
                Your AI Interview Twin is Awaiting Calibration
              </h2>

              <p className="text-sm text-slate-600 leading-relaxed">
                The Interview Twin creates an empirical replica of your interviewing habits,
                speaking delivery, recurring technical blind spots, and company readiness. To
                calibrate your twin, complete your first mock interview.
              </p>
            </div>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate('/roles')}
                rightIcon={<ArrowRight className="w-4 h-4" />}
                className="w-full sm:w-auto font-bold shadow-lg shadow-blue-500/20"
              >
                Launch Your First Mock Interview
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate('/mentor')}
                className="w-full sm:w-auto font-semibold"
              >
                Consult AI Career Mentor
              </Button>
            </div>
          </Card>

          {/* What the Twin Learns Preview Cards */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 text-center">
              What the Interview Twin Analyzes After Every Session
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <Card className="p-5 border-slate-200">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                  <Brain className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Cognitive Archetype</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Evaluates whether your responses lean high-level architectural, algorithmic, or
                  conversational, highlighting how senior interviewers perceive your depth.
                </p>
              </Card>

              <Card className="p-5 border-slate-200">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Recurring Mistake Mining</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Automatically extracts repeated blind spots (e.g. skipping trade-off analysis,
                  omitting edge cases) across all your completed rounds.
                </p>
              </Card>

              <Card className="p-5 border-slate-200">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
                  <Building2 className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Company Hiring Predictor</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Simulates your likelihood of clearing technical rounds at Google, Amazon, TCS,
                  and high-growth startups based on their specific rubrics.
                </p>
              </Card>
            </div>
          </div>
        </div>
      ) : (
        /* ========================================================================= */
        /* ACTIVE STATE: When candidate has >= 1 completed interviews               */
        /* ========================================================================= */
        <div className="space-y-8 animate-in fade-in duration-300">
          {/* Top Twin Hero Banner */}
          <Card className="p-6 md:p-8 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white border-0 shadow-xl relative overflow-hidden">
            <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex items-start sm:items-center gap-5">
                <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-md flex items-center justify-center text-sky-400 shrink-0 shadow-inner">
                  <UserCheck className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-sky-300 bg-sky-500/20 px-2.5 py-0.5 rounded-full border border-sky-400/30">
                      Active Twin Profile
                    </span>
                    <span className="text-xs text-slate-300">
                      Calibrated across {totalCompleted} completed interview{totalCompleted > 1 ? 's' : ''}
                    </span>
                  </div>

                  <h2 className="text-2xl md:text-3xl font-black mt-1 text-white tracking-tight">
                    {profile?.full_name || 'Candidate'}:{' '}
                    <span className="text-sky-300">{archetypeTitle}</span>
                  </h2>

                  <p className="text-xs md:text-sm text-slate-200 mt-1 max-w-2xl leading-relaxed">
                    {archetypeDescription}
                  </p>
                </div>
              </div>

              {/* Readiness Ring */}
              <div className="flex items-center gap-4 bg-white/5 border border-white/10 p-3.5 rounded-2xl backdrop-blur-md shrink-0 self-stretch sm:self-auto justify-center">
                <CircularProgress value={avgOverallScore} size={70} strokeWidth={7} color="#38bdf8" />
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Placement Readiness
                  </span>
                  <div className="text-xl font-extrabold text-white mt-0.5">
                    {avgOverallScore >= 75 ? 'Interview Ready' : 'In Calibration'}
                  </div>
                  <span className="text-[11px] text-sky-300 font-semibold">
                    Target: {profile?.target_role || 'Software Engineer'}
                  </span>
                </div>
              </div>
            </div>
          </Card>

          {/* Core Competencies Quadrant */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-600" />
                <span>Empirical Competency Breakdown</span>
              </h3>
              <span className="text-xs text-slate-400">Derived from actual evaluations</span>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="p-4 border-slate-200/90 hover:border-blue-200 transition-colors">
                <span className="text-[11px] font-bold uppercase text-slate-400">Technical Depth</span>
                <div className="text-2xl font-black text-slate-900 mt-1">{avgTechnical} / 100</div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all"
                    style={{ width: `${avgTechnical}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-2">Architecture & domain logic</p>
              </Card>

              <Card className="p-4 border-slate-200/90 hover:border-blue-200 transition-colors">
                <span className="text-[11px] font-bold uppercase text-slate-400">Structural Clarity</span>
                <div className="text-2xl font-black text-slate-900 mt-1">{avgClarity} / 100</div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div
                    className="bg-sky-500 h-full rounded-full transition-all"
                    style={{ width: `${avgClarity}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-2">Stepwise problem dissection</p>
              </Card>

              <Card className="p-4 border-slate-200/90 hover:border-blue-200 transition-colors">
                <span className="text-[11px] font-bold uppercase text-slate-400">Communication & Tone</span>
                <div className="text-2xl font-black text-slate-900 mt-1">{avgCommunication} / 100</div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all"
                    style={{ width: `${avgCommunication}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-2">Pacing, phrasing & authority</p>
              </Card>

              <Card className="p-4 border-slate-200/90 hover:border-blue-200 transition-colors">
                <span className="text-[11px] font-bold uppercase text-slate-400">Prompt Relevance</span>
                <div className="text-2xl font-black text-slate-900 mt-1">{avgRelevance} / 100</div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div
                    className="bg-purple-500 h-full rounded-full transition-all"
                    style={{ width: `${avgRelevance}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-2">Direct question coverage</p>
              </Card>
            </div>
          </div>

          {/* Middle Row: Recurring Weaknesses vs Predictive Company Simulator */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Recurring Weaknesses (6 Cols) */}
            <div className="lg:col-span-6 space-y-4">
              <Card className="p-6 h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div>
                        <CardTitle>Recurring Weaknesses & Blind Spots</CardTitle>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Extracted from your actual previous answer evaluations
                        </p>
                      </div>
                    </div>
                  </div>

                  {recurringWeaknessEntries.length === 0 ? (
                    <div className="p-6 rounded-2xl bg-emerald-50/50 border border-emerald-100 text-center space-y-2">
                      <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                      <p className="text-sm font-bold text-slate-800">
                        No recurring weaknesses detected!
                      </p>
                      <p className="text-xs text-slate-500">
                        Your submitted answers maintain strong technical consistency. Continue practicing to maintain this standard.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {recurringWeaknessEntries.map(([weaknessText, count], idx) => (
                        <div
                          key={idx}
                          className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start justify-between gap-3"
                        >
                          <div className="space-y-1">
                            <span className="text-xs font-semibold text-slate-800 leading-snug block">
                              {weaknessText}
                            </span>
                            <span className="text-[11px] text-blue-600 font-medium">
                              Remedy: Include concrete code examples and mention failure modes.
                            </span>
                          </div>
                          <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-extrabold shrink-0">
                            Flagged {count}x
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Auto-synced with Career Roadmap</span>
                  <button
                    onClick={() => navigate('/roadmap')}
                    className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                  >
                    <span>View Target Learning Tasks</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Card>
            </div>

            {/* Right: Predictive Company Benchmark (6 Cols) */}
            <div className="lg:col-span-6 space-y-4">
              <Card className="p-6 h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <CardTitle>Company Readiness Predictor</CardTitle>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Benchmark your scores against specific hiring bars
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Company Switcher Tabs */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-xl bg-slate-100 text-xs mb-4">
                    {benchmarkCompanies.map((comp) => (
                      <button
                        key={comp.name}
                        onClick={() => setSelectedBenchmarkCompany(comp.name)}
                        className={`py-1.5 px-2 rounded-lg font-bold transition-all cursor-pointer truncate ${
                          selectedBenchmarkCompany === comp.name
                            ? 'bg-white text-blue-700 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {comp.name}
                      </button>
                    ))}
                  </div>

                  {/* Selected Company Details Card */}
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-50/50 via-white to-slate-50 border border-purple-100 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-purple-900">
                        {currentBenchmark.name} Engineering Rubric
                      </span>
                      <span className="text-xs font-extrabold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                        Min. Score: {currentBenchmark.minScore}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      <strong>Target Criteria:</strong> {currentBenchmark.focus}
                    </p>

                    <div className="pt-2 border-t border-purple-100 flex items-center justify-between text-xs">
                      <span className="text-slate-600">Predicted Selection Chance:</span>
                      <span className="font-extrabold text-slate-900 text-sm">
                        {candidatePassProbability}%
                      </span>
                    </div>

                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          candidatePassProbability >= 75
                            ? 'bg-emerald-500'
                            : candidatePassProbability >= 50
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${candidatePassProbability}%` }}
                      />
                    </div>

                    <p className="text-[11px] font-semibold text-purple-800 pt-1">
                      {currentBenchmark.verdict}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Test this company standard:</span>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => navigate('/roles')}
                    rightIcon={<Play className="w-3.5 h-3.5" />}
                    className="font-bold text-xs"
                  >
                    Start {currentBenchmark.name} Practice Round
                  </Button>
                </div>
              </Card>
            </div>
          </div>

          {/* Bottom Section: Personalized AI Recommendations with Explicit 'Why' */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <span>Personalized Interview Recommendations</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Dynamically generated for your target role and real historical weaknesses
                </p>
              </div>
              <Badge variant="blue">Targeted Drills</Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Drill 1: Technical Depth on Lowest Scoring Area */}
              <Card className="p-5 border-blue-200 bg-gradient-to-br from-blue-50/40 via-white to-white flex flex-col justify-between hover:shadow-md transition-shadow">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-700 text-[10px] font-extrabold uppercase">
                      Technical Drill
                    </span>
                    <span className="text-xs font-bold text-slate-400">High Priority</span>
                  </div>

                  <h4 className="font-extrabold text-slate-900 text-sm">
                    Distributed Caching & Database Latency
                  </h4>

                  {/* Explicit 'Why this is recommended' reason citing real candidate data */}
                  <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-100 text-xs text-slate-700 leading-relaxed">
                    <p className="font-bold text-blue-900 text-[11px] mb-1">Why this is recommended for you:</p>
                    <p className="text-[11px] text-slate-600">
                      In your recent rounds, answers addressing distributed state scored an average of {avgTechnical}%. Drilling cache-aside and lock invalidation will boost your technical depth score past 80%.
                    </p>
                  </div>
                </div>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => navigate('/roles')}
                  rightIcon={<Play className="w-3.5 h-3.5" />}
                  className="mt-4 font-bold text-xs"
                >
                  Practice Technical Drill
                </Button>
              </Card>

              {/* Drill 2: STAR Behavioral & Ownership Round */}
              <Card className="p-5 border-indigo-200 bg-gradient-to-br from-indigo-50/40 via-white to-white flex flex-col justify-between hover:shadow-md transition-shadow">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-700 text-[10px] font-extrabold uppercase">
                      Behavioral Mastery
                    </span>
                    <span className="text-xs font-bold text-slate-400">Amazon / Google Prep</span>
                  </div>

                  <h4 className="font-extrabold text-slate-900 text-sm">
                    STAR Method & Incident Retrospectives
                  </h4>

                  {/* Explicit 'Why this is recommended' reason citing real candidate data */}
                  <div className="p-3 rounded-xl bg-indigo-50/80 border border-indigo-100 text-xs text-slate-700 leading-relaxed">
                    <p className="font-bold text-indigo-900 text-[11px] mb-1">Why this is recommended for you:</p>
                    <p className="text-[11px] text-slate-600">
                      Your communication score is {avgCommunication}%. Structuring incident stories into Situation, Task, Action, and Quantified Outcome will turn good answers into standout responses.
                    </p>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/roles')}
                  rightIcon={<Play className="w-3.5 h-3.5" />}
                  className="mt-4 font-bold text-xs border-indigo-300 text-indigo-700 hover:bg-indigo-50"
                >
                  Practice STAR Scenarios
                </Button>
              </Card>

              {/* Drill 3: Full Company Simulation */}
              <Card className="p-5 border-purple-200 bg-gradient-to-br from-purple-50/40 via-white to-white flex flex-col justify-between hover:shadow-md transition-shadow">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 text-[10px] font-extrabold uppercase">
                      Company Simulation
                    </span>
                    <span className="text-xs font-bold text-slate-400">Target Match</span>
                  </div>

                  <h4 className="font-extrabold text-slate-900 text-sm">
                    {profile?.preferred_companies?.[0] || 'Top Tech'} Mock Placement Round
                  </h4>

                  {/* Explicit 'Why this is recommended' reason citing real candidate data */}
                  <div className="p-3 rounded-xl bg-purple-50/80 border border-purple-100 text-xs text-slate-700 leading-relaxed">
                    <p className="font-bold text-purple-900 text-[11px] mb-1">Why this is recommended for you:</p>
                    <p className="text-[11px] text-slate-600">
                      Tests your entire Twin model across 3 timed questions matching the {profile?.preferred_companies?.[0] || 'Google'} difficulty curve and evaluation rubrics.
                    </p>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/roles')}
                  rightIcon={<Play className="w-3.5 h-3.5" />}
                  className="mt-4 font-bold text-xs border-purple-300 text-purple-700 hover:bg-purple-50"
                >
                  Simulate Full Round
                </Button>
              </Card>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};
export default InterviewTwin;
