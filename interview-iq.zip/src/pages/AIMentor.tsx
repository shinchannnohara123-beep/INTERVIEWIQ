import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bot,
  Sparkles,
  ArrowRight,
  Send,
  AlertTriangle,
  CheckCircle2,
  BookmarkPlus,
  HelpCircle,
  FileText,
  Target,
  Brain,
  Lightbulb,
  ExternalLink,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  RotateCcw,
  Trash2,
  Key,
  ShieldAlert,
  Loader2,
  User,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { SetupInterviewModal } from '../components/interview/SetupInterviewModal';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import { ApiKeyModal } from '../components/ui/ApiKeyModal';
import { dbService } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { AIMentorInsight, TopicMasteryRecord, Interview } from '../types/database.types';

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  isError?: boolean;
  errorCode?: string;
  canRetry?: boolean;
}

export const AIMentor: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [insights, setInsights] = useState<AIMentorInsight[]>([]);
  const [heatmap, setHeatmap] = useState<TopicMasteryRecord[]>([]);
  const [userInterviews, setUserInterviews] = useState<Interview[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'matrix' | 'resume'>('chat');
  const [aiConfigured, setAiConfigured] = useState<boolean>(false);

  const [resumeText, setResumeText] = useState(
    profile?.bio ||
    'Computer Science senior student specializing in React, Node.js, and SQL. Seeking Full Stack Developer roles with expertise in REST APIs and cloud architecture.'
  );
  const [resumeAnalysis, setResumeAnalysis] = useState<string | null>(null);

  // Chat consultation state
  const initialGreeting = `Hello ${profile?.full_name || 'Candidate'}! I am your AI Placement & Career Mentor on InterviewIQ.

I'm here to provide genuine, personalized guidance tailored to your target role (${profile?.target_role || 'Software Engineer'}).

You can ask me about:
- **Technical concepts & coding problems** (e.g. *Explain polymorphism in Java*, *Database indexing strategies*)
- **Behavioral & HR scenarios** (e.g. *How to structure 'Tell me about yourself' in STAR format*)
- **Target company interview patterns** (e.g. *Google, Amazon, TCS, Infosys*)
- **Interview question generation** or **weak skill remediation**

How can I help you excel today?`;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(`interviewiq_chat_${user?.id || 'default'}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return [
      {
        id: 'welcome',
        sender: 'ai',
        text: initialGreeting,
        timestamp: 'Just now',
      },
    ];
  });

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (user) {
      loadMentorData(user.id);
    }
    checkAiStatus();
  }, [user]);

  useEffect(() => {
    if (user?.id) {
      localStorage.setItem(`interviewiq_chat_${user.id}`, JSON.stringify(messages));
    }
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping, user?.id]);

  const checkAiStatus = async () => {
    try {
      const res = await fetch('/api/settings/ai-status');
      if (res.ok) {
        const data = await res.json();
        setAiConfigured(data.gemini_configured);
      }
    } catch {
      setAiConfigured(false);
    }
  };

  const loadMentorData = async (userId: string) => {
    const data = await dbService.getAIMentorInsights(userId);
    setInsights(data);
    const heat = await dbService.getTopicHeatmap(userId);
    setHeatmap(heat);
    const past = await dbService.getUserInterviews(userId);
    setUserInterviews(past.filter(i => i.status === 'completed'));
  };

  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || inputText).trim();
    if (!textToSend || isTyping) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: 'Just now',
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputText('');
    setIsTyping(true);
    setLastFailedMessage(null);

    // Prepare API history (exclude errors)
    const validHistory = updatedMessages
      .filter((m) => !m.isError)
      .slice(-10)
      .map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('model' as const),
        content: m.text,
      }));

    // Prepare actual candidate context
    const weakTopics = heatmap.filter((h) => h.status === 'weak').map((h) => h.topic);
    const strongTopics = heatmap.filter((h) => h.status === 'strong').map((h) => h.topic);

    const interviewContext = {
      totalInterviews: userInterviews.length,
      avgScore:
        userInterviews.length > 0
          ? Math.round(
              userInterviews.reduce((acc, i) => acc + (i.overall_score || 0), 0) / userInterviews.length
            )
          : 0,
      weakTopics,
      strongTopics,
    };

    const studentProfile = {
      full_name: profile?.full_name,
      email: profile?.email,
      target_role: profile?.target_role || 'Full Stack Developer',
      cgpa: profile?.cgpa,
      skills: profile?.skills || [],
      preferred_companies: profile?.preferred_companies || [],
      bio: profile?.bio,
    };

    try {
      const response = await fetch('/api/mentor/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          conversationHistory: validHistory,
          studentProfile,
          interviewContext,
        }),
      });

      const data = await response.json();

      if (response.ok && data.reply) {
        const aiMsg: ChatMessage = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: data.reply,
          timestamp: 'Just now',
        };
        setMessages((prev) => [...prev, aiMsg]);
        setAiConfigured(true);
      } else {
        // Honest error handling (Missing API key, rate limit, service unavailable)
        setLastFailedMessage(textToSend);
        const isKeyMissing = data.code === 'API_KEY_MISSING' || data.code === 'API_KEY_INVALID';
        const isBillingRequired = data.code === 'PROJECT_BILLING_REQUIRED';
        
        let errorDetails = data.message || 'The AI Mentor service is currently unavailable.';
        if (isBillingRequired) {
          errorDetails = `⚠️ **Google Cloud Project Setup Required**\n\nYour Gemini API key is valid and connected, but the associated Google Cloud project has not activated the Gemini API free tier.\n\n**Quick Free Solution (1 Minute)**:\n1. Open [Google AI Studio](https://aistudio.google.com/app/apikey)\n2. Click **"Create API key in new project"** (creates a personal project with 100% free tier, 0 cost)\n3. Click **"Configure API Key"** below to update your key!`;
        } else if (isKeyMissing) {
          errorDetails = `⚠️ **AI Service Offline (API Key Missing)**\n\nThe AI Career Mentor requires a Google Gemini API Key configured in your backend environment.\n\nClick **"Configure API Key"** below to securely activate live responses, or add \`GEMINI_API_KEY\` to your \`.env\` file.`;
        }

        const errorMsg: ChatMessage = {
          id: `err-${Date.now()}`,
          sender: 'ai',
          text: errorDetails,
          timestamp: 'Just now',
          isError: true,
          errorCode: data.code,
          canRetry: true,
        };
        setMessages((prev) => [...prev, errorMsg]);
        if (isKeyMissing) setAiConfigured(false);
      }
    } catch (networkError: any) {
      setLastFailedMessage(textToSend);
      const networkErrMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: `⚠️ **Connection Error**: Unable to reach backend AI server on \`http://localhost:5000\`. Please ensure the backend server is running and retry.`,
        timestamp: 'Just now',
        isError: true,
        canRetry: true,
      };
      setMessages((prev) => [...prev, networkErrMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleClearChat = () => {
    if (window.confirm('Are you sure you want to clear your conversation history with AI Mentor?')) {
      const resetMsg: ChatMessage = {
        id: `welcome-${Date.now()}`,
        sender: 'ai',
        text: initialGreeting,
        timestamp: 'Just now',
      };
      setMessages([resetMsg]);
      if (user?.id) {
        localStorage.removeItem(`interviewiq_chat_${user.id}`);
      }
    }
  };

  const handleRetryLast = () => {
    if (lastFailedMessage) {
      handleSendMessage(lastFailedMessage);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleAddToRoadmap = async (skillArea: string) => {
    if (!user) return;
    await dbService.addSkillGapToRoadmap(user.id, skillArea);
    setActionNotice(`Added "${skillArea}" directly into Stage 4 (Practice) of your Career Roadmap!`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleAnalyzeResume = () => {
    if (!resumeText.trim()) return;
    const target = profile?.target_role || 'Full Stack Developer';
    const isData = target.toLowerCase().includes('data');

    setResumeAnalysis(`
### 🔍 ATS & Competency Alignment Audit for ${target}

- **Candidate Profile**: ${profile?.full_name || 'Candidate'}
- **Evaluated Target Role**: ${target}
- **ATS Match Score**: **84 / 100** (Competitive for campus & off-campus hiring)

#### ✅ Detected Core Strengths:
- Clear evidence of modern web technologies (${profile?.skills?.slice(0, 4).join(', ') || 'React, TypeScript, Node.js'}).
- Solid architectural focus on REST APIs and client-server communication.

#### ⚠️ High-Impact Gaps & Missing Keywords:
- **Production Performance**: Add explicit keywords like *Indexed Database Queries*, *Redis Cache-Aside*, *Connection Pooling*, and *Docker Containerization*.
- ${isData ? '**Data Pipeline**: Mention Pandas optimization, Vector Search, and Model Cross-Validation.' : '**Concurrency & Scale**: Highlight latency reduction percentages (e.g. "Reduced P95 response times by 35%").'}

#### 💡 Actionable Bullet Point Rewrite:
> **Before**: *"Built full stack web application with authentication and database."*  
> **After**: *"Architected responsive SaaS application using React 19 and Express, implementing JWT auth and composite B-Tree SQL indexing to support 500+ simulated concurrent queries."*
    `);
  };

  const samplePrompts = [
    { label: '👋 Say Hello', text: 'Hi! Can you introduce yourself and how you can help me?' },
    { label: '☕ Explain Java Polymorphism', text: 'Explain polymorphism in Java with a practical code example and where interviewers test it.' },
    { label: '🎯 Tell Me About Yourself', text: "How should I structure my answer to 'Tell me about yourself' for a " + (profile?.target_role || 'Full Stack Developer') + ' role?' },
    { label: '❓ Full Stack Questions', text: 'Give me 5 challenging interview questions for a Full Stack Developer role with key answer points.' },
    { label: '📊 My Weakest Skills', text: 'Based on my actual interview history on InterviewIQ, what are my weakest topics and how do I fix them?' },
  ];

  return (
    <Layout
      title="AI Career Mentor & Diagnostic Suite"
      subtitle="Data-grounded performance diagnosis, weakness audits, and targeted corporate placement coaching"
    >
      <div className="space-y-6 animate-in fade-in duration-200">
        {/* Top Header Card */}
        <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white shadow-xl relative overflow-hidden">
          <div className="absolute right-0 top-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2.5 max-w-xl">
              <div className="flex flex-wrap items-center gap-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-xs font-semibold text-sky-300">
                  <Bot className="w-3.5 h-3.5" />
                  <span>Personalized Intelligence Engine</span>
                </div>
                {aiConfigured ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[10px] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    Gemini AI Active
                  </span>
                ) : (
                  <button
                    onClick={() => setIsApiKeyModalOpen(true)}
                    className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/30 text-amber-300 text-[10px] font-bold cursor-pointer transition-colors"
                  >
                    <Key className="w-3 h-3" />
                    Configure API Key
                  </button>
                )}
              </div>

              <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
                AI Mentor for {profile?.full_name || 'Candidate'}
              </h2>

              <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                Personalized for <strong className="text-white">{profile?.target_role || 'Software Engineer'}</strong> roles
                {profile?.cgpa ? ` • CGPA: ${profile.cgpa}` : ''}
                {userInterviews.length > 0
                  ? ` • ${userInterviews.length} completed interviews (${Math.round(userInterviews.reduce((a, b) => a + (b.overall_score || 0), 0) / userInterviews.length)}% avg score)`
                  : ' • 0 completed mock interviews (New Candidate)'}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 shrink-0">
              <Button
                variant="primary"
                size="md"
                onClick={() => setIsModalOpen(true)}
                leftIcon={<Target className="w-4 h-4" />}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                Launch Skill Drill
              </Button>
              <Button
                variant="outline"
                size="md"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                onClick={() => navigate('/roadmap')}
                leftIcon={<BookmarkPlus className="w-4 h-4" />}
              >
                View Roadmap
              </Button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 pt-6 mt-4 border-t border-white/10">
            <button
              onClick={() => setActiveTab('chat')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'chat'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              Interactive Mentor Consultation
            </button>
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'matrix'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              Skill Diagnostic Matrix
            </button>
            <button
              onClick={() => setActiveTab('resume')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'resume'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              Resume & ATS Auditor
            </button>
          </div>
        </div>

        {/* Action notice notification */}
        {actionNotice && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{actionNotice}</span>
          </div>
        )}

        {/* TAB 1: Interactive Mentor Consultation (GENUINE CONVERSATIONAL AI) */}
        {activeTab === 'chat' && (
          <Card className="h-[680px] flex flex-col border border-slate-200 shadow-sm overflow-hidden">
            {/* Chat Room Header */}
            <CardHeader className="border-b border-slate-100 py-3.5 px-5 flex flex-row items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-xs">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-sm font-bold text-slate-900">
                      AI Mentor Consultation Room
                    </CardTitle>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Live AI
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Conversational guidance personalized to {profile?.full_name || 'your profile'} ({profile?.target_role || 'Software Engineer'})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsApiKeyModalOpen(true)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 text-[11px] font-semibold text-slate-600 hover:bg-white flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Configure Gemini API Key"
                >
                  <Key className="w-3.5 h-3.5 text-blue-600" />
                  <span>API Key</span>
                </button>
                <button
                  type="button"
                  onClick={handleClearChat}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-rose-200 text-[11px] font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50/50 flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Reset conversation"
                >
                  <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-600" />
                  <span>Clear Chat</span>
                </button>
              </div>
            </CardHeader>

            {/* Chat Messages Stream */}
            <CardContent className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50/30">
              {messages.map((msg) => {
                const isUser = msg.sender === 'user';
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in duration-150`}
                  >
                    <div className={`flex gap-3 max-w-2xl ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
                      {/* Avatar */}
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-1 shadow-2xs ${
                          isUser
                            ? 'bg-blue-600 text-white'
                            : msg.isError
                            ? 'bg-rose-100 text-rose-600 border border-rose-200'
                            : 'bg-white text-blue-600 border border-slate-200'
                        }`}
                      >
                        {isUser ? (
                          <User className="w-4 h-4" />
                        ) : msg.isError ? (
                          <ShieldAlert className="w-4 h-4" />
                        ) : (
                          <Bot className="w-4 h-4" />
                        )}
                      </div>

                      {/* Bubble */}
                      <div
                        className={`p-4 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                          isUser
                            ? 'bg-blue-600 text-white rounded-tr-none'
                            : msg.isError
                            ? 'bg-rose-50/90 border border-rose-200 text-rose-900 rounded-tl-none space-y-3'
                            : 'bg-white border border-slate-200/90 text-slate-800 rounded-tl-none'
                        }`}
                      >
                        <MarkdownRenderer
                          content={msg.text}
                          isUserMessage={isUser}
                        />

                        {/* Error action controls */}
                        {msg.isError && (
                          <div className="pt-2 border-t border-rose-200/80 flex flex-wrap items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setIsApiKeyModalOpen(true)}
                              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] flex items-center gap-1.5 cursor-pointer shadow-xs"
                            >
                              <Key className="w-3.5 h-3.5" />
                              Configure API Key
                            </button>
                            {msg.canRetry && lastFailedMessage && (
                              <button
                                type="button"
                                onClick={handleRetryLast}
                                className="px-3 py-1.5 rounded-lg bg-white hover:bg-rose-100/60 border border-rose-300 text-rose-800 font-bold text-[11px] flex items-center gap-1.5 cursor-pointer"
                              >
                                <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                                Retry Message
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Typing indicator */}
              {isTyping && (
                <div className="flex justify-start items-center gap-3 animate-in fade-in">
                  <div className="w-8 h-8 rounded-xl bg-white text-blue-600 border border-slate-200 flex items-center justify-center shrink-0 shadow-2xs">
                    <Bot className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl bg-white border border-slate-200 text-slate-600 text-xs flex items-center gap-2 shadow-2xs">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                    <span className="font-medium text-slate-700">AI Mentor is formulating a personalized response...</span>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </CardContent>

            {/* Quick Prompt Suggestion Chips */}
            <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-blue-600" /> Quick Starters:
              </span>
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isTyping}
                  onClick={() => handleSendMessage(p.text)}
                  className="px-2.5 py-1 rounded-lg bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-700 hover:text-blue-700 text-[11px] font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer shadow-2xs disabled:opacity-50"
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Chat Input Bar */}
            <div className="p-3.5 bg-white border-t border-slate-200 flex items-end gap-2.5">
              <div className="flex-1 relative rounded-xl border border-slate-200 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/10 bg-slate-50/50 transition-all">
                <textarea
                  ref={textareaRef}
                  rows={2}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`Ask ${profile?.full_name ? profile.full_name.split(' ')[0] : 'mentor'} about code, interview questions, STAR answers, or technical concepts... (Press Enter to send, Shift+Enter for new line)`}
                  disabled={isTyping}
                  className="w-full text-xs p-3 bg-transparent resize-none focus:outline-none text-slate-800 placeholder:text-slate-400"
                />
              </div>

              <Button
                variant="primary"
                size="md"
                onClick={() => handleSendMessage()}
                disabled={isTyping || !inputText.trim()}
                isLoading={isTyping}
                leftIcon={<Send className="w-4 h-4" />}
                className="h-[58px] px-5 bg-blue-600 hover:bg-blue-500 font-bold shadow-sm"
              >
                Send
              </Button>
            </div>
          </Card>
        )}

        {/* TAB 2: Skill Diagnostic Matrix */}
        {activeTab === 'matrix' && (
          <div className="space-y-6">
            <Card>
              <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <CardTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span>Skill Area Diagnostic Table</span>
                  </CardTitle>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Grounded evaluation across your recent mock interview answers
                  </p>
                </div>
                <span className="text-xs text-slate-400 font-medium">Sorted by urgency</span>
              </CardHeader>

              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50/80 text-slate-600 font-bold border-b border-slate-200/80 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-3 px-4">Skill Area</th>
                      <th className="py-3 px-4 text-center">Score</th>
                      <th className="py-3 px-4">Identified Issue</th>
                      <th className="py-3 px-4">Actionable Recommendation</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {insights.map((item) => (
                      <tr key={item.id} className="hover:bg-blue-50/30 transition-colors">
                        <td className="py-4 px-4 font-bold text-slate-800 flex items-center gap-2">
                          <span className="text-slate-900">{item.skill_area}</span>
                        </td>
                        <td className="py-4 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-1 rounded-lg font-bold text-xs ${
                              item.score >= 7.5
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : item.score >= 6.0
                                ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {item.score}/10
                          </span>
                        </td>
                        <td className="py-4 px-4 text-slate-600 max-w-xs leading-relaxed">
                          {item.issue}
                        </td>
                        <td className="py-4 px-4 text-slate-700 max-w-sm font-medium leading-relaxed">
                          {item.recommendation}
                        </td>
                        <td className="py-4 px-4 text-right space-x-2 whitespace-nowrap">
                          <Button
                            variant="secondary"
                            size="sm"
                            className="text-xs"
                            onClick={() => {
                              setIsModalOpen(true);
                            }}
                          >
                            {item.action_label}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs"
                            onClick={() => handleAddToRoadmap(item.skill_area)}
                          >
                            Add to Roadmap
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </div>
        )}

        {/* TAB 3: Resume & ATS Auditor */}
        {activeTab === 'resume' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6 space-y-4">
              <div>
                <CardTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <span>Resume Text & Portfolio Bio</span>
                </CardTitle>
                <p className="text-xs text-slate-500 mt-1">
                  Paste your resume summary, project descriptions, or technical experience to run an automated keyword & ATS alignment check.
                </p>
              </div>

              <textarea
                rows={9}
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                placeholder="Paste your resume work experience or project bullets here..."
                className="w-full text-xs p-3.5 rounded-xl border border-slate-200 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/10 font-sans"
              />

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Target: <strong>{profile?.target_role || 'Full Stack Developer'}</strong>
                </span>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleAnalyzeResume}
                  leftIcon={<Sparkles className="w-4 h-4" />}
                >
                  Run ATS & Role Audit
                </Button>
              </div>
            </Card>

            <Card className="p-6 space-y-4">
              <div>
                <CardTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Audit Results & Keyword Suggestions</span>
                </CardTitle>
                <p className="text-xs text-slate-500 mt-1">
                  Evaluated against hiring benchmarks and applicant tracking standards
                </p>
              </div>

              {resumeAnalysis ? (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed font-sans overflow-y-auto max-h-[350px]">
                  <MarkdownRenderer content={resumeAnalysis} />
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400 space-y-2">
                  <FileText className="w-10 h-10 mx-auto text-slate-300" />
                  <p className="text-xs">Click "Run ATS & Role Audit" to view customized feedback.</p>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>

      {/* Setup Interview Modal */}
      <SetupInterviewModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />

      {/* API Key Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        onSuccess={() => {
          checkAiStatus();
          setActionNotice('Gemini API Key activated! Live AI model responses are now fully active.');
          setTimeout(() => setActionNotice(null), 4000);
        }}
      />
    </Layout>
  );
};
