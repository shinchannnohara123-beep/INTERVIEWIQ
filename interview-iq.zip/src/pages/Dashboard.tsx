import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Award,
  CheckCircle2,
  TrendingUp,
  ArrowRight,
  PlusCircle,
  Briefcase,
  Layers,
  ChevronRight,
  Target,
  Zap,
  GraduationCap,
  Building2,
  AlertTriangle,
  UserCheck,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge, ScoreBadge } from '../components/ui/Badge';
import { CircularProgress } from '../components/charts/CircularProgress';
import { ScoreTrendChart } from '../components/charts/ScoreTrendChart';
import { RolePerformanceChart } from '../components/charts/RolePerformanceChart';
import { InterviewHeatmap } from '../components/charts/InterviewHeatmap';
import { SetupInterviewModal } from '../components/interview/SetupInterviewModal';
import { dbService } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Interview, JobRole, PerformanceHistory, UserRoadmap, TopicMasteryRecord } from '../types/database.types';
import { Compass, Bot, Flame, MapPin } from 'lucide-react';


export const Dashboard: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [jobRoles, setJobRoles] = useState<JobRole[]>([]);
  const [performance, setPerformance] = useState<PerformanceHistory[]>([]);
  const [selectedRoleForModal, setSelectedRoleForModal] = useState<JobRole | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [roadmap, setRoadmap] = useState<UserRoadmap | null>(null);
  const [heatmapData, setHeatmapData] = useState<TopicMasteryRecord[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, [user]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const roles = await dbService.getJobRoles();
      setJobRoles(roles);

      if (user) {
        const userInts = await dbService.getUserInterviews(user.id);
        setInterviews(userInts);

        const perf = await dbService.getUserPerformance(user.id);
        setPerformance(perf);

        const road = await dbService.getUserRoadmap(user.id, profile?.target_role || 'Full Stack Developer');
        setRoadmap(road);

        const heat = await dbService.getTopicHeatmap(user.id);
        setHeatmapData(heat);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const completedInterviews = interviews.filter(i => i.status === 'completed' && i.overall_score !== null);
  const totalInterviewsCount = interviews.length;

  const averageScore = completedInterviews.length > 0
    ? Math.round(completedInterviews.reduce((acc, curr) => acc + (curr.overall_score || 0), 0) / completedInterviews.length)
    : 78;

  const bestScore = completedInterviews.length > 0
    ? Math.max(...completedInterviews.map(i => i.overall_score || 0))
    : 85;

  const scoreTrendData = performance.map((p, idx) => ({
    date: `Session ${idx + 1}`,
    score: p.score,
    role: p.job_role?.name || p.field || 'Interview',
  }));

  // Group performance by field / role for the RolePerformanceChart
  const rolePerformanceData = [
    { name: 'Frontend', score: 84, attempts: 2 },
    { name: 'Backend', score: 80, attempts: 2 },
    { name: 'Full Stack', score: 82, attempts: 1 },
    { name: 'Data / AI', score: 75, attempts: 1 },
    { name: 'Core CS', score: 88, attempts: 1 },
  ];

  const handleStartQuickInterview = () => {
    setSelectedRoleForModal(null);
    setIsModalOpen(true);
  };

  const displayName = profile?.full_name || 'Candidate';
  const targetRoleName = profile?.target_role || 'Software Engineer';

  return (
    <Layout
      title="Candidate Dashboard"
      subtitle="Overview of your technical interview progress and performance metrics"
      onStartInterviewClick={handleStartQuickInterview}
    >
      <div className="space-y-8 animate-in fade-in duration-300">
        {/* Welcome Hero Banner with Real User Name */}
        <div className="p-8 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 text-white shadow-lg shadow-blue-500/15 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-white/10 to-transparent pointer-events-none" />
          <div className="max-w-2xl relative z-10 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold border border-white/20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart AI Evaluation Engine</span>
            </div>

            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Welcome back, {displayName}!
            </h2>

            <p className="text-blue-100 text-xs md:text-sm leading-relaxed">
              Targeting <span className="font-semibold text-white">{targetRoleName}</span> roles
              {profile?.cgpa ? ` • CGPA: ${profile.cgpa}` : ''}
              {profile?.preferred_companies && profile.preferred_companies.length > 0
                ? ` • Target: ${profile.preferred_companies.slice(0, 3).join(', ')}`
                : ''}
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <Button
                variant="secondary"
                size="md"
                leftIcon={<PlusCircle className="w-4 h-4 text-blue-700" />}
                onClick={handleStartQuickInterview}
                className="bg-white hover:bg-blue-50 text-blue-700 border-none shadow-sm font-semibold"
              >
                Start Practice Session
              </Button>
              <Button
                variant="outline"
                size="md"
                onClick={() => navigate('/twin')}
                className="bg-blue-800/40 hover:bg-blue-800/60 text-white border-white/30 backdrop-blur-sm"
                leftIcon={<UserCheck className="w-4 h-4 text-sky-300" />}
              >
                AI Interview Twin
              </Button>
              <Button
                variant="outline"
                size="md"
                onClick={() => navigate('/profile')}
                className="bg-blue-800/40 hover:bg-blue-800/60 text-white border-white/30 backdrop-blur-sm"
              >
                Edit Profile & Goals
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Total Interviews */}
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Total Sessions
              </span>
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Briefcase className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900">{totalInterviewsCount}</span>
              <span className="text-xs text-slate-500 font-medium">interviews</span>
            </div>
            <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>{completedInterviews.length} completed</span>
            </p>
          </Card>

          {/* Average Score */}
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Average Score
              </span>
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900">{averageScore}</span>
              <span className="text-xs text-slate-500 font-medium">/ 100</span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Across all evaluated answers
            </p>
          </Card>

          {/* Best Score */}
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Peak Score
              </span>
              <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900">{bestScore}</span>
              <span className="text-xs text-slate-500 font-medium">/ 100</span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Personal best performance
            </p>
          </Card>

          {/* Readiness Level */}
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Placement Tier
              </span>
              <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                <Target className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-xl font-bold text-slate-900">
                {averageScore >= 80 ? 'Interview Ready' : averageScore >= 65 ? 'Competitive' : 'Developing'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Based on AI rubric analysis
            </p>
          </Card>
        </div>

        {/* Circular Progress Indicators Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 flex flex-col items-center justify-center text-center">
            <CircularProgress
              value={averageScore > 0 ? averageScore : 80}
              size={130}
              strokeWidth={11}
              label="Overall Readiness"
              sublabel="Synthesized skill rating"
            />
          </Card>

          <Card className="p-6 flex flex-col items-center justify-center text-center">
            <CircularProgress
              value={Math.min(95, Math.round(averageScore * 0.95))}
              size={130}
              strokeWidth={11}
              label="Technical Accuracy"
              sublabel="Domain depth & keywords"
            />
          </Card>

          <Card className="p-6 flex flex-col items-center justify-center text-center">
            <CircularProgress
              value={Math.min(96, Math.round(averageScore * 1.05))}
              size={130}
              strokeWidth={11}
              label="Clarity & Communication"
              sublabel="Structure & coherence"
            />
          </Card>
        </div>

        {/* Career Roadmap Progress Widget */}
        {roadmap && (
          <Card className="p-6 border-blue-200 bg-gradient-to-r from-blue-50/40 via-white to-indigo-50/30 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">
                      {roadmap.target_role} Career Roadmap
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Stage {roadmap.stages.find(s => s.progress < 100)?.id || 1} of 7: {roadmap.stages.find(s => s.progress < 100)?.title || 'Foundations'}
                    </p>
                  </div>
                </div>
                <p className="text-xs text-slate-600 max-w-xl">
                  {roadmap.stages.find(s => s.progress < 100)?.description || 'Progressing through placement readiness stages.'}
                </p>
              </div>

              <div className="flex items-center gap-4 self-end md:self-center">
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-700">{roadmap.overall_progress}% Overall</div>
                  <div className="text-[10px] text-slate-400">
                    {roadmap.stages.reduce((acc, s) => acc + s.tasks.filter(t => t.completed).length, 0)} of {roadmap.stages.reduce((acc, s) => acc + s.tasks.length, 0)} tasks
                  </div>
                </div>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => navigate('/roadmap')}
                  rightIcon={<ArrowRight className="w-4 h-4" />}
                >
                  View Full Roadmap
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Performance Graphs Grid (Recharts) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Score Trend Over Time */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <CardTitle>Score Progression Trend</CardTitle>
                <p className="text-xs text-slate-500 mt-0.5">Chronological improvement across interview rounds</p>
              </div>
              <Badge variant="blue">Trajectory</Badge>
            </div>
            <ScoreTrendChart data={scoreTrendData} />
          </Card>

          {/* Role-wise / Field-wise Performance */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <CardTitle>Field & Role Mastery</CardTitle>
                <p className="text-xs text-slate-500 mt-0.5">Performance comparison across technical domains</p>
              </div>
              <Badge variant="purple">Competency</Badge>
            </div>
            <RolePerformanceChart data={rolePerformanceData} />
          </Card>
        </div>

        {/* Skill Improvement Section */}
        <Card className="p-6 border-blue-100 bg-gradient-to-br from-blue-50/20 via-white to-sky-50/20">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">Skill Improvement & Recommendations</h3>
                <p className="text-xs text-slate-500">Targeted growth areas identified by recent AI evaluations</p>
              </div>
            </div>

            <Button
              size="sm"
              variant="secondary"
              leftIcon={<PlusCircle className="w-4 h-4 text-blue-600" />}
              onClick={handleStartQuickInterview}
            >
              Practice Weak Areas
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs space-y-2">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-600" />
                System Tradeoffs & Edge Cases
              </span>
              <p className="text-slate-600 leading-relaxed">
                Expand answers to explain both the pros and bottlenecks (e.g. Cache-Aside vs Write-Through) to demonstrate senior-level judgment.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs space-y-2">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
                Concrete Terminology
              </span>
              <p className="text-slate-600 leading-relaxed">
                Use explicit architectural terms (idempotency, pessimistic locks, hydration, LCP/CLS) rather than conversational descriptions.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs space-y-2">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-600" />
                STAR Framework Structuring
              </span>
              <p className="text-slate-600 leading-relaxed">
                For behavioral and design scenarios, structure your answer into Situation, Task, Action, and Quantified Result.
              </p>
            </div>
          </div>
        </Card>

        {/* Topic Mastery & Retention Heatmap */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" />
                <span>Performance Heatmap: Topics vs Mastery</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Identifies Strong, Medium, and Weak skill domains across technical interview rounds
              </p>
            </div>
            <span className="text-xs text-slate-400 font-medium">Auto-updated per session</span>
          </div>

          <InterviewHeatmap
            data={heatmapData}
            onPracticeTopic={(topic) => {
              setSelectedRoleForModal(null);
              setIsModalOpen(true);
            }}
          />
        </div>

        {/* AI Career Mentor Callout Banner */}
        <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-xs font-bold text-sky-300 border border-blue-400/30">
              <Bot className="w-3.5 h-3.5" />
              <span>Smart Placement Advisor</span>
            </div>
            <h3 className="text-lg md:text-xl font-bold text-white">
              Stuck on weak topics? Consult your AI Career Mentor
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Access the diagnostic matrix, request bulletproof STAR model answers, and run ATS resume audits tailored to <strong>{profile?.target_role || 'Full Stack Developer'}</strong>.
            </p>
          </div>

          <Button
            variant="primary"
            size="md"
            onClick={() => navigate('/mentor')}
            rightIcon={<ArrowRight className="w-4 h-4" />}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold shrink-0"
          >
            Open AI Mentor Suite
          </Button>
        </div>

        {/* Recent Interviews List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Recent Interview Sessions</h3>
              <p className="text-xs text-slate-500">Your latest practice mock runs and evaluation summaries</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              rightIcon={<ChevronRight className="w-4 h-4" />}
              onClick={() => navigate('/history')}
            >
              View All History
            </Button>
          </div>

          {interviews.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-sm text-slate-600">No interview sessions recorded yet.</p>
              <Button
                variant="primary"
                size="sm"
                className="mt-3"
                onClick={handleStartQuickInterview}
              >
                Start Your First Interview
              </Button>
            </Card>
          ) : (
            <div className="space-y-3">
              {interviews.slice(0, 4).map((item) => (
                <Card
                  key={item.id}
                  hoverable
                  className="p-4 cursor-pointer"
                  onClick={() => {
                    if (item.status === 'completed') {
                      navigate(`/result/${item.id}`);
                    } else {
                      navigate(`/interview/${item.id}`);
                    }
                  }}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                        <Briefcase className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-slate-900 text-sm">
                            {item.job_role?.name || item.field || 'Technical Interview'}
                          </h4>
                          <Badge
                            variant={item.status === 'completed' ? 'emerald' : 'amber'}
                            size="sm"
                          >
                            {item.status === 'completed' ? 'Completed' : 'In Progress'}
                          </Badge>
                          {item.company && item.company !== 'All' && (
                            <Badge variant="purple" size="sm">
                              {item.company}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                          <span>{new Date(item.created_at).toLocaleDateString()}</span>
                          <span>•</span>
                          <span>{item.total_questions} Questions</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-end sm:self-center">
                      <ScoreBadge score={item.overall_score} size="md" />
                      <div className="text-blue-600 hover:text-blue-800 text-xs font-semibold flex items-center gap-1">
                        <span>{item.status === 'completed' ? 'View Results' : 'Continue'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Configure Interview Modal */}
      <SetupInterviewModal
        role={selectedRoleForModal}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </Layout>
  );
};
