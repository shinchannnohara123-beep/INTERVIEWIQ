import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  GraduationCap,
  Briefcase,
  Layers,
  Code,
  Building2,
  FileText,
  Save,
  CheckCircle2,
  Sparkles,
  Camera,
  Mail,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { AVAILABLE_FIELDS, AVAILABLE_COMPANIES } from '../data/question-bank';

export const Profile: React.FC = () => {
  const { profile, updateProfile } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [email, setEmail] = useState(profile?.email || '');
  const [cgpa, setCgpa] = useState(profile?.cgpa ? String(profile.cgpa) : '');
  const [targetRole, setTargetRole] = useState(profile?.target_role || 'Full Stack Developer');
  const [selectedFields, setSelectedFields] = useState<string[]>(
    profile?.interested_fields && profile.interested_fields.length > 0
      ? profile.interested_fields
      : ['Frontend / Web Development', 'Backend Development']
  );
  const [skills, setSkills] = useState<string[]>(
    profile?.skills && profile.skills.length > 0
      ? profile.skills
      : ['React', 'JavaScript', 'Node.js', 'SQL']
  );
  const [newSkill, setNewSkill] = useState('');
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>(
    profile?.preferred_companies && profile.preferred_companies.length > 0
      ? profile.preferred_companies
      : ['Google', 'Amazon', 'TCS']
  );
  const [bio, setBio] = useState(profile?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(
    profile?.avatar_url || 'https://api.dicebear.com/7.x/avataaars/svg?seed=Candidate'
  );

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setEmail(profile.email || '');
      setCgpa(profile.cgpa ? String(profile.cgpa) : '');
      setTargetRole(profile.target_role || 'Full Stack Developer');
      if (profile.interested_fields && profile.interested_fields.length > 0) {
        setSelectedFields(profile.interested_fields);
      }
      if (profile.skills && profile.skills.length > 0) {
        setSkills(profile.skills);
      }
      if (profile.preferred_companies && profile.preferred_companies.length > 0) {
        setSelectedCompanies(profile.preferred_companies);
      }
      setBio(profile.bio || '');
      if (profile.avatar_url) {
        setAvatarUrl(profile.avatar_url);
      }
    }
  }, [profile]);

  const avatarPresets = [
    'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael',
    'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya',
    'https://api.dicebear.com/7.x/avataaars/svg?seed=David',
  ];

  const handleToggleField = (field: string) => {
    if (field === 'All') return;
    if (selectedFields.includes(field)) {
      setSelectedFields(selectedFields.filter(f => f !== field));
    } else {
      setSelectedFields([...selectedFields, field]);
    }
  };

  const handleToggleCompany = (company: string) => {
    if (company === 'All') return;
    if (selectedCompanies.includes(company)) {
      setSelectedCompanies(selectedCompanies.filter(c => c !== company));
    } else {
      setSelectedCompanies([...selectedCompanies, company]);
    }
  };

  const handleAddSkill = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    const clean = newSkill.trim();
    if (clean && !skills.includes(clean)) {
      setSkills([...skills, clean]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(s => s !== skillToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSavedSuccess(false);

    try {
      await updateProfile({
        full_name: fullName.trim() || 'Candidate',
        email: email.trim() || profile?.email || '',
        cgpa: cgpa ? parseFloat(cgpa) : null,
        target_role: targetRole.trim(),
        interested_fields: selectedFields,
        skills,
        preferred_companies: selectedCompanies,
        bio: bio.trim(),
        avatar_url: avatarUrl,
        is_profile_completed: true,
      });

      setSavedSuccess(true);
      setTimeout(() => {
        navigate('/');
      }, 1200);
    } catch (err) {
      console.error('Failed to save profile:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const candidateFields = AVAILABLE_FIELDS.filter(f => f !== 'All');
  const candidateCompanies = AVAILABLE_COMPANIES.filter(c => c !== 'All');

  return (
    <Layout
      title="Candidate Profile"
      subtitle="Complete your profile to receive targeted interview questions tailored to your skills"
    >
      <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-200">
        {/* Profile Completion Alert Banner if not completed */}
        {!profile?.is_profile_completed && (
          <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-blue-900 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-blue-800">Complete Your Candidate Profile</h4>
              <p className="text-xs text-blue-700 mt-0.5">
                Set up your real name, email, CGPA, target role, and preferred companies to personalize your AI interviews and performance benchmarks.
              </p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Header Card with Avatar & Name */}
          <Card className="p-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="relative group">
                <img
                  src={avatarUrl}
                  alt={fullName || 'Avatar'}
                  className="w-24 h-24 rounded-2xl border-2 border-blue-200 object-cover bg-slate-50 shadow-sm"
                />
              </div>

              <div className="flex-1 space-y-2 text-center sm:text-left">
                <h3 className="text-lg font-bold text-slate-900">{fullName || 'Set Your Name'}</h3>
                <p className="text-xs text-slate-500">{email || profile?.email || 'Candidate Account'}</p>

                {/* Preset Avatar Selector */}
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Choose Profile Avatar Preset
                  </label>
                  <div className="flex flex-wrap justify-center sm:justify-start gap-2">
                    {avatarPresets.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setAvatarUrl(preset)}
                        className={`w-9 h-9 rounded-xl border-2 overflow-hidden transition-all cursor-pointer ${
                          avatarUrl === preset ? 'border-blue-600 scale-105 shadow-xs' : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <img src={preset} alt={`Preset ${idx + 1}`} className="w-full h-full object-cover bg-white" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Core Information Card */}
          <Card className="p-6 space-y-5">
            <CardTitle className="text-base text-slate-900 border-b border-slate-100 pb-3">
              Academic & Career Details
            </CardTitle>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Aditi Sharma"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 bg-white"
                  />
                </div>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. aditi.sharma@college.edu"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 bg-white"
                  />
                </div>
              </div>

              {/* Target Job Role */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Target Job Role *
                </label>
                <div className="relative">
                  <Briefcase className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value)}
                    placeholder="e.g. Full Stack Developer, Data Scientist"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 bg-white"
                  />
                </div>
              </div>

              {/* CGPA */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  College CGPA / GPA
                </label>
                <div className="relative">
                  <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="10"
                    value={cgpa}
                    onChange={(e) => setCgpa(e.target.value)}
                    placeholder="e.g. 8.65"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 bg-white"
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Interested Fields Multi-Select */}
          <Card className="p-6 space-y-4">
            <div>
              <CardTitle className="text-base text-slate-900">Interested Fields</CardTitle>
              <p className="text-xs text-slate-500 mt-0.5">
                Select one or more domains. Interview questions will be dynamically curated for these areas.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {candidateFields.map((field) => {
                const isSelected = selectedFields.includes(field);
                return (
                  <button
                    key={field}
                    type="button"
                    onClick={() => handleToggleField(field)}
                    className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 shadow-2xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <span>{field}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Preferred Companies Multi-Select */}
          <Card className="p-6 space-y-4">
            <div>
              <CardTitle className="text-base text-slate-900">Preferred Companies</CardTitle>
              <p className="text-xs text-slate-500 mt-0.5">
                Select your target tech employers to practice company-style interview questions.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {candidateCompanies.map((company) => {
                const isSelected = selectedCompanies.includes(company);
                return (
                  <button
                    key={company}
                    type="button"
                    onClick={() => handleToggleCompany(company)}
                    className={`py-2.5 px-3 rounded-xl border text-center text-xs font-semibold transition-all cursor-pointer ${
                      isSelected
                        ? 'border-blue-600 bg-blue-600 text-white shadow-2xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    {company}
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Technical Skills Tag Manager */}
          <Card className="p-6 space-y-4">
            <div>
              <CardTitle className="text-base text-slate-900">Technical Skills</CardTitle>
              <p className="text-xs text-slate-500 mt-0.5">
                Add skills, frameworks, and programming languages you know.
              </p>
            </div>

            {/* Existing Skills Tags */}
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <span
                  key={skill}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 text-xs font-medium"
                >
                  <span>{skill}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(skill)}
                    className="text-blue-400 hover:text-blue-800 cursor-pointer text-sm leading-none"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            {/* Input to add skill */}
            <div className="flex gap-2 max-w-md">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddSkill(e);
                }}
                placeholder="Type skill (e.g. Python, Docker, Next.js)"
                className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-blue-500 bg-white"
              />
              <Button type="button" variant="outline" size="sm" onClick={handleAddSkill}>
                Add Skill
              </Button>
            </div>
          </Card>

          {/* Bio / About */}
          <Card className="p-6 space-y-3">
            <CardTitle className="text-base text-slate-900">Candidate Bio & Goals</CardTitle>
            <textarea
              rows={4}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Brief description of your background, projects built, and upcoming placement interview goals..."
              className="w-full p-4 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 bg-white resize-y leading-relaxed"
            />
          </Card>

          {/* Actions Bar */}
          <div className="flex items-center justify-between pt-2">
            <div>
              {savedSuccess && (
                <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 font-semibold animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4" /> Profile saved successfully!
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <Button
                type="button"
                variant="outline"
                size="md"
                onClick={() => navigate('/')}
              >
                Back to Dashboard
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="md"
                isLoading={isSaving}
                leftIcon={<Save className="w-4 h-4" />}
              >
                Save Profile
              </Button>
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
};
