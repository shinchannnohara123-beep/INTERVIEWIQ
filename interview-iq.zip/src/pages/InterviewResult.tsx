import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import confetti from 'canvas-confetti';
import {
  Award,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  RotateCcw,
  History,
  ChevronDown,
  ChevronUp,
  FileText,
  Briefcase,
  Share2,
  Sparkles,
  Bot,
  Layers,
  Scale,
  Mic,
  BookmarkPlus,
  Zap,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge, DifficultyBadge, ScoreBadge } from '../components/ui/Badge';
import { CircularProgress } from '../components/charts/CircularProgress';
import { dbService } from '../lib/supabase';
import { generateIdealAnswerComparison } from '../lib/ai-client';
import { Interview, JobRole, Answer, Evaluation, Question } from '../types/database.types';

export const InterviewResult: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [interview, setInterview] = useState<Interview | null>(null);
  const [role, setRole] = useState<JobRole | null>(null);
  const [answersWithEval, setAnswersWithEval] = useState<
    (Answer & { evaluation?: Evaluation; question?: Question })[]
  >([]);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);
  const [comparisonModeIndex, setComparisonModeIndex] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [roadmapSynced, setRoadmapSynced] = useState(false);

  useEffect(() => {
    if (id) {
      loadResults(id);
    }
  }, [id]);

  const loadResults = async (interviewId: string) => {
    setIsLoading(true);
    try {
      const data = await dbService.getInterviewDetails(interviewId);
      if (data) {
        setInterview(data.interview);
        setRole(data.role || null);
        setAnswersWithEval(data.answersWithEval);

        if ((data.interview.overall_score || 0) >= 70) {
          confetti({
            particleCount: 90,
            spread: 70,
            origin: { y: 0.6 },
          });
        }
      }
    } catch (err) {
      console.error('Error fetching interview result:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSyncToRoadmap = async () => {
    if (!interview) return;
    try {
      // Find weak topics (< 60)
      const weakAnswers = answersWithEval.filter(a => (a.evaluation?.overall_score || 0) < 65);
      for (const item of weakAnswers) {
        if (item.question?.topic) {
          await dbService.addSkillGapToRoadmap(interview.user_id, item.question.topic);
        }
      }
      setRoadmapSynced(true);
      setTimeout(() => setRoadmapSynced(false), 4000);
    } catch (e) {
      console.error(e);
    }
  };

  if (isLoading) {
    return (
      <Layout title="Evaluation Report">
        <div className="py-24 text-center">
          <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm font-semibold text-slate-700">Synthesizing comprehensive AI evaluation...</p>
        </div>
      </Layout>
    );
  }

  if (!interview) {
    return (
      <Layout title="Report Not Found">
        <div className="max-w-md mx-auto py-16 text-center space-y-4">
          <p className="text-sm text-slate-600">The requested interview results could not be located.</p>
          <Button variant="primary" onClick={() => navigate('/history')}>
            Go to Interview History
          </Button>
        </div>
      </Layout>
    );
  }

  const validEvaluations = answersWithEval
    .map(a => a.evaluation)
    .filter((e): e is Evaluation => Boolean(e));

  const count = validEvaluations.length || 1;
  const avgRelevance = Math.round(validEvaluations.reduce((sum, e) => sum + e.relevance_score, 0) / count);
  const avgClarity = Math.round(validEvaluations.reduce((sum, e) => sum + e.clarity_score, 0) / count);
  const avgContent = Math.round(validEvaluations.reduce((sum, e) => sum + e.content_score, 0) / count);
  const avgTechnical = Math.round(validEvaluations.reduce((sum, e) => sum + e.technical_score, 0) / count);
  const avgCommunication = Math.round(validEvaluations.reduce((sum, e) => sum + e.communication_score, 0) / count);
  const overallScore = interview.overall_score !== null ? interview.overall_score : 75;

  const currentComparisonItem = answersWithEval[comparisonModeIndex];
  const comparisonData = currentComparisonItem && currentComparisonItem.question
    ? generateIdealAnswerComparison(
        currentComparisonItem.question.question_text,
        currentComparisonItem.answer_text,
        currentComparisonItem.question.topic,
        currentComparisonItem.evaluation?.overall_score || 75
      )
    : null;

  return (
    <Layout
      title="Comprehensive AI Evaluation & Answer Comparison"
      subtitle="Multi-dimensional scoring, ideal answer benchmarking, and actionable phrasing critique"
    >
      <div className="space-y-8 animate-in fade-in duration-200">
        {/* Top Hero Banner */}
        <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-700 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-semibold backdrop-blur-md">
              <Award className="w-3.5 h-3.5" />
              <span>Interview Completed Successfully</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              {role?.name || interview.field || 'Software Engineering'} Placement Assessment
            </h2>
            <p className="text-sm text-blue-100">
              Evaluated against corporate placement standards ({interview.company || 'Tech Giant'} style) across {answersWithEval.length} questions.
            </p>
          </div>

          {/* Circular Score */}
          <div className="flex items-center gap-6 bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/20">
            <CircularProgress
              value={overallScore}
              size={100}
              strokeWidth={10}
              label="Overall"
              sublabel="Score"
            />
            <div className="space-y-1">
              <div className="text-xs text-blue-200 font-semibold uppercase tracking-wider">Hiring Verdict</div>
              <div className="text-xl font-bold">
                {overallScore >= 80 ? 'Strong Candidate' : overallScore >= 65 ? 'Placement Eligible' : 'Needs Preparation'}
              </div>
              <div className="text-xs text-blue-100">
                Performance Tier: {overallScore >= 80 ? 'Top 10%' : overallScore >= 65 ? 'Top 35%' : 'Developing'}
              </div>
            </div>
          </div>
        </div>

        {/* 5-Dimensional Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs text-center">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Relevance</div>
            <div className="text-2xl font-extrabold text-blue-600 mt-1">{avgRelevance}%</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Prompt alignment</div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs text-center">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Technical</div>
            <div className="text-2xl font-extrabold text-indigo-600 mt-1">{avgTechnical}%</div>
            <div className="text-[10px] text-slate-500 mt-0.5">System terminology</div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs text-center">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Clarity</div>
            <div className="text-2xl font-extrabold text-emerald-600 mt-1">{avgClarity}%</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Logical flow</div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs text-center">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Content</div>
            <div className="text-2xl font-extrabold text-sky-600 mt-1">{avgContent}%</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Depth & substance</div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs text-center col-span-2 md:col-span-1">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Communication</div>
            <div className="text-2xl font-extrabold text-purple-600 mt-1">{avgCommunication}%</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Executive delivery</div>
          </div>
        </div>

        {/* Roadmap Sync Action Bar */}
        <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <BookmarkPlus className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Career Roadmap Synchronization</h4>
              <p className="text-[11px] text-slate-500">
                Automatically add topics with scores under 65% as dedicated practice tasks in your Career Roadmap
              </p>
            </div>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={handleSyncToRoadmap}
            leftIcon={<CheckCircle2 className="w-4 h-4" />}
          >
            {roadmapSynced ? 'Synced Successfully! ✓' : 'Add Weak Skills to Roadmap'}
          </Button>
        </div>

        {/* FEATURE 5: ANSWER COMPARISON MODE (Mandatory Feature!) */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Scale className="w-5 h-5 text-blue-600" />
                <span>Answer Comparison Mode (Side-by-Side)</span>
              </h3>
              <p className="text-xs text-slate-500">
                Compare your actual submitted response directly against an AI-generated model answer and phrasing critique
              </p>
            </div>

            {/* Question Selector Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {answersWithEval.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setComparisonModeIndex(idx)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    comparisonModeIndex === idx
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Q{idx + 1} Comparison
                </button>
              ))}
            </div>
          </div>

          {currentComparisonItem && comparisonData && (
            <div className="space-y-4">
              {/* Question Banner & Score (0-10) */}
              <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400">
                    Question {comparisonModeIndex + 1}: {currentComparisonItem.question?.topic}
                  </span>
                  <p className="text-sm font-bold text-slate-100">
                    {currentComparisonItem.question?.question_text}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="px-3 py-1.5 rounded-xl bg-blue-500/20 text-blue-300 font-extrabold text-xs border border-blue-400/30">
                    Score: {comparisonData.score_out_of_10} / 10 ({currentComparisonItem.evaluation?.overall_score || 0}%)
                  </span>
                </div>
              </div>

              {/* 3 Comparative Columns */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
                {/* 1. User Answer */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2 border-slate-100">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                        <FileText className="w-4 h-4 text-blue-500" />
                        <span>1. User Answer</span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {currentComparisonItem.answer_text.split(/\s+/).length} words
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 text-xs text-slate-800 leading-relaxed font-sans whitespace-pre-line border border-slate-100 max-h-80 overflow-y-auto">
                      {currentComparisonItem.answer_text}
                    </div>
                  </div>

                  {/* Strengths identified */}
                  <div className="pt-2 border-t border-slate-100">
                    <div className="text-[11px] font-bold text-emerald-700 mb-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> What Worked Well:
                    </div>
                    <ul className="text-[11px] text-slate-600 space-y-1 list-disc pl-4">
                      {currentComparisonItem.evaluation?.strengths.slice(0, 2).map((s, idx) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* 2. Ideal Answer */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-blue-50/50 to-white border border-blue-200 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2 border-blue-100">
                      <span className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-blue-600" />
                        <span>2. Ideal Answer</span>
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold">
                        STAR Model Format
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-white text-xs text-slate-800 leading-relaxed border border-blue-100/80 max-h-80 overflow-y-auto shadow-2xs font-medium">
                      {comparisonData.ideal_answer}
                    </div>
                  </div>

                  {/* Missing Keywords highlight */}
                  <div className="pt-2 border-t border-blue-100">
                    <div className="text-[11px] font-bold text-blue-900 mb-1 flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5 text-blue-600" /> Essential Keywords:
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {comparisonData.missing_keywords.map((kw, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-blue-800 text-[10px] font-bold"
                        >
                          + {kw}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 3. Missing Points & Phrasing Critique */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2 border-slate-100">
                      <span className="text-xs font-bold text-rose-900 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-rose-600" />
                        <span>3. Missing Points</span>
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 font-bold border border-rose-200">
                        Skill Gaps
                      </span>
                    </div>

                    {/* Missing Points Bullets */}
                    <div className="space-y-1.5">
                      <ul className="text-xs text-slate-700 space-y-1.5 list-disc pl-4 bg-rose-50/40 p-3 rounded-xl border border-rose-100 font-medium">
                        {comparisonData.missing_points && comparisonData.missing_points.length > 0 ? (
                          comparisonData.missing_points.map((pt, idx) => (
                            <li key={idx} className="text-[11px] leading-relaxed text-rose-950">{pt}</li>
                          ))
                        ) : (
                          <li className="text-[11px] leading-relaxed text-rose-950">Add deeper consideration of production edge cases and error boundaries.</li>
                        )}
                      </ul>
                    </div>

                    {/* Phrasing Suggestions */}
                    <div className="space-y-2 pt-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Recommended Phrasing Transformation:
                      </div>
                      {comparisonData.phrasing_suggestions.slice(0, 1).map((ps, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] space-y-1">
                          <div className="text-rose-600 line-through">"{ps.original}"</div>
                          <div className="text-emerald-700 font-semibold">"{ps.improved}"</div>
                          <div className="text-[10px] text-slate-500">{ps.rationale}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <div className="text-[11px] font-bold text-amber-700 mb-1 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Key Weakness to Fix:
                    </div>
                    <p className="text-[11px] text-slate-600">
                      {currentComparisonItem.evaluation?.weaknesses[0] || 'Expand on production error handling.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-200">
          <Button
            variant="ghost"
            size="md"
            onClick={() => navigate('/history')}
            leftIcon={<History className="w-4 h-4" />}
          >
            All Past Interviews
          </Button>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="md"
              onClick={() => navigate('/roadmap')}
              leftIcon={<Layers className="w-4 h-4" />}
            >
              Open Career Roadmap
            </Button>
            <Button
              variant="primary"
              size="md"
              onClick={() => navigate('/roles')}
              leftIcon={<RotateCcw className="w-4 h-4" />}
            >
              Practice Another Track
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default InterviewResult;
