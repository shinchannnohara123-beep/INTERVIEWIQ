import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { History, Calendar, CheckCircle2, ArrowRight, Search, PlusCircle, Award } from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge, ScoreBadge } from '../components/ui/Badge';
import { dbService } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Interview } from '../types/database.types';

export const InterviewHistory: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'completed' | 'in_progress'>('All');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, [user]);

  const loadHistory = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const data = await dbService.getUserInterviews(user.id);
      setInterviews(data);
    } catch (err) {
      console.error('Error fetching history:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredInterviews = interviews.filter((item) => {
    const roleName = item.job_role?.name || 'Interview Session';
    const matchesSearch = roleName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <Layout
      title="Interview History"
      subtitle="Complete chronological record of your AI evaluation sessions and scores"
      onStartInterviewClick={() => navigate('/roles')}
    >
      <div className="space-y-6 animate-in fade-in duration-300">
        {/* Search and Filters */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search interview role..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 bg-white"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
              Status:
            </span>
            {(['All', 'completed', 'in_progress'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
                  statusFilter === st
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st === 'All' ? 'All' : st === 'completed' ? 'Completed' : 'In Progress'}
              </button>
            ))}
          </div>
        </div>

        {/* History List */}
        {filteredInterviews.length === 0 ? (
          <Card className="p-12 text-center">
            <History className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-800">No interview sessions found</h3>
            <p className="text-xs text-slate-500 mt-1">Practice an interview track to record your performance history.</p>
            <Button
              variant="primary"
              size="sm"
              className="mt-4"
              onClick={() => navigate('/roles')}
            >
              Start New Interview
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredInterviews.map((item) => (
              <Card
                key={item.id}
                hoverable
                className="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer"
                onClick={() => {
                  if (item.status === 'completed') {
                    navigate(`/result/${item.id}`);
                  } else {
                    navigate(`/interview/${item.id}`);
                  }
                }}
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 text-sm">
                        {item.job_role?.name || 'Technical Interview Session'}
                      </h4>
                      <Badge
                        variant={item.status === 'completed' ? 'emerald' : 'amber'}
                        size="sm"
                      >
                        {item.status === 'completed' ? 'Completed' : 'In Progress'}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {new Date(item.created_at).toLocaleDateString()} at{' '}
                        {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <span>•</span>
                      <span>{item.total_questions} Questions</span>
                      {item.job_role?.difficulty && (
                        <>
                          <span>•</span>
                          <span>{item.job_role.difficulty}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end md:self-center">
                  <ScoreBadge score={item.overall_score} size="md" />
                  <Button
                    size="sm"
                    variant={item.status === 'completed' ? 'outline' : 'primary'}
                    rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                  >
                    {item.status === 'completed' ? 'View Report' : 'Resume'}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};
