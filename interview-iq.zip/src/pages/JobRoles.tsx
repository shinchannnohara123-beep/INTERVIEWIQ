import React, { useState, useEffect } from 'react';
import {
  Search,
  Briefcase,
  Layers,
  ArrowRight,
  Filter,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge, DifficultyBadge } from '../components/ui/Badge';
import { SetupInterviewModal } from '../components/interview/SetupInterviewModal';
import { dbService } from '../lib/supabase';
import { JobRole } from '../types/database.types';

export const JobRoles: React.FC = () => {
  const [roles, setRoles] = useState<JobRole[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedRoleForModal, setSelectedRoleForModal] = useState<JobRole | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadRoles();
  }, []);

  const loadRoles = async () => {
    setIsLoading(true);
    try {
      const data = await dbService.getJobRoles();
      setRoles(data);
    } catch (err) {
      console.error('Error fetching job roles:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const categories = ['All', 'Engineering', 'Data & AI', 'DevOps & Infra', 'Product'];
  const difficulties = ['All', 'Junior', 'Mid-Level', 'Senior'];

  const filteredRoles = roles.filter((role) => {
    const matchesSearch =
      role.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (role.description && role.description.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesCategory =
      selectedCategory === 'All' || role.category === selectedCategory;

    const matchesDifficulty =
      selectedDifficulty === 'All' ||
      role.difficulty.toLowerCase().includes(selectedDifficulty.toLowerCase());

    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  return (
    <Layout
      title="Job Roles & Interview Tracks"
      subtitle="Select a target engineering or tech role to practice curated interview questions"
      onStartInterviewClick={() => {
        if (roles.length > 0) {
          setSelectedRoleForModal(roles[0]);
          setIsModalOpen(true);
        }
      }}
    >
      <div className="space-y-6 animate-in fade-in duration-300">
        {/* Search & Filter Header Bar */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            {/* Search Input */}
            <div className="relative w-full md:w-96">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search job roles, stacks, or keywords..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all bg-white"
              />
            </div>

            {/* Total Results Count */}
            <div className="text-xs text-slate-500 font-medium self-end md:self-center">
              Showing <span className="font-bold text-slate-800">{filteredRoles.length}</span> of {roles.length} tracks
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-6 pt-3 border-t border-slate-100 text-xs">
            {/* Category Filter */}
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
                Category:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-colors ${
                      selectedCategory === cat
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty Filter */}
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
                Level:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {difficulties.map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setSelectedDifficulty(diff)}
                    className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-colors ${
                      selectedDifficulty === diff
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Roles Grid */}
        {filteredRoles.length === 0 ? (
          <Card className="p-12 text-center">
            <Briefcase className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-800">No matching roles found</h3>
            <p className="text-xs text-slate-500 mt-1">Try clearing your filters or changing your search keywords.</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All');
                setSelectedDifficulty('All');
              }}
            >
              Reset Filters
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRoles.map((role) => (
              <Card
                key={role.id}
                hoverable
                className="p-6 flex flex-col justify-between group cursor-pointer"
                onClick={() => {
                  setSelectedRoleForModal(role);
                  setIsModalOpen(true);
                }}
              >
                <div>
                  {/* Top Badges */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <Badge variant="blue" size="sm">
                      {role.category || 'Tech'}
                    </Badge>
                    <DifficultyBadge difficulty={role.difficulty} size="sm" />
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {role.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-2 line-clamp-3 leading-relaxed">
                    {role.description}
                  </p>
                </div>

                {/* Footer action */}
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                    AI Scored Mock
                  </span>
                  <div className="text-blue-600 font-semibold text-xs flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    <span>Practice Role</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Start Interview Modal */}
      <SetupInterviewModal
        role={selectedRoleForModal}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </Layout>
  );
};
