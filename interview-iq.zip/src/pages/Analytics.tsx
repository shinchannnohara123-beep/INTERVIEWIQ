import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  BarChart2,
  Award,
  Zap,
  Target,
  CheckCircle,
  HelpCircle,
  Briefcase,
} from 'lucide-react';
import { Layout } from '../components/layout/Layout';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { ScoreTrendChart } from '../components/charts/ScoreTrendChart';
import { RadarSkillsChart } from '../components/charts/RadarSkillsChart';
import { CircularProgress } from '../components/charts/CircularProgress';
import { InterviewHeatmap } from '../components/charts/InterviewHeatmap';
import { dbService } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { PerformanceHistory, Interview, TopicMasteryRecord } from '../types/database.types';
import { Flame } from 'lucide-react';


export const Analytics: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [history, setHistory] = useState<PerformanceHistory[]>([]);
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [heatmapData, setHeatmapData] = useState<TopicMasteryRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, [user]);

  const loadAnalytics = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const perf = await dbService.getUserPerformance(user.id);
      setHistory(perf);

      const ints = await dbService.getUserInterviews(user.id);
      setInterviews(ints);

      const heat = await dbService.getTopicHeatmap(user.id);
      setHeatmapData(heat);
    } catch (err) {
      console.error('Error loading analytics:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const completed = interviews.filter(i => i.status === 'completed' && i.overall_score !== null);
  const avgScore = completed.length > 0
    ? Math.round(completed.reduce((acc, curr) => acc + (curr.overall_score || 0), 0) / completed.length)
    : 78;

  const bestScore = completed.length > 0
    ? Math.max(...completed.map(i => i.overall_score || 0))
    : 85;

  const chartData = history.map((item, idx) => ({
    date: `Attempt ${idx + 1}`,
    score: item.score,
    role: item.job_role?.name || 'Interview',
  }));

  return (
    <Layout
      title="Performance Analytics & Intelligence"
      subtitle="Comprehensive insights across technical depth, communication, and historical growth"
      onStartInterviewClick={() => navigate('/roles')}
    >
      <div className="space-y-8 animate-in fade-in duration-300">
        {/* KPI Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <Card className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs uppercase font-bold text-slate-400">Mean Score</p>
              <h3 className="text-2xl font-black text-slate-900 mt-0.5">{avgScore} / 100</h3>
              <p className="text-[11px] text-slate-500">Across {completed.length || 1} completed rounds</p>
            </div>
          </Card>

          <Card className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs uppercase font-bold text-slate-400">Peak Performance</p>
              <h3 className="text-2xl font-black text-slate-900 mt-0.5">{bestScore} / 100</h3>
              <p className="text-[11px] text-emerald-600 font-semibold">Top score achieved</p>
            </div>
          </Card>

          <Card className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs uppercase font-bold text-slate-400">Readiness Status</p>
              <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                {avgScore >= 80 ? 'Interview Ready' : 'Competitive'}
              </h3>
              <p className="text-[11px] text-purple-700 font-medium">Senior Tier Recommended</p>
            </div>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Trend Line Chart */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <CardTitle>Historical Score Trend</CardTitle>
                <p className="text-xs text-slate-500 mt-0.5">Performance trajectory across repeated interview iterations</p>
              </div>
              <Badge variant="blue">Trajectory</Badge>
            </div>
            <ScoreTrendChart data={chartData} />
          </Card>

          {/* Competency Breakdown Bar Chart */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <CardTitle>Core Competency Distribution</CardTitle>
                <p className="text-xs text-slate-500 mt-0.5">Cross-category analysis of technical and communication metrics</p>
              </div>
              <Badge variant="blue">Competencies</Badge>
            </div>
            <RadarSkillsChart />
          </Card>
        </div>

        {/* Topic Mastery & Retention Heatmap */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" />
                <span>Performance Heatmap: Topics vs Performance</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Evaluates retention across strong (&ge;75%), medium (50-74%), and weak (&lt;50%) technical disciplines
              </p>
            </div>
            <span className="text-xs text-slate-400 font-medium">Full Skill Matrix</span>
          </div>

          <InterviewHeatmap
            data={heatmapData}
            onPracticeTopic={(topic) => navigate('/roles')}
          />
        </div>

        {/* Actionable Intelligence & Growth Advice */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 border-blue-100 bg-gradient-to-br from-blue-50/30 to-white">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-3">
              <Zap className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">System Design & Tradeoffs</h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              When answering architectural questions, always present both the benefits and bottlenecks (e.g., Cache-Aside vs Write-Through).
            </p>
          </Card>

          <Card className="p-6 border-emerald-100 bg-gradient-to-br from-emerald-50/30 to-white">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3">
              <CheckCircle className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Concrete Terminology</h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Incorporate precise industry terms (idempotency, pessimistic locks, hydration, LCP/CLS) to increase your technical depth score.
            </p>
          </Card>

          <Card className="p-6 border-purple-100 bg-gradient-to-br from-purple-50/30 to-white">
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-3">
              <Target className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">STAR Structure</h4>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              For behavioral and incident questions, structure your reply using Situation, Task, Action, and Quantitative Result.
            </p>
          </Card>
        </div>
      </div>
    </Layout>
  );
};
