import React, { createContext, useContext, useState, useEffect } from 'react';
import { getSupabaseClient, isSupabaseConfigured, dbService } from '../lib/supabase';
import { localDB } from '../lib/mock-db';
import { Profile } from '../types/database.types';

interface User {
  id: string;
  email?: string;
  user_metadata?: {
    full_name?: string;
    avatar_url?: string;
  };
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  isLoading: boolean;
  isSupabaseMode: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  register: (email: string, password: string, fullName: string) => Promise<{ error?: string; user?: User }>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<Profile>;
  loginAsGuest: (fullName?: string, email?: string) => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSupabaseMode, setIsSupabaseMode] = useState(false);

  useEffect(() => {
    checkInitialAuth();
  }, []);

  const checkInitialAuth = async () => {
    setIsLoading(true);
    const configured = isSupabaseConfigured();
    setIsSupabaseMode(configured);

    if (configured) {
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data: { session } } = await client.auth.getSession();
          if (session?.user) {
            setUser(session.user);
            const prof = await dbService.getProfile(session.user.id);
            if (prof) {
              setProfile(prof);
            }
            setIsLoading(false);
            return;
          }
        } catch (e) {
          console.warn('Supabase session load error:', e);
        }
      }
    }

    // Check local session
    const storedUser = localStorage.getItem('interviewiq_current_user');
    if (storedUser) {
      try {
        const parsed = JSON.parse(storedUser);
        setUser(parsed);
        const prof = await dbService.getProfile(parsed.id);
        if (prof) {
          setProfile(prof);
        } else {
          const newProf: Profile = {
            id: parsed.id,
            full_name: parsed.user_metadata?.full_name || 'Aditi Sharma',
            email: parsed.email || 'aditi.sharma@college.edu',
            avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=Aditi`,
            cgpa: 8.6,
            target_role: 'Full Stack Developer',
            interested_fields: ['Frontend / Web Development', 'Backend Development'],
            skills: ['React', 'JavaScript', 'Node.js', 'SQL'],
            preferred_companies: ['Google', 'Amazon', 'TCS'],
            bio: 'Computer Science student preparing for technical placement interviews.',
            is_profile_completed: true,
          };
          localDB.saveProfile(newProf);
          setProfile(newProf);
        }
      } catch (e) {
        console.warn('Error reading stored user session:', e);
      }
    } else {
      // Auto-initialize real candidate session for immediate usability
      const defaultUser: User = {
        id: 'candidate-user-01',
        email: 'aditi.sharma@college.edu',
        user_metadata: { full_name: 'Aditi Sharma' },
      };
      setUser(defaultUser);
      localStorage.setItem('interviewiq_current_user', JSON.stringify(defaultUser));

      const existingProf = localDB.getProfile(defaultUser.id);
      if (existingProf) {
        setProfile(existingProf);
      } else {
        const initialProf: Profile = {
          id: defaultUser.id,
          full_name: 'Aditi Sharma',
          email: 'aditi.sharma@college.edu',
          avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aditi',
          cgpa: 8.6,
          target_role: 'Full Stack Developer',
          interested_fields: ['Frontend / Web Development', 'Backend Development'],
          skills: ['React', 'JavaScript', 'Node.js', 'SQL'],
          preferred_companies: ['Google', 'Amazon', 'TCS', 'Infosys'],
          bio: 'Computer Science student passionate about full-stack web applications and scalable system design.',
          is_profile_completed: true,
        };
        localDB.saveProfile(initialProf);
        setProfile(initialProf);
      }
    }
    setIsLoading(false);
  };

  const login = async (email: string, password: string): Promise<{ error?: string }> => {
    if (isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        const { data, error } = await client.auth.signInWithPassword({ email, password });
        if (error) {
          return { error: error.message };
        }
        if (data.user) {
          setUser(data.user);
          const prof = await dbService.getProfile(data.user.id);
          if (prof) setProfile(prof);
          return {};
        }
      }
    }

    // Local authentication: lookup or create for this exact email
    const userId = `user-${email.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    const loggedUser: User = {
      id: userId,
      email,
      user_metadata: {
        full_name: email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      },
    };

    setUser(loggedUser);
    localStorage.setItem('interviewiq_current_user', JSON.stringify(loggedUser));

    const existingProfile = localDB.getProfile(userId);
    if (existingProfile) {
      setProfile(existingProfile);
    } else {
      const newProf: Profile = {
        id: userId,
        full_name: loggedUser.user_metadata?.full_name || 'Candidate',
        email,
        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(email)}`,
        cgpa: null,
        target_role: 'Full Stack Developer',
        interested_fields: ['Full Stack Development', 'Frontend / Web Development'],
        skills: ['JavaScript', 'React', 'Node.js'],
        preferred_companies: ['Google', 'TCS', 'Amazon'],
        bio: '',
        is_profile_completed: false,
      };
      localDB.saveProfile(newProf);
      setProfile(newProf);
    }

    return {};
  };

  const register = async (email: string, password: string, fullName: string): Promise<{ error?: string; user?: User }> => {
    if (isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        const { data, error } = await client.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
          },
        });
        if (error) {
          return { error: error.message };
        }
        if (data.user) {
          setUser(data.user);
          const newProf: Profile = {
            id: data.user.id,
            full_name: fullName,
            email,
            avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
            cgpa: null,
            target_role: '',
            interested_fields: [],
            skills: [],
            preferred_companies: [],
            bio: '',
            is_profile_completed: false,
          };
          await dbService.updateProfile(data.user.id, newProf);
          setProfile(newProf);
          return { user: data.user };
        }
      }
    }

    // Local / Offline signup
    const userId = `user-${Date.now()}`;
    const newUser: User = {
      id: userId,
      email,
      user_metadata: { full_name: fullName },
    };
    setUser(newUser);
    localStorage.setItem('interviewiq_current_user', JSON.stringify(newUser));

    const newProfile: Profile = {
      id: userId,
      full_name: fullName,
      email,
      avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
      cgpa: null,
      target_role: '',
      interested_fields: [],
      skills: [],
      preferred_companies: [],
      bio: '',
      is_profile_completed: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    localDB.saveProfile(newProfile);
    setProfile(newProfile);

    return { user: newUser };
  };

  const updateProfile = async (updates: Partial<Profile>): Promise<Profile> => {
    if (!user) throw new Error('No authenticated user');
    const updated = await dbService.updateProfile(user.id, updates);
    setProfile(updated);
    return updated;
  };

  const logout = async () => {
    if (isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        await client.auth.signOut();
      }
    }
    localStorage.removeItem('interviewiq_current_user');
    setUser(null);
    setProfile(null);
  };

  const loginAsGuest = (fullName = 'Candidate', email = 'candidate@college.edu') => {
    const guestUser: User = {
      id: `guest-${Date.now()}`,
      email,
      user_metadata: {
        full_name: fullName,
      },
    };
    setUser(guestUser);
    localStorage.setItem('interviewiq_current_user', JSON.stringify(guestUser));

    const newProf: Profile = {
      id: guestUser.id,
      full_name: fullName,
      email,
      avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
      cgpa: '8.5',
      target_role: 'Full Stack Developer',
      interested_fields: ['Frontend / Web Development', 'Backend Development'],
      skills: ['React', 'JavaScript', 'Node.js', 'SQL'],
      preferred_companies: ['Google', 'Amazon', 'TCS', 'Infosys'],
      bio: 'Enthusiastic computer science student passionate about full-stack web applications and scalable system design.',
      is_profile_completed: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    localDB.saveProfile(newProf);
    setProfile(newProf);
  };

  const refreshProfile = async () => {
    if (user) {
      const prof = await dbService.getProfile(user.id);
      if (prof) setProfile(prof);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isLoading,
        isSupabaseMode,
        login,
        register,
        logout,
        updateProfile,
        loginAsGuest,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

const defaultProfile: Profile = {
  id: 'candidate-user-01',
  full_name: 'Aditi Sharma',
  email: 'aditi.sharma@college.edu',
  avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aditi',
  cgpa: 8.6,
  target_role: 'Full Stack Developer',
  interested_fields: ['Frontend / Web Development', 'Backend Development'],
  skills: ['React', 'JavaScript', 'Node.js', 'SQL'],
  preferred_companies: ['Google', 'Amazon', 'TCS', 'Infosys'],
  bio: 'Computer Science student passionate about full-stack web applications and scalable system design.',
  is_profile_completed: true,
};

const defaultAuthContext: AuthContextType = {
  user: {
    id: 'candidate-user-01',
    email: 'aditi.sharma@college.edu',
    user_metadata: { full_name: 'Aditi Sharma' },
  },
  profile: defaultProfile,
  isLoading: false,
  isSupabaseMode: false,
  login: async () => ({}),
  register: async () => ({}),
  logout: async () => {},
  updateProfile: async (updates) => ({ ...defaultProfile, ...updates }),
  loginAsGuest: () => {},
  refreshProfile: async () => {},
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  return context || defaultAuthContext;
};
