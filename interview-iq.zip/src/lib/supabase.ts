import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { localDB, generateUUID } from './mock-db';
import { generateDynamicQuestions } from '../data/question-bank';
import {
  JobRole,
  Question,
  Interview,
  Answer,
  Evaluation,
  PerformanceHistory,
  Profile,
  AIEvaluationResponse,
  QuestionFilters,
  UserRoadmap,
  TopicMasteryRecord,
  AIMentorInsight,
} from '../types/database.types';


// Get Supabase configuration from environment or localStorage
export function getSupabaseCredentials(): { url: string; key: string } {
  try {
    const saved = localStorage.getItem('interviewiq_supabase_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.url && parsed.key) {
        return { url: parsed.url, key: parsed.key };
      }
    }
  } catch (e) {
    console.warn('Failed to parse saved Supabase credentials:', e);
  }

  const envUrl = import.meta.env.VITE_SUPABASE_URL || '';
  const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
  return { url: envUrl, key: envKey };
}

export function isSupabaseConfigured(): boolean {
  const { url, key } = getSupabaseCredentials();
  return Boolean(
    url &&
    key &&
    url.startsWith('http') &&
    url !== 'https://your-project.supabase.co' &&
    key !== 'your-anon-key'
  );
}

// Global Supabase client instance if configured
let _supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const { url, key } = getSupabaseCredentials();
  if (isSupabaseConfigured()) {
    if (!_supabaseInstance) {
      _supabaseInstance = createClient(url, key);
    }
    return _supabaseInstance;
  }
  return null;
}

export function resetSupabaseClient() {
  _supabaseInstance = null;
}

/**
 * Unified Database API that operates transparently against either Supabase PostgreSQL
 * or the persistent localDB layer.
 */
export const dbService = {
  // ----------------------------------------------------
  // Profiles
  // ----------------------------------------------------
  async getProfile(userId: string): Promise<Profile | null> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single();
        if (!error && data) {
          return data as Profile;
        }
      } catch (e) {
        console.warn('Supabase getProfile error:', e);
      }
    }
    return localDB.getProfile(userId);
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('profiles')
          .upsert({ id: userId, ...updates, updated_at: new Date().toISOString() })
          .select()
          .single();
        if (!error && data) {
          localDB.saveProfile(data as Profile);
          return data as Profile;
        }
      } catch (e) {
        console.warn('Supabase updateProfile error:', e);
      }
    }

    const existing = localDB.getProfile(userId);
    const updated: Profile = {
      id: userId,
      full_name: updates.full_name || existing?.full_name || 'Candidate',
      email: updates.email || existing?.email || '',
      avatar_url: updates.avatar_url !== undefined ? updates.avatar_url : existing?.avatar_url,
      cgpa: updates.cgpa !== undefined ? updates.cgpa : existing?.cgpa,
      target_role: updates.target_role !== undefined ? updates.target_role : existing?.target_role,
      interested_fields: updates.interested_fields !== undefined ? updates.interested_fields : existing?.interested_fields,
      skills: updates.skills !== undefined ? updates.skills : existing?.skills,
      preferred_companies: updates.preferred_companies !== undefined ? updates.preferred_companies : existing?.preferred_companies,
      bio: updates.bio !== undefined ? updates.bio : existing?.bio,
      is_profile_completed: true,
      created_at: existing?.created_at || new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    localDB.saveProfile(updated);
    return updated;
  },

  // ----------------------------------------------------
  // Job Roles
  // ----------------------------------------------------
  async getJobRoles(): Promise<JobRole[]> {
    const client = getSupabaseClient();
    if (client) {
      const { data, error } = await client
        .from('job_roles')
        .select('*')
        .order('created_at', { ascending: true });
      if (!error && data && data.length > 0) {
        return data as JobRole[];
      }
    }
    return localDB.getJobRoles();
  },

  // ----------------------------------------------------
  // Dynamic Smart Questions (Zero Duplicates, Field & Company Aware)
  // ----------------------------------------------------
  async getDynamicQuestions(params: {
    userId: string;
    field?: string;
    company?: string;
    difficulty?: string;
    totalQuestions?: number;
  }): Promise<Question[]> {
    const { userId, field = 'All', company = 'All', difficulty = 'Scaling', totalQuestions = 3 } = params;

    // Track previously asked questions to avoid duplicates
    const excludeIds = localDB.getAskedQuestionIds(userId);

    const questions = generateDynamicQuestions({
      field,
      company,
      difficulty,
      totalQuestions,
      excludeIds,
    });

    // Record newly selected questions
    const newQuestionIds = questions.map((q: Question) => q.id);
    localDB.recordAskedQuestions(userId, newQuestionIds);

    return questions;
  },

  // ----------------------------------------------------
  // Create Interview Record
  // ----------------------------------------------------
  async createInterview(params: {
    userId: string;
    roleId?: string;
    field?: string;
    company?: string;
    difficulty?: string;
    totalQuestions: number;
    questions?: Question[];
  }): Promise<{ interview: Interview; questions: Question[] }> {
    const { userId, roleId = null, field = 'All', company = 'All', difficulty = 'Scaling', totalQuestions } = params;

    // Generate dynamic non-repeating questions matching user's field, company & difficulty
    const selectedQuestions = params.questions || (await this.getDynamicQuestions({
      userId,
      field,
      company,
      difficulty,
      totalQuestions,
    }));

    const client = getSupabaseClient();
    if (client) {
      try {
        const { data: interviewData, error: intError } = await client
          .from('interviews')
          .insert({
            user_id: userId,
            role_id: roleId,
            status: 'in_progress',
            total_questions: selectedQuestions.length,
          })
          .select()
          .single();

        if (!intError && interviewData) {
          const mapping = selectedQuestions.map((q, idx) => ({
            interview_id: interviewData.id,
            question_id: q.id,
            sequence_number: idx + 1,
          }));

          await client.from('interview_questions').insert(mapping);
          return {
            interview: {
              ...(interviewData as Interview),
              field,
              company,
              difficulty,
            },
            questions: selectedQuestions,
          };
        }
      } catch (err) {
        console.warn('Supabase createInterview error, using local fallback:', err);
      }
    }

    // Local DB fallback
    const interviewId = generateUUID();
    const newInterview: Interview = {
      id: interviewId,
      user_id: userId,
      role_id: roleId,
      field,
      company,
      difficulty,
      status: 'in_progress',
      started_at: new Date().toISOString(),
      completed_at: null,
      total_questions: selectedQuestions.length,
      overall_score: null,
      created_at: new Date().toISOString(),
    };

    localDB.saveInterview(newInterview);
    localDB.saveInterviewQuestions(interviewId, selectedQuestions);
    return {
      interview: newInterview,
      questions: selectedQuestions,
    };
  },

  // ----------------------------------------------------
  // Save Answer and AI Evaluation
  // ----------------------------------------------------
  async saveAnswerAndEvaluation(params: {
    interviewId: string;
    questionId: string;
    userId: string;
    answerText: string;
    evaluation: AIEvaluationResponse;
  }): Promise<{ answerId: string; evaluationId: string }> {
    const { interviewId, questionId, userId, answerText, evaluation } = params;
    const client = getSupabaseClient();

    if (client) {
      try {
        const { data: ansData, error: ansError } = await client
          .from('answers')
          .insert({
            interview_id: interviewId,
            question_id: questionId,
            user_id: userId,
            answer_text: answerText,
          })
          .select()
          .single();

        if (!ansError && ansData) {
          const { data: evalData, error: evalError } = await client
            .from('evaluations')
            .insert({
              answer_id: ansData.id,
              relevance_score: evaluation.relevance_score,
              clarity_score: evaluation.clarity_score,
              content_score: evaluation.content_score,
              technical_score: evaluation.technical_score,
              communication_score: evaluation.communication_score,
              overall_score: evaluation.overall_score,
              strengths: evaluation.strengths,
              weaknesses: evaluation.weaknesses,
              suggestions: evaluation.suggestions,
              feedback: evaluation.feedback,
            })
            .select()
            .single();

          if (!evalError && evalData) {
            return { answerId: ansData.id, evaluationId: evalData.id };
          }
        }
      } catch (err) {
        console.warn('Supabase answer saving failed, falling back to localDB:', err);
      }
    }

    // Local DB save
    const answerId = generateUUID();
    const evaluationId = generateUUID();

    const answerObj: Answer = {
      id: answerId,
      interview_id: interviewId,
      question_id: questionId,
      user_id: userId,
      answer_text: answerText,
      submitted_at: new Date().toISOString(),
    };
    localDB.saveAnswer(answerObj);

    const evalObj: Evaluation = {
      id: evaluationId,
      answer_id: answerId,
      relevance_score: evaluation.relevance_score,
      clarity_score: evaluation.clarity_score,
      content_score: evaluation.content_score,
      technical_score: evaluation.technical_score,
      communication_score: evaluation.communication_score,
      overall_score: evaluation.overall_score,
      strengths: evaluation.strengths,
      weaknesses: evaluation.weaknesses,
      suggestions: evaluation.suggestions,
      feedback: evaluation.feedback,
      created_at: new Date().toISOString(),
    };
    localDB.saveEvaluation(evalObj);

    return { answerId, evaluationId };
  },

  // ----------------------------------------------------
  // Finalize / Complete Interview
  // ----------------------------------------------------
  async completeInterview(params: {
    interviewId: string;
    userId: string;
    roleId?: string | null;
    field?: string;
    company?: string;
    overallScore: number;
  }): Promise<void> {
    const { interviewId, userId, roleId = null, field, company, overallScore } = params;
    const completedAt = new Date().toISOString();
    const client = getSupabaseClient();

    if (client) {
      try {
        await client
          .from('interviews')
          .update({
            status: 'completed',
            completed_at: completedAt,
            overall_score: overallScore,
          })
          .eq('id', interviewId);

        await client.from('performance_history').insert({
          user_id: userId,
          interview_id: interviewId,
          role_id: roleId,
          score: overallScore,
          completed_at: completedAt,
        });
        return;
      } catch (err) {
        console.warn('Supabase completion update failed, fallback to localDB:', err);
      }
    }

    // Local DB update
    const interviews = localDB.getInterviews();
    const target = interviews.find(i => i.id === interviewId);
    if (target) {
      target.status = 'completed';
      target.completed_at = completedAt;
      target.overall_score = overallScore;
      localDB.saveInterview(target);
    }

    localDB.savePerformanceHistory({
      id: generateUUID(),
      user_id: userId,
      interview_id: interviewId,
      role_id: roleId,
      field,
      company,
      score: overallScore,
      completed_at: completedAt,
    });
  },

  // ----------------------------------------------------
  // Get Complete Interview Details (with Answers & Evaluations)
  // ----------------------------------------------------
  async getInterviewDetails(interviewId: string): Promise<{
    interview: Interview;
    role?: JobRole;
    answersWithEval: (Answer & { evaluation?: Evaluation; question?: Question })[];
  } | null> {
    const client = getSupabaseClient();

    if (client) {
      try {
        const { data: interviewData } = await client
          .from('interviews')
          .select('*, job_roles(*)')
          .eq('id', interviewId)
          .single();

        if (interviewData) {
          const { data: answersData } = await client
            .from('answers')
            .select('*, questions(*), evaluations(*)')
            .eq('interview_id', interviewId);

          const answersFormatted = (answersData || []).map((a: any) => ({
            ...a,
            evaluation: a.evaluations?.[0] || a.evaluations || undefined,
            question: a.questions || undefined,
          }));

          return {
            interview: interviewData,
            role: interviewData.job_roles,
            answersWithEval: answersFormatted,
          };
        }
      } catch (err) {
        console.warn('Supabase getInterviewDetails fallback:', err);
      }
    }

    // Local DB
    const interviews = localDB.getInterviews();
    const interview = interviews.find(i => i.id === interviewId);
    if (!interview) return null;

    const roles = localDB.getJobRoles();
    const role = roles.find(r => r.id === interview.role_id);

    const answers = localDB.getAnswers(interviewId);
    const questions = localDB.getQuestions();
    const evaluations = localDB.getEvaluations();

    const answersWithEval = answers.map(ans => {
      const evaluation = evaluations.find(e => e.answer_id === ans.id);
      const question = questions.find(q => q.id === ans.question_id);
      return {
        ...ans,
        evaluation,
        question,
      };
    });

    return {
      interview,
      role,
      answersWithEval,
    };
  },

  // ----------------------------------------------------
  // Get User Interviews History
  // ----------------------------------------------------
  async getUserInterviews(userId: string): Promise<Interview[]> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('interviews')
          .select('*, job_roles(*)')
          .eq('user_id', userId)
          .order('created_at', { ascending: false });

        if (!error && data) {
          return data.map((item: any) => ({
            ...item,
            job_role: item.job_roles,
          }));
        }
      } catch (err) {
        console.warn('Supabase getUserInterviews fallback:', err);
      }
    }

    const roles = localDB.getJobRoles();
    const interviews = localDB.getInterviews();
    return interviews
      .filter(i => i.user_id === userId)
      .map(i => ({
        ...i,
        job_role: roles.find(r => r.id === i.role_id),
      }))
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  // ----------------------------------------------------
  // Get User Performance / Analytics Data
  // ----------------------------------------------------
  async getUserPerformance(userId: string): Promise<PerformanceHistory[]> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('performance_history')
          .select('*, job_roles(*)')
          .eq('user_id', userId)
          .order('completed_at', { ascending: true });

        if (!error && data) {
          return data.map((item: any) => ({
            ...item,
            job_role: item.job_roles,
          }));
        }
      } catch (err) {
        console.warn('Supabase getUserPerformance fallback:', err);
      }
    }

    const roles = localDB.getJobRoles();
    const history = localDB.getPerformanceHistory(userId);
    return history
      .map(h => ({
        ...h,
        job_role: roles.find(r => r.id === h.role_id),
      }))
      .sort((a, b) => new Date(a.completed_at).getTime() - new Date(b.completed_at).getTime());
  },

  // ----------------------------------------------------
  // Career Roadmap
  // ----------------------------------------------------
  async getUserRoadmap(userId: string, targetRole = 'Full Stack Developer'): Promise<UserRoadmap> {
    return localDB.getUserRoadmap(userId, targetRole);
  },

  async saveUserRoadmap(roadmap: UserRoadmap): Promise<void> {
    localDB.saveUserRoadmap(roadmap);
  },

  async toggleRoadmapTask(userId: string, stageId: number, taskId: string): Promise<UserRoadmap> {
    return localDB.toggleRoadmapTask(userId, stageId, taskId);
  },

  async addCustomTaskToRoadmap(userId: string, stageId: number, title: string, tag?: string): Promise<UserRoadmap> {
    return localDB.addCustomTaskToRoadmap(userId, stageId, title, tag);
  },

  async addSkillGapToRoadmap(userId: string, skill: string): Promise<UserRoadmap> {
    return localDB.addSkillGapToRoadmap(userId, skill);
  },

  // ----------------------------------------------------
  // Topic Heatmap
  // ----------------------------------------------------
  async getTopicHeatmap(userId: string): Promise<TopicMasteryRecord[]> {
    return localDB.getTopicHeatmap(userId);
  },

  async saveTopicHeatmap(userId: string, records: TopicMasteryRecord[]): Promise<void> {
    localDB.saveTopicHeatmap(userId, records);
  },

  async recordTopicScore(userId: string, topic: string, score: number): Promise<void> {
    localDB.recordTopicScore(userId, topic, score);
  },

  // ----------------------------------------------------
  // AI Mentor Insights
  // ----------------------------------------------------
  async getAIMentorInsights(userId: string): Promise<AIMentorInsight[]> {
    return localDB.getAIMentorInsights(userId);
  },

  async saveAIMentorInsights(userId: string, insights: AIMentorInsight[]): Promise<void> {
    localDB.saveAIMentorInsights(userId, insights);
  },
};

