import {
  AIEvaluationResponse,
  RealtimeImprovementData,
  VoiceMetrics,
  AnswerComparisonData,
} from '../types/database.types';

export interface EvaluatePayload {
  question_text: string;
  role_name?: string;
  difficulty?: string;
  topic?: string;
  answer_text: string;
}

/**
 * Call the secure backend AI API endpoint (/api/evaluate) with automatic client-side fallback
 */
export async function evaluateAnswer(payload: EvaluatePayload): Promise<AIEvaluationResponse> {
  try {
    const res = await fetch('/api/evaluate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      const data = await res.json();
      return data as AIEvaluationResponse;
    }
  } catch (error) {
    console.warn('Backend API request failed or server not running, using resilient evaluator:', error);
  }

  // Client-side fallback evaluator implementing exact rules
  return fallbackClientEvaluator(payload);
}

function fallbackClientEvaluator(payload: EvaluatePayload): AIEvaluationResponse {
  const { question_text, role_name = 'Software Engineer', difficulty = 'Mid-Level', topic = 'Technical Core', answer_text } = payload;
  const cleanAnswer = answer_text.trim();
  const words = cleanAnswer.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  const qLower = question_text.toLowerCase();
  const aLower = cleanAnswer.toLowerCase();

  const questionKeywords = qLower
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 3 && !['what', 'when', 'where', 'which', 'explain', 'describe', 'tell', 'about', 'your', 'with', 'from', 'this', 'that', 'would', 'could', 'have', 'does'].includes(w));

  const matchedKeywords = questionKeywords.filter(kw => aLower.includes(kw));

  const technicalTerms = [
    'performance', 'scalability', 'complexity', 'tradeoff', 'cache', 'latency', 'database',
    'async', 'promise', 'component', 'state', 'architecture', 'concurrency', 'render', 'index',
    'lock', 'transaction', 'security', 'token', 'algorithm', 'memory', 'optimistic', 'pessimistic',
    'api', 'rest', 'event', 'microservice', 'load', 'idempotent', 'resilience', 'queue', 'stack'
  ];
  const domainHits = technicalTerms.filter(term => aLower.includes(term));

  const structuralMarkers = [
    'because', 'for example', 'such as', 'tradeoff', 'pros and cons', 'first', 'second',
    'in addition', 'on the other hand', 'however', 'consequently', 'result', 'therefore'
  ];
  const structureHits = structuralMarkers.filter(m => aLower.includes(m));

  let relevance = 65 + Math.min(25, matchedKeywords.length * 8);
  let clarity = 65 + Math.min(20, structureHits.length * 6) + (wordCount >= 35 ? 10 : 0);
  let content = Math.min(95, 50 + Math.min(30, wordCount / 3) + structureHits.length * 5);
  let technical = 60 + Math.min(30, domainHits.length * 7);
  let communication = 70 + (structureHits.length > 0 ? 12 : 0) + (cleanAnswer.endsWith('.') ? 8 : 0);

  if (wordCount < 20) {
    relevance = Math.max(30, relevance - 25);
    content = Math.max(25, content - 30);
    technical = Math.max(25, technical - 25);
  }

  relevance = Math.max(20, Math.min(96, Math.round(relevance)));
  clarity = Math.max(25, Math.min(95, Math.round(clarity)));
  content = Math.max(20, Math.min(95, Math.round(content)));
  technical = Math.max(20, Math.min(95, Math.round(technical)));
  communication = Math.max(30, Math.min(95, Math.round(communication)));

  const overall = Math.round(
    relevance * 0.25 +
    content * 0.25 +
    technical * 0.25 +
    clarity * 0.15 +
    communication * 0.10
  );

  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  if (matchedKeywords.length > 0) {
    strengths.push(`Directly tackled core subject matter: referenced "${matchedKeywords.slice(0, 3).join('", "')}".`);
  } else {
    weaknesses.push(`Did not explicitly cite the primary concepts required by the question prompt.`);
  }

  if (domainHits.length >= 2) {
    strengths.push(`Demonstrated appropriate technical terminology (${domainHits.slice(0, 3).join(', ')}).`);
  } else {
    weaknesses.push(`Answer relies heavily on conversational language rather than formal system concepts.`);
    suggestions.push(`Include concrete terms like caching layers, latency considerations, and failure boundaries.`);
  }

  if (structureHits.length >= 2) {
    strengths.push(`Employed logical connectives and structured reasoning ("${structureHits[0]}", "${structureHits[1]}").`);
  } else {
    suggestions.push(`Structure your thoughts into clear sections: 1) Core Definition, 2) Trade-offs, and 3) Practical Scenario.`);
  }

  if (wordCount < 30) {
    weaknesses.push(`Length (${wordCount} words) is concise but lacks in-depth architectural justification for ${difficulty} level.`);
    suggestions.push(`Elaborate on production edge cases, scaling bottlenecks, or error recovery.`);
  } else {
    strengths.push(`Delivered a well-elaborated response with solid structural depth.`);
  }

  let feedback = `The candidate achieved an overall score of ${overall}/100. `;
  if (overall >= 80) {
    feedback += `Outstanding response for a ${difficulty} ${role_name}. You addressed "${matchedKeywords.slice(0, 2).join(' ')}" accurately with strong domain insight in ${topic}.`;
  } else if (overall >= 60) {
    feedback += `Competent response for a ${difficulty} ${role_name}. You demonstrated foundational understanding of ${topic}, though expanding on system edge cases and concrete tradeoffs would significantly boost your impact.`;
  } else {
    feedback += `The response is underdeveloped for a ${difficulty} ${role_name}. It introduces high-level thoughts but lacks technical specifics and direct treatment of ${topic}.`;
  }

  return {
    relevance_score: relevance,
    clarity_score: clarity,
    content_score: content,
    technical_score: technical,
    communication_score: communication,
    overall_score: overall,
    strengths,
    weaknesses,
    suggestions,
    feedback,
  };
}

// ----------------------------------------------------
// Real-Time Answer Improver Analyzer
// ----------------------------------------------------
export function analyzeRealtimeAnswer(
  answerText: string,
  questionText: string,
  topic = 'Technical'
): RealtimeImprovementData {
  const clean = answerText.trim();
  const words = clean.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const lower = clean.toLowerCase();

  const readingTime = Math.ceil(wordCount / 2.5); // ~150 WPM speaking pace

  const introMarkers = ['is', 'defines', 'refers to', 'in my experience', 'when building', 'the core concept', 'essentially'];
  const has_intro = introMarkers.some(m => lower.includes(m)) || wordCount >= 10;

  const technicalKeywords = [
    'performance', 'scalability', 'complexity', 'tradeoff', 'cache', 'latency', 'database',
    'async', 'promise', 'component', 'state', 'architecture', 'concurrency', 'render', 'index',
    'lock', 'transaction', 'security', 'token', 'algorithm', 'memory', 'optimistic', 'pessimistic',
    'api', 'rest', 'microservice', 'distributed', 'schema', 'hook', 'dom', 'query', 'payload',
    'idempotent', 'resilience', 'queue', 'stack', 'lifecycle', 'middleware'
  ];
  const detected_keywords = technicalKeywords.filter(kw => lower.includes(kw));
  const has_technical_body = detected_keywords.length >= 2;

  const conclusionMarkers = ['in summary', 'overall', 'as a result', 'consequently', 'therefore', 'ultimately', 'to conclude', 'hence'];
  const has_conclusion = conclusionMarkers.some(m => lower.includes(m)) || (wordCount >= 60 && clean.endsWith('.'));

  const starMarkers = ['situation', 'task', 'action', 'result', 'we had to', 'my role', 'i implemented', 'resulting in'];
  const starCount = starMarkers.filter(m => lower.includes(m)).length;
  const has_star_method = starCount >= 2;

  const suggestions: string[] = [];

  if (wordCount < 20) {
    suggestions.push('Answer is too brief. State the primary definition, followed by how it operates in real systems.');
  }

  const exampleMarkers = ['for example', 'for instance', 'such as', 'e.g.', 'in a past project', 'in my experience', 'like when'];
  const hasExamples = exampleMarkers.some(m => lower.includes(m));
  if (!hasExamples && wordCount >= 15) {
    suggestions.push('💡 Add a real-world example: Describe a production scenario where you utilized this concept.');
  }

  if (detected_keywords.length < 2 && wordCount >= 20) {
    suggestions.push('💡 Explain concept deeper: Mention specific libraries, data models, or underlying protocols.');
  }

  const edgeCaseMarkers = ['edge case', 'tradeoff', 'trade-off', 'concurrency', 'error handling', 'bottleneck', 'failure', 'latency', 'fallback'];
  const hasEdgeCases = edgeCaseMarkers.some(m => lower.includes(m));
  if (!hasEdgeCases && wordCount >= 40) {
    suggestions.push('💡 Mention edge cases: Consider failure modes, memory leaks, scale limits, or async race conditions.');
  }

  if (!has_intro || (!has_conclusion && wordCount >= 50)) {
    suggestions.push('💡 Use structured answer: Follow the Intro (Definition) → Body (Implementation & Tradeoffs) → Conclusion flow.');
  }

  // Recommended keywords to prompt candidate
  const questionWords = questionText.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
  const recommended_keywords: string[] = [];
  if (lower.includes('react') || questionWords.includes('react')) {
    recommended_keywords.push('Virtual DOM', 'Reconciliation', 'useCallback / useMemo', 'State Immutability');
  } else if (lower.includes('database') || lower.includes('sql') || questionWords.includes('database') || questionWords.includes('sql')) {
    recommended_keywords.push('B-Tree Indexing', 'ACID Properties', 'EXPLAIN ANALYZE', 'Connection Pooling');
  } else if (lower.includes('api') || lower.includes('backend') || questionWords.includes('api')) {
    recommended_keywords.push('Idempotency', 'Rate Limiting', 'JWT Auth', 'Redis Caching');
  } else {
    recommended_keywords.push('Time Complexity', 'Trade-offs', 'Scalability', 'Error Handling');
  }

  let status_badge = 'Initial Draft';
  if (wordCount >= 70 && has_technical_body && hasExamples) {
    status_badge = '🌟 Comprehensive Answer';
  } else if (wordCount >= 40 && (has_technical_body || hasExamples)) {
    status_badge = '✅ Solid Progress';
  } else if (wordCount >= 20) {
    status_badge = '⚡ Needs Technical Depth';
  } else {
    status_badge = '⚠️ Too Brief';
  }

  // Generate improved STAR format answer
  let improved_star_answer = '';
  if (wordCount > 5) {
    const mainTopic = detected_keywords[0] || (topic !== 'General' ? topic : 'the required architecture');
    improved_star_answer = `**Situation:** In our production web application, we needed to optimize ${mainTopic} under high-load conditions and strict SLAs.\n\n**Task:** My responsibility was to architect a robust, scalable implementation addressing concurrency, latency bottlenecks, and fault tolerance.\n\n**Action:** ${clean.length > 50 ? clean.replace(/^i /i, 'I ') : `I established normalized models, leveraged ${recommended_keywords.slice(0, 2).join(' and ')}, and implemented defensive error handling with caching`}.\n\n**Result:** The system achieved a 65% reduction in latency, eliminated regression bugs, and supported seamless scaling across traffic spikes.`;
  }

  // Grammar & Phrasing Corrections
  const grammar_corrections: { original: string; correction: string; reason: string }[] = [];
  if (lower.includes('basically') || lower.includes('actually')) {
    grammar_corrections.push({
      original: 'basically / actually',
      correction: 'essentially / strategically',
      reason: 'Replaces conversational filler words with assertive engineering vocabulary.',
    });
  }
  if (lower.includes('i think') || lower.includes('in my opinion')) {
    grammar_corrections.push({
      original: 'I think that...',
      correction: 'Based on production benchmarks / architectural standards...',
      reason: 'Frames technical answers with empirical authority rather than hesitation.',
    });
  }
  if (lower.includes('lots of') || lower.includes('a lot of')) {
    grammar_corrections.push({
      original: 'a lot of / lots of',
      correction: 'high-volume / scalable / extensive',
      reason: 'Quantifies system throughput and scale professionally.',
    });
  }
  if (lower.includes('stuff') || lower.includes('things')) {
    grammar_corrections.push({
      original: 'stuff / things',
      correction: 'components / protocols / subsystems',
      reason: 'Specifies concrete architectural primitives.',
    });
  }
  if (clean.length > 0 && !clean.endsWith('.')) {
    grammar_corrections.push({
      original: 'Trailing unpunctuated sentence',
      correction: 'End sentence with proper punctuation.',
      reason: 'Maintains crisp, structured delivery in written assessments.',
    });
  }

  return {
    word_count: wordCount,
    reading_time_sec: readingTime,
    structure: {
      has_intro,
      has_technical_body,
      has_conclusion,
      has_star_method,
    },
    suggestions,
    detected_keywords,
    recommended_keywords,
    status_badge,
    improved_star_answer,
    grammar_corrections,
  };
}

// ----------------------------------------------------
// Factual Communication & Voice Delivery Analyzer
// ----------------------------------------------------
export function analyzeVoiceMetrics(
  transcript: string,
  speakingSeconds = 0,
  pauseCount = 0,
  isVoice = true
): VoiceMetrics {
  const clean = transcript.trim();
  const words = clean.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  const timingAvailable = Boolean(isVoice && speakingSeconds > 0);
  const safeSeconds = timingAvailable ? Math.max(speakingSeconds, 2) : 0;
  const wpm = timingAvailable ? Math.round((wordCount / safeSeconds) * 60) : 0;

  const fillerList = ['uh', 'um', 'like', 'actually', 'basically', 'you know', 'sort of', 'kind of', 'i mean', 'right'];
  const detectedFillers: string[] = [];
  let fillerCount = 0;

  const lowerWords = clean.toLowerCase().split(/\s+/);
  lowerWords.forEach((word) => {
    const stripped = word.replace(/[^\w]/g, '');
    if (fillerList.includes(stripped)) {
      fillerCount++;
      if (!detectedFillers.includes(stripped)) {
        detectedFillers.push(stripped);
      }
    }
  });

  // Structural checks
  const lowerText = clean.toLowerCase();
  const hasIntro = /^(first|to begin|in my experience|the primary|fundamentally|at its core|essentially)/i.test(lowerText) ||
    lowerText.includes('first of all') || lowerText.includes('to explain');
  const hasTechnicalBody = /(because|specifically|trade-off|architecture|performance|implementation|latency|memory|complexity)/i.test(lowerText);
  const hasConclusion = /(overall|in conclusion|therefore|as a result|ultimately|in summary|this ensures)/i.test(lowerText) || clean.endsWith('.');

  // Calculate Delivery Scores (0 - 10) based on objective signals
  let paceScore = 8.0;
  let pace_feedback = '';

  if (!timingAvailable) {
    pace_feedback = 'Audio timing unavailable (typed input) — delivery evaluated on text structure, conciseness, and filler usage.';
  } else if (wpm < 100) {
    paceScore = 6.0;
    pace_feedback = `Speaking pace is slow (${wpm} WPM). A standard engineering conversational pace is between 125-155 WPM.`;
  } else if (wpm > 175) {
    paceScore = 6.5;
    pace_feedback = `Speaking pace is fast (${wpm} WPM). Pausing briefly after major technical points improves comprehension.`;
  } else if (wpm >= 120 && wpm <= 160) {
    paceScore = 9.5;
    pace_feedback = `Optimal speaking pace (${wpm} WPM). Easy for technical interviewers to follow with clear phrase pacing.`;
  } else {
    paceScore = 8.0;
    pace_feedback = `Measured pace of ${wpm} WPM is within acceptable range. Maintain steady cadence.`;
  }

  // Filler deduction
  const fillerRatio = wordCount > 0 ? fillerCount / wordCount : 0;
  const fillerScore = Math.max(3, 10 - fillerRatio * 50);

  // Fluency & Structural articulation
  let structurePoints = (hasIntro ? 1.5 : 0) + (hasTechnicalBody ? 2 : 0) + (hasConclusion ? 1.5 : 0);
  const clarityScore = Number(Math.min(10, Math.max(3, 5 + structurePoints - Math.min(2.5, fillerRatio * 30))).toFixed(1));
  const confidenceScore = Number(((paceScore * 0.4 + fillerScore * 0.35 + (wordCount >= 25 ? 2.5 : 1.0))).toFixed(1));

  let tone = 'Professional & Direct';
  if (timingAvailable && wpm > 170) {
    tone = 'Fast-Paced Delivery';
  } else if (fillerCount >= 4) {
    tone = 'Conversational with Hesitations';
  } else if (confidenceScore >= 8.5 && clarityScore >= 8.0) {
    tone = 'Structured & Articulate';
  }

  // Objective communication delivery feedback
  let delivery_feedback = '';
  if (fillerCount === 0 && wordCount >= 25 && hasTechnicalBody) {
    delivery_feedback = 'Strong delivery: zero verbal fillers detected with well-articulated technical argumentation.';
  } else if (fillerCount > 2) {
    delivery_feedback = `Delivery noted ${fillerCount} filler occurrence${fillerCount > 1 ? 's' : ''} (${detectedFillers.slice(0, 3).join(', ')}). Replacing fillers with intentional 1-second pauses projects greater authority.`;
  } else if (!hasTechnicalBody) {
    delivery_feedback = 'Delivery is clear, but response would benefit from incorporating concrete technical mechanisms and trade-offs.';
  } else if (timingAvailable && wpm > 170) {
    delivery_feedback = 'Rapid delivery rate. Slowing down slightly allows the interviewer time to digest your architectural rationale.';
  } else {
    delivery_feedback = 'Clear, steady communication delivery aligned with professional software engineering interview standards.';
  }

  return {
    wpm,
    filler_count: fillerCount,
    filler_words: detectedFillers,
    pause_count: pauseCount,
    confidence_score: Math.min(10, Math.max(1, confidenceScore)),
    clarity_score: Math.min(10, Math.max(1, clarityScore)),
    tone,
    timing_available: timingAvailable,
    duration_seconds: timingAvailable ? speakingSeconds : undefined,
    delivery_feedback,
    personality_verdict: delivery_feedback, // Backward compatibility
    pace_feedback,
    structural_clarity: {
      has_intro: hasIntro,
      has_technical_body: hasTechnicalBody,
      has_conclusion: hasConclusion,
    },
  };
}

// ----------------------------------------------------
// AI Follow-Up Question Generator
// ----------------------------------------------------
export function generateFollowUpQuestion(
  questionText: string,
  candidateAnswer: string,
  topic = 'General'
): {
  question_text: string;
  context_reason: string;
  suggested_focus: string;
} {
  const answerLower = candidateAnswer.toLowerCase();

  if (answerLower.includes('react') || answerLower.includes('component') || answerLower.includes('hook')) {
    return {
      question_text: `You highlighted using React components and state. How do you prevent unnecessary re-renders across the component tree, and what criteria determine whether you reach for useCallback vs useMemo vs React.memo?`,
      context_reason: 'Interviewer wants to test your advanced render lifecycle & memoization mechanics.',
      suggested_focus: 'Explain referential equality, props comparison, and performance profiling.',
    };
  }

  if (answerLower.includes('sql') || answerLower.includes('database') || answerLower.includes('table') || answerLower.includes('query')) {
    return {
      question_text: `Following up on your database explanation: How would you investigate a high-latency query running against a table with 10 million rows, and how do composite B-Tree indexes impact write throughput?`,
      context_reason: 'Interviewer wants to evaluate your production indexing & query execution plan mastery.',
      suggested_focus: 'Cite EXPLAIN ANALYZE, index selectivity, write amplification, and connection pooling.',
    };
  }

  if (answerLower.includes('api') || answerLower.includes('backend') || answerLower.includes('microservice') || answerLower.includes('server')) {
    return {
      question_text: `That's a clean architectural design. How do you handle distributed failure scenarios when a downstream dependency times out, and how do you guarantee idempotency for critical payment or data modification POST endpoints?`,
      context_reason: 'Interviewer is evaluating your production resilience, circuit breaking, and idempotency guarantees.',
      suggested_focus: 'Mention Idempotency Keys, Circuit Breaker patterns, Exponential Backoff, and Dead Letter Queues.',
    };
  }

  if (answerLower.includes('algorithm') || answerLower.includes('complexity') || answerLower.includes('array') || answerLower.includes('tree')) {
    return {
      question_text: `Good algorithmic approach. What is the worst-case space complexity of your solution on deep recursion or call-stack overhead, and could this be optimized iteratively with O(1) auxiliary memory?`,
      context_reason: 'Interviewer is drilling down into space-time optimization and iterative refactoring.',
      suggested_focus: 'Analyze call stack depth, recursion vs two-pointer iterative scan, and in-place swapping.',
    };
  }

  // Default intelligent follow-up
  return {
    question_text: `Could you walk me through a specific edge case or trade-off you encountered with this approach in a real production environment, and what architectural decisions you would adjust in hindsight?`,
    context_reason: 'Interviewer is probing for self-awareness, trade-off evaluation, and senior engineering maturity.',
    suggested_focus: 'Concretely contrast alternative approaches and discuss trade-offs (e.g. speed vs memory, simplicity vs extensibility).',
  };
}

// ----------------------------------------------------
// Ideal Answer & Answer Comparison Generator
// ----------------------------------------------------
export function generateIdealAnswerComparison(
  questionText: string,
  userAnswer: string,
  topic = 'Technical',
  overallScore = 75
): {
  user_answer: string;
  ideal_answer: string;
  score_out_of_10: number;
  missing_points: string[];
  missing_keywords: string[];
  phrasing_suggestions: {
    original: string;
    improved: string;
    rationale: string;
  }[];
  depth_critique: string;
} {
  const qLower = questionText.toLowerCase();

  let ideal_answer = '';
  let missing_keywords: string[] = [];
  let missing_points: string[] = [];

  if (qLower.includes('virtual dom') || qLower.includes('reconciliation') || qLower.includes('react')) {
    ideal_answer = `The Virtual DOM is an in-memory lightweight representation of the real DOM maintained by React. When component state changes, React creates a new Virtual DOM tree and runs its Reconciliation algorithm (Fiber architecture) using heuristics like element type comparison and key props. It calculates the minimum necessary diff and batches updates into a single real DOM commit, eliminating expensive layout reflows and repaints. While modern frameworks like Svelte compile reactivity ahead-of-time, React's Virtual DOM provides an optimal declarative abstraction with predictable updates.`;
    missing_keywords = ['Fiber Architecture', 'Batching Updates', 'Layout Reflow', 'Key Props Heuristics', 'State Immutability'];
    missing_points = [
      'Mention React Fiber tree traversal and cooperative scheduling.',
      'Explain how key prop heuristics prevent tearing and redundant DOM re-mounts.',
      'Highlight the difference between render phase (pure calculation) and commit phase (DOM mutations).',
    ];
  } else if (qLower.includes('index') || qLower.includes('sql') || qLower.includes('database')) {
    ideal_answer = `A database index is an auxiliary data structure—predominantly a self-balancing B+ Tree—that allows the database engine to find specific rows in O(log N) time rather than performing a full table scan of O(N). Clustered indexes dictate the physical on-disk storage order of the rows, while non-clustered indexes maintain pointers (or primary keys) referencing the actual data. The trade-off is write amplification: every INSERT, UPDATE, or DELETE requires updating index B-Trees, which adds overhead and disk space. In production, we run EXPLAIN ANALYZE to verify index usage and build composite indexes matching multi-column filter selectivity.`;
    missing_keywords = ['B+ Tree Data Structure', 'Clustered vs Non-Clustered', 'Full Table Scan O(N)', 'Write Amplification', 'EXPLAIN ANALYZE'];
    missing_points = [
      'Contrast clustered vs non-clustered index memory pointer mechanics.',
      'Discuss write amplification trade-offs on high-frequency INSERT pipelines.',
      'Reference query execution plans using EXPLAIN ANALYZE to identify sequential table scans.',
    ];
  } else if (qLower.includes('microservice') || qLower.includes('monolith') || qLower.includes('scalability')) {
    ideal_answer = `A monolithic architecture bundles the UI, business logic, and database access into a single deployable artifact, which excels in rapid early prototyping, straightforward debugging, and zero network serialization overhead. Microservices decouple distinct business domains into independently deployable, scalable services communicating via lightweight protocols (REST, gRPC, message brokers like Kafka). However, microservices introduce distributed system complexity: network latency, distributed transactions (requiring Sagas rather than ACID locks), eventual consistency, and operational observability overhead (distributed tracing). The decision should be driven by organizational scale and independent deployability needs rather than trendiness.`;
    missing_keywords = ['Independent Deployability', 'Saga Pattern vs ACID', 'Network Latency', 'Distributed Tracing', 'Eventual Consistency'];
    missing_points = [
      'Cite distributed transaction strategies (Saga Pattern or 2-Phase Commit) vs ACID database constraints.',
      'Acknowledge network serialization latency and failure boundaries.',
      'Highlight distributed observability requirements (OpenTelemetry, distributed tracing, correlated logs).',
    ];
  } else if (qLower.includes('yourself') || qLower.includes('career') || qLower.includes('strength')) {
    ideal_answer = `I am a dedicated software engineer with a strong foundation in full-stack architecture, algorithms, and database systems. Over the course of my projects, I have engineered scalable web applications, designed normalized relational schemas, and integrated resilient REST APIs. Beyond my technical skills, I prioritize clean documentation, cross-functional collaboration, and continuous learning. In my next role, I want to contribute to high-impact products, solve complex scalability challenges, and continue growing into an architectural leader.`;
    missing_keywords = ['Quantified Project Impact', 'Collaboration', 'Continuous Learning', 'Architectural Growth'];
    missing_points = [
      'Structure intro chronologically: Background -> Key Technical Projects -> Vision for Company.',
      'Quantify past project achievements (e.g. latency improvement, user adoption, code test coverage).',
      'Articulate clear 3-5 year growth aspirations aligned with engineering leadership.',
    ];
  } else {
    ideal_answer = `To solve this in an enterprise setting, I follow a structured STAR approach: First, establish the core functional boundaries and constraints. Second, implement a modular solution emphasizing clean separation of concerns, defensive error handling, and predictable time-space complexity. Third, identify edge cases such as concurrency contention, null references, and network drops, applying mitigations like connection pooling, caching layers, and graceful degradation. Finally, quantify the business or operational impact—such as latency reduction, fault isolation, and developer velocity.`;
    missing_keywords = ['Separation of Concerns', 'Graceful Degradation', 'Concurrency Handling', 'Quantifiable Impact', 'Defensive Error Handling'];
    missing_points = [
      'Clearly delineate the functional requirements and system scale boundaries.',
      'Explicitly discuss trade-offs (e.g. latency vs consistency, memory vs CPU cycles).',
      'Provide production-level mitigations for unexpected edge cases or system failures.',
    ];
  }

  const phrasing_suggestions = [
    {
      original: 'I used a database to store data.',
      improved: 'I designed a normalized relational schema with indexed foreign keys and connection pooling.',
      rationale: 'Demonstrates architectural rigor, database mechanics, and scale-conscious vocabulary.',
    },
    {
      original: 'I made the code fast.',
      improved: 'I optimized algorithmic complexity from O(N²) to O(N log N) and implemented in-memory cache-aside invalidation.',
      rationale: 'Replaces vague claims with precise Big-O metrics and engineering design patterns.',
    },
    {
      original: 'It handles errors fine.',
      improved: 'We implemented defensive error boundaries, structured centralized logging, and automatic retry with exponential backoff.',
      rationale: 'Highlights production-grade resilience and observability rather than trivial try/catch blocks.',
    },
  ];

  const depth_critique = `Your response captured the general essence of the question. To elevate it to corporate placement standards, replace conversational summaries with explicit technical terminology (such as internal data structures and complexity guarantees), structure the answer with clear trade-offs, and cite concrete production examples.`;

  const score_out_of_10 = Number((Math.min(10, Math.max(1, overallScore / 10))).toFixed(1));

  return {
    user_answer: userAnswer,
    ideal_answer,
    score_out_of_10,
    missing_points,
    missing_keywords,
    phrasing_suggestions,
    depth_critique,
  };
}

