import {
  JobRole,
  Question,
  Interview,
  Answer,
  Evaluation,
  PerformanceHistory,
  Profile,
  UserRoadmap,
  TopicMasteryRecord,
  AIMentorInsight,
} from '../types/database.types';
import { COMPREHENSIVE_QUESTION_BANK } from '../data/question-bank';
import { getDefaultRoadmap, INITIAL_TOPIC_HEATMAP, INITIAL_AI_MENTOR_INSIGHTS } from '../data/roadmap-data';


export const DEFAULT_JOB_ROLES: JobRole[] = [
  {
    id: 'b1000000-0000-0000-0000-000000000001',
    name: 'Frontend Developer',
    description: 'Core frontend web development specializing in modern React, JavaScript/TypeScript, state management, and web performance.',
    category: 'Engineering',
    difficulty: 'Mid-Level',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000002',
    name: 'Backend Engineer',
    description: 'Server-side architecture, REST & GraphQL APIs, microservices, databases, caching, and scalable system design.',
    category: 'Engineering',
    difficulty: 'Mid-Level',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000003',
    name: 'Full Stack Developer',
    description: 'End-to-end web application development encompassing UI components, Node.js services, ORM/SQL, and cloud deployments.',
    category: 'Engineering',
    difficulty: 'Mid-Level',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000004',
    name: 'Data Scientist / ML Engineer',
    description: 'Statistical modeling, feature engineering, machine learning pipelines, LLMs, and Python data frameworks.',
    category: 'Data & AI',
    difficulty: 'Senior',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000005',
    name: 'DevOps & Cloud Engineer',
    description: 'CI/CD pipelines, Docker, Kubernetes, infrastructure-as-code, monitoring, reliability, and security practices.',
    category: 'DevOps & Infra',
    difficulty: 'Mid-Level',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000006',
    name: 'Product Manager (Tech)',
    description: 'Product discovery, requirement scoping, user story mapping, prioritization frameworks, and stakeholder communication.',
    category: 'Product',
    difficulty: 'Mid-Level',
    created_at: new Date().toISOString(),
  },
  {
    id: 'b1000000-0000-0000-0000-000000000007',
    name: 'Junior Software Engineer',
    description: 'Foundational computer science, OOPs, data structures, algorithms, debugging, and software craft.',
    category: 'Engineering',
    difficulty: 'Junior',
    created_at: new Date().toISOString(),
  },
];

// Helper to generate UUIDs
export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Local Storage Manager for persistent local database
class LocalDatabaseStore {
  private get<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(`interviewiq_${key}`);
      return data ? JSON.parse(data) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(`interviewiq_${key}`, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  getProfiles(): Profile[] {
    return this.get<Profile[]>('profiles', []);
  }

  getProfile(userId: string): Profile | null {
    const profiles = this.getProfiles();
    return profiles.find(p => p.id === userId) || null;
  }

  saveProfile(profile: Profile): void {
    const profiles = this.getProfiles();
    const index = profiles.findIndex(p => p.id === profile.id);
    if (index >= 0) {
      profiles[index] = { ...profiles[index], ...profile, updated_at: new Date().toISOString() };
    } else {
      profiles.push({ ...profile, updated_at: new Date().toISOString() });
    }
    this.set('profiles', profiles);
  }

  getJobRoles(): JobRole[] {
    return this.get<JobRole[]>('job_roles', DEFAULT_JOB_ROLES);
  }

  getQuestions(): Question[] {
    return this.get<Question[]>('questions', COMPREHENSIVE_QUESTION_BANK);
  }

  getAskedQuestionIds(userId: string): string[] {
    const list = this.get<string[]>(`asked_questions_${userId}`, []);
    return list.slice(-10);
  }

  recordAskedQuestions(userId: string, questionIds: string[]): void {
    const current = this.get<string[]>(`asked_questions_${userId}`, []);
    // Strictly preserve only the most recent 10 questions to prevent repeating the last 10
    const updated = Array.from(new Set([...current, ...questionIds])).slice(-10);
    this.set(`asked_questions_${userId}`, updated);
  }

  saveInterviewQuestions(interviewId: string, questions: Question[]): void {
    this.set(`interview_questions_${interviewId}`, questions);
  }

  getInterviewQuestions(interviewId: string): Question[] {
    return this.get<Question[]>(`interview_questions_${interviewId}`, []);
  }

  getInterviews(): Interview[] {
    return this.get<Interview[]>('interviews', []);
  }

  saveInterview(interview: Interview): void {
    const list = this.getInterviews();
    const idx = list.findIndex(i => i.id === interview.id);
    if (idx >= 0) {
      list[idx] = interview;
    } else {
      list.unshift(interview);
    }
    this.set('interviews', list);
  }

  getAnswers(interviewId?: string): Answer[] {
    const all = this.get<Answer[]>('answers', []);
    if (interviewId) {
      return all.filter(a => a.interview_id === interviewId);
    }
    return all;
  }

  saveAnswer(answer: Answer): void {
    const list = this.getAnswers();
    const idx = list.findIndex(a => a.id === answer.id);
    if (idx >= 0) {
      list[idx] = answer;
    } else {
      list.push(answer);
    }
    this.set('answers', list);
  }

  getEvaluations(): Evaluation[] {
    return this.get<Evaluation[]>('evaluations', []);
  }

  saveEvaluation(evaluation: Evaluation): void {
    const list = this.getEvaluations();
    const idx = list.findIndex(e => e.id === evaluation.id);
    if (idx >= 0) {
      list[idx] = evaluation;
    } else {
      list.push(evaluation);
    }
    this.set('evaluations', list);
  }

  getPerformanceHistory(userId?: string): PerformanceHistory[] {
    const list = this.get<PerformanceHistory[]>('performance_history', []);
    if (userId) {
      return list.filter(p => p.user_id === userId);
    }
    return list;
  }

  savePerformanceHistory(record: PerformanceHistory): void {
    const list = this.getPerformanceHistory();
    list.unshift(record);
    this.set('performance_history', list);
  }

  // ----------------------------------------------------
  // Career Roadmap
  // ----------------------------------------------------
  getUserRoadmap(userId: string, targetRole = 'Full Stack Developer'): UserRoadmap {
    const existing = this.get<UserRoadmap | null>(`roadmap_${userId}`, null);
    if (existing) {
      return existing;
    }
    const def = getDefaultRoadmap(userId, targetRole);
    this.set(`roadmap_${userId}`, def);
    return def;
  }

  saveUserRoadmap(roadmap: UserRoadmap): void {
    this.set(`roadmap_${roadmap.user_id}`, {
      ...roadmap,
      last_updated: new Date().toISOString(),
    });
  }

  toggleRoadmapTask(userId: string, stageId: number, taskId: string): UserRoadmap {
    const roadmap = this.getUserRoadmap(userId);
    const updatedStages = roadmap.stages.map((stage) => {
      if (stage.id !== stageId) return stage;
      const updatedTasks = stage.tasks.map((task) => {
        if (task.id === taskId) {
          return { ...task, completed: !task.completed };
        }
        return task;
      });
      const completedCount = updatedTasks.filter((t) => t.completed).length;
      const progress = Math.round((completedCount / updatedTasks.length) * 100);
      return {
        ...stage,
        tasks: updatedTasks,
        progress,
      };
    });

    const totalTasks = updatedStages.flatMap((s) => s.tasks);
    const completedTasks = totalTasks.filter((t) => t.completed).length;
    const overall_progress = Math.round((completedTasks / totalTasks.length) * 100);

    const updatedRoadmap: UserRoadmap = {
      ...roadmap,
      stages: updatedStages,
      overall_progress,
      last_updated: new Date().toISOString(),
    };
    this.saveUserRoadmap(updatedRoadmap);
    return updatedRoadmap;
  }

  addCustomTaskToRoadmap(userId: string, stageId: number, title: string, tag = 'Custom'): UserRoadmap {
    const roadmap = this.getUserRoadmap(userId);
    const updatedStages = roadmap.stages.map((stage) => {
      if (stage.id !== stageId) return stage;
      const newTask = {
        id: `custom-${Date.now()}`,
        title,
        completed: false,
        tag,
        difficulty: 'Intermediate' as const,
      };
      const updatedTasks = [...stage.tasks, newTask];
      const completedCount = updatedTasks.filter((t) => t.completed).length;
      const progress = Math.round((completedCount / updatedTasks.length) * 100);
      return {
        ...stage,
        tasks: updatedTasks,
        progress,
      };
    });

    const totalTasks = updatedStages.flatMap((s) => s.tasks);
    const completedTasks = totalTasks.filter((t) => t.completed).length;
    const overall_progress = Math.round((completedTasks / totalTasks.length) * 100);

    const updatedRoadmap: UserRoadmap = {
      ...roadmap,
      stages: updatedStages,
      overall_progress,
      last_updated: new Date().toISOString(),
    };
    this.saveUserRoadmap(updatedRoadmap);
    return updatedRoadmap;
  }

  addSkillGapToRoadmap(userId: string, skill: string): UserRoadmap {
    const roadmap = this.getUserRoadmap(userId);
    const currentGaps = roadmap.skill_gaps || [];
    if (!currentGaps.includes(skill)) {
      roadmap.skill_gaps = [...currentGaps, skill];
    }

    const detailed = roadmap.detailed_skill_gaps || [];
    if (!detailed.some(d => d.skill.toLowerCase() === skill.toLowerCase())) {
      detailed.unshift({
        skill,
        priority: 'High',
        category: 'Interview Weakness',
        resource_title: `${skill} Placement Preparation & Best Practices`,
        resource_url: skill.toLowerCase().includes('sql')
          ? 'https://use-the-index-luke.com/'
          : skill.toLowerCase().includes('design')
          ? 'https://github.com/donnemartin/system-design-primer'
          : 'https://leetcode.com/explore/',
        action_summary: `Directly targets weaknesses identified during interview rounds. Review core trade-offs and practice drills.`,
      });
      roadmap.detailed_skill_gaps = detailed;
    }

    // Also inject as an actionable task under Stage 3 or 4 (Intermediate/Advanced)
    const targetStage = roadmap.stages.find((s) => s.id === 3) || roadmap.stages.find((s) => s.id === 4) || roadmap.stages[0];
    if (targetStage) {
      const taskTitle = `Master interview weakness: ${skill}`;
      if (!targetStage.tasks.some((t) => t.title.includes(skill))) {
        targetStage.tasks.push({
          id: `gap-${Date.now()}`,
          title: taskTitle,
          completed: false,
          tag: 'Skill Gap',
          difficulty: 'Intermediate',
        });
      }
      const completedCount = targetStage.tasks.filter((t) => t.completed).length;
      targetStage.progress = Math.round((completedCount / targetStage.tasks.length) * 100);
    }

    const totalTasks = roadmap.stages.flatMap((s) => s.tasks);
    const completedTasks = totalTasks.filter((t) => t.completed).length;
    roadmap.overall_progress = Math.round((completedTasks / totalTasks.length) * 100);

    this.saveUserRoadmap(roadmap);
    return roadmap;
  }

  // ----------------------------------------------------
  // Topic Heatmap
  // ----------------------------------------------------
  getTopicHeatmap(userId: string): TopicMasteryRecord[] {
    return this.get<TopicMasteryRecord[]>(`topic_heatmap_${userId}`, INITIAL_TOPIC_HEATMAP);
  }

  saveTopicHeatmap(userId: string, records: TopicMasteryRecord[]): void {
    this.set(`topic_heatmap_${userId}`, records);
  }

  recordTopicScore(userId: string, topicName: string, score: number): void {
    const heatmap = this.getTopicHeatmap(userId);
    const index = heatmap.findIndex((h) => h.topic.toLowerCase() === topicName.toLowerCase());
    const status: 'strong' | 'medium' | 'weak' = score >= 75 ? 'strong' : score >= 50 ? 'medium' : 'weak';

    if (index >= 0) {
      const current = heatmap[index];
      const newScore = Math.round((current.score + score) / 2);
      heatmap[index] = {
        ...current,
        score: newScore,
        status: newScore >= 75 ? 'strong' : newScore >= 50 ? 'medium' : 'weak',
        sessions_tested: current.sessions_tested + 1,
        trend: score > current.score ? 'up' : score < current.score ? 'down' : 'neutral',
        last_tested: 'Just now',
      };
    } else {
      heatmap.push({
        topic: topicName,
        category: 'Technical',
        score,
        status,
        sessions_tested: 1,
        trend: 'neutral',
        last_tested: 'Just now',
      });
    }

    this.saveTopicHeatmap(userId, heatmap);
  }

  // ----------------------------------------------------
  // AI Mentor Insights
  // ----------------------------------------------------
  getAIMentorInsights(userId: string): AIMentorInsight[] {
    return this.get<AIMentorInsight[]>(`mentor_insights_${userId}`, INITIAL_AI_MENTOR_INSIGHTS);
  }

  saveAIMentorInsights(userId: string, insights: AIMentorInsight[]): void {
    this.set(`mentor_insights_${userId}`, insights);
  }
}

export const localDB = new LocalDatabaseStore();
